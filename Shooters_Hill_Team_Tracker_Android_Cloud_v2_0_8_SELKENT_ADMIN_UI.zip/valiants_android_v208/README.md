# Shooters Hill Team Tracker — Cloud v2.0.8

One Android app is used by Club Admins, coaches and parents. Access is enforced by the live Supabase backend rather than by hiding controls in the APK.

## Access model

- **Club Admin** signs in with the administrator email/password and can access every Shooters Hill team.
- **Coach** joins using only their **name + one-time invite code**. No email address/password is requested from the coach.
- **Parent** joins using only their **name + one-time invite code**. Parent access remains **Awaiting approval** until a coach or Club Admin approves it.
- Coaches can approve and remove parents for their own team.
- Club Admins can create Coach or Parent invites for any team and can remove team-access accounts.
- Removed accounts become `revoked` and cannot read team data. Removing access does not delete football records.

## v2.0.8 UI changes

- Club Overview has its own **Club** tab for Club Admin accounts.
- The bottom app navigation now hides while scrolling down and rises back when scrolling up.
- Android navigation-bar insets are passed into CSS so the app bar sits above gesture/three-button phone controls.
- Settings are presented as a compact list of collapsible sections.
- Award history moved to **Home → Player awards**.
- Manual backup/export controls were removed from the normal UI. Team changes are automatically archived server-side in `team_state_history`; the latest 50 revisions per team are retained.
- Player/match/award dialogs are constrained to the usable screen. Android Back, the X button and Cancel close the dialog without browser required-field validation trapping the user.
- The software keyboard uses `adjustResize` so forms remain usable on smaller phones.

## Selkent sync

- **Divisions source:** `https://www.selkent.org.uk/public/divisions/all`
- **Fixtures source:** `https://www.selkent.org.uk/public/fixtures/all`
- **League tables/results source:** `https://www.selkent.org.uk/public/results`
- The app confirms the selected team's age/division from the Divisions page before syncing fixtures/results.
- Published league tables/results sync from the Selkent Results / League Tables page for supported ages.
- Manual result entry remains only as a fallback for friendlies, tournaments or unpublished results.

## Live Supabase changes already applied

Production includes migration `invite_only_team_access_and_server_backups` and the `join-team` Edge Function. Source copies are included under:

- `supabase/migrations/20260912_v207_invite_access.sql`
- `supabase/functions/join-team/index.ts`

The invite generator no longer uses the broken unqualified `gen_random_bytes()` call. Invite codes are single-use, expiring and stored only as SHA-256 hashes.

## Cloud backup model

Every saved team-state revision archives the previous state in the server database before the new revision is stored. This replaces user-facing JSON backup/import controls. Recovery can be carried out centrally without asking coaches or parents to manage backup files.

## Build APK

The Android project uses Java 17, compile/target SDK 35. A GitHub Actions workflow can unzip this project and run:

`gradle :app:assembleDebug`

The debug APK is created at:

`app/build/outputs/apk/debug/app-debug.apk`

## Security notes

- The APK contains only the Supabase publishable key; no service-role key is shipped in the client.
- Parent writes are blocked by Row Level Security/server RPC permissions.
- Coaches can edit only their assigned team.
- Club Admin access remains tied to the authenticated admin account.
- Coach/parent synthetic auth credentials are generated only inside the `join-team` Edge Function and are never shown to users.


## v2.0.8 changes
- Selkent Divisions/Results pages are now rendered through a native background WebView before parsing, so JavaScript-driven age/division tabs populate correctly.
- Club Admin can switch between Club Overview and Coach View; Coach View uses the same team UI as a normal coach for the selected team.
- Players can be removed from the current squad without deleting historical goals, assists, bookings or awards.
