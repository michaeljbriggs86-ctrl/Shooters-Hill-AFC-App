-- Shooters Hill Team Tracker v2.0.20 inbox backend reference.
-- The live Supabase project has already been updated with this structure.
create schema if not exists private;

create or replace function private.can_message_user(p_recipient uuid)
returns boolean
language sql
stable security definer
set search_path = ''
as $$
  select exists(
    select 1
    from public.profiles me
    join public.profiles target on target.user_id = p_recipient
    where me.user_id = auth.uid()
      and me.club_id is not null
      and target.club_id = me.club_id
      and ((me.role = 'club_admin' and target.role = 'coach')
        or (me.role = 'coach' and target.role = 'club_admin'))
  );
$$;

create table if not exists public.club_messages (
  id uuid primary key default gen_random_uuid(),
  thread_id uuid not null default gen_random_uuid(),
  club_id uuid not null references public.clubs(id) on delete cascade,
  sender_user_id uuid not null references auth.users(id) on delete cascade,
  recipient_user_id uuid not null references auth.users(id) on delete cascade,
  subject text not null default '' check (char_length(subject) <= 120),
  body text not null check (char_length(body) between 1 and 4000),
  created_at timestamptz not null default now(),
  read_at timestamptz null
);
alter table public.club_messages enable row level security;
create index if not exists club_messages_club_id_idx on public.club_messages(club_id);
create index if not exists club_messages_sender_created_idx on public.club_messages(sender_user_id,created_at desc);
create index if not exists club_messages_recipient_created_idx on public.club_messages(recipient_user_id,created_at desc);
create index if not exists club_messages_thread_created_idx on public.club_messages(thread_id,created_at);

drop policy if exists club_messages_select on public.club_messages;
create policy club_messages_select on public.club_messages for select to authenticated
using ((select auth.uid()) is not null and ((select auth.uid())=sender_user_id or (select auth.uid())=recipient_user_id));
drop policy if exists club_messages_insert on public.club_messages;
create policy club_messages_insert on public.club_messages for insert to authenticated
with check ((select auth.uid()) is not null and sender_user_id=(select auth.uid()) and club_id=(select public.my_club_id()) and private.can_message_user(recipient_user_id));
drop policy if exists club_messages_update_read on public.club_messages;
create policy club_messages_update_read on public.club_messages for update to authenticated
using ((select auth.uid())=recipient_user_id) with check ((select auth.uid())=recipient_user_id);
revoke all on public.club_messages from anon;
revoke update on public.club_messages from authenticated;
grant select,insert on public.club_messages to authenticated;
grant update(read_at) on public.club_messages to authenticated;

create or replace function public.list_message_contacts()
returns table(user_id uuid, full_name text, role text, team_id uuid, team_name text, age_group integer)
language plpgsql security definer set search_path = ''
as $$
declare me public.profiles;
begin
  select p.* into me from public.profiles p where p.user_id=auth.uid();
  if me.user_id is null or me.role not in ('club_admin','coach') then return; end if;
  return query select p.user_id,p.full_name,p.role,p.team_id,t.name,t.age_group
  from public.profiles p left join public.teams t on t.id=p.team_id
  where p.club_id=me.club_id and p.user_id<>me.user_id
    and ((me.role='club_admin' and p.role='coach') or (me.role='coach' and p.role='club_admin'))
  order by t.age_group nulls last,t.name nulls last,p.full_name;
end $$;
revoke all on function public.list_message_contacts() from public,anon;
grant execute on function public.list_message_contacts() to authenticated;
