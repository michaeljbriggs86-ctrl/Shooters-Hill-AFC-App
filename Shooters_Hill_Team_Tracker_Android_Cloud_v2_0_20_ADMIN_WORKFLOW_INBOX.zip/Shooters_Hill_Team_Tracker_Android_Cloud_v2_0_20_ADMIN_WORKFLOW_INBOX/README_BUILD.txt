Shooters Hill Team Tracker Android source v2.0.20

Includes all v2.0.19 auth fixes plus the Club Admin workflow upgrade:
- Club Admin Overview now shows team health, coach assignment, squad capacity and attention alerts.
- Club-wide Fixture Centre with TBC teams, published Selkent fixtures, opposition colours and away-ground detail lookup.
- Club Results browser remains age-filtered with previous/next paging.
- Coach Overview maps coaches to teams, supports coach invite creation, removal, and direct messaging.
- Secure two-way in-app Inbox between Club Admin and coaches; Admin can message one coach or broadcast a private copy to all coaches. Parents cannot access inbox messages.
- Club Admin can open every team in a read-only preview and inspect dashboards, matches, match details, squad, tactics, stats and Selkent data without edit controls.
- Existing Supabase accounts, roles, team data and v2.0.18 tactics/results features are retained.

Supabase backend requirements for Inbox are already applied to the live project. A reference SQL file is included in this source ZIP.

Upload this ZIP as the only *Android*.zip in the Shooters-Hill-AFC-App repository. The existing GitHub Action will extract it and build Shooters-Hill-Team-Tracker.apk.
