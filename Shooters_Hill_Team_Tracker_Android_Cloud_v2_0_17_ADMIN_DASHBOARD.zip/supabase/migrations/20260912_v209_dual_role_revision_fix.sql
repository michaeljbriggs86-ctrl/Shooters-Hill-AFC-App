-- Applied to the live Shooters Hill Team Tracker project for v2.0.9.
-- 1) Fixes save_team_state() "revision is ambiguous" by qualifying history columns.
-- 2) Adds an optional coach_team_id to a Club Admin profile for dual Admin/Coach access.
-- 3) Keeps Club Admin team previews read-only at the database write layer.

alter table public.profiles
  add column if not exists coach_team_id uuid references public.teams(id) on delete set null;

create or replace function public.can_edit_team(p_team uuid)
returns boolean
language sql
stable security definer
set search_path to 'public'
as $$
  select exists(
    select 1
    from public.profiles p
    join public.teams t on t.id=p_team
    where p.user_id=auth.uid()
      and p.club_id=t.club_id
      and (
        (p.role='coach' and p.team_id=p_team)
        or
        (p.role='club_admin' and p.coach_team_id=p_team)
      )
  )
$$;

create or replace function public.get_my_context()
returns jsonb
language plpgsql
stable security definer
set search_path to 'public'
as $$
declare p public.profiles; t public.teams; ct public.teams; c public.clubs;
begin
  select * into p from public.profiles where user_id=auth.uid();
  if p.user_id is null then return null; end if;
  if p.team_id is not null then select * into t from public.teams where id=p.team_id; end if;
  if p.coach_team_id is not null then select * into ct from public.teams where id=p.coach_team_id; end if;
  if p.club_id is not null then select * into c from public.clubs where id=p.club_id; end if;
  return jsonb_build_object(
    'profile',to_jsonb(p),
    'team',case when t.id is null then null else to_jsonb(t) end,
    'coach_team',case when ct.id is null then null else to_jsonb(ct) end,
    'club',case when c.id is null then null else to_jsonb(c) end
  );
end $$;

create or replace function public.save_team_state(p_team_id uuid, p_state jsonb, p_expected_revision bigint)
returns table(revision bigint, updated_at timestamptz)
language plpgsql
security definer
set search_path to 'public'
as $$
declare current_rev bigint; current_state jsonb; new_rev bigint; stamp timestamptz;
begin
  if not public.can_edit_team(p_team_id) then raise exception 'You do not have edit access to this team'; end if;
  select ts.revision,ts.state into current_rev,current_state from public.team_state ts where ts.team_id=p_team_id for update;
  if current_rev is null then
    if p_expected_revision not in (-1,-2) then raise exception 'STALE_STATE'; end if;
    insert into public.team_state(team_id,state,revision,updated_at,updated_by)
    values(p_team_id,p_state,0,now(),auth.uid())
    returning team_state.revision,team_state.updated_at into new_rev,stamp;
  else
    if p_expected_revision<>-2 and current_rev<>p_expected_revision then raise exception 'STALE_STATE'; end if;
    insert into public.team_state_history(team_id,revision,state,archived_at,archived_by)
    values(p_team_id,current_rev,current_state,now(),auth.uid());
    update public.team_state ts
       set state=p_state,revision=current_rev+1,updated_at=now(),updated_by=auth.uid()
     where ts.team_id=p_team_id
     returning ts.revision,ts.updated_at into new_rev,stamp;
    delete from public.team_state_history h
     where h.team_id=p_team_id
       and h.id not in (
         select h2.id
         from public.team_state_history h2
         where h2.team_id=p_team_id
         order by h2.revision desc,h2.id desc
         limit 50
       );
  end if;
  return query select new_rev,stamp;
end $$;
