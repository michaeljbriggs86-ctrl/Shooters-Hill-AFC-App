-- v2.0.15 — unique team assignment + Club Admin invitations
alter table public.invitations alter column team_id drop not null;
alter table public.invitations drop constraint if exists invitations_role_check;
alter table public.invitations add constraint invitations_role_check
  check (role = any (array['club_admin'::text,'coach'::text,'parent'::text]));

create or replace function public.create_invite(
  p_team_id uuid,
  p_role text,
  p_label text default ''::text,
  p_expires_hours integer default 168
)
returns table(code text, invitation_id uuid, expires_at timestamptz)
language plpgsql
security definer
set search_path to 'public','extensions'
as $$
declare
  p public.profiles;
  t public.teams;
  v_code text;
  v_id uuid;
  v_exp timestamptz;
  v_team_id uuid;
begin
  select * into p from public.profiles where user_id=auth.uid();
  if p.role not in ('club_admin','coach') then
    raise exception 'Coach or Club Admin access required';
  end if;
  if p_role not in ('club_admin','coach','parent') then
    raise exception 'Role must be Club Admin, coach or parent';
  end if;
  if p.role='coach' and p_role<>'parent' then
    raise exception 'Coaches can only invite parents';
  end if;

  v_team_id := p_team_id;
  if p_role='club_admin' then
    if p.role<>'club_admin' then
      raise exception 'Only Club Admins can invite another Club Admin';
    end if;
    v_team_id := null;
  else
    select * into t from public.teams
      where id=v_team_id and club_id=p.club_id and active=true;
    if t.id is null then raise exception 'Team not available'; end if;
    if p.role='coach' and p.team_id<>t.id then
      raise exception 'Coaches can only invite parents to their own team';
    end if;
  end if;

  v_code='SH-'||upper(substr(replace(gen_random_uuid()::text,'-',''),1,12));
  v_exp=now()+make_interval(hours=>greatest(1,least(coalesce(p_expires_hours,168),720)));
  insert into public.invitations(club_id,team_id,role,label,code_hash,created_by,expires_at)
  values(p.club_id,v_team_id,p_role,coalesce(p_label,''),extensions.digest(v_code,'sha256'),auth.uid(),v_exp)
  returning id into v_id;
  return query select v_code,v_id,v_exp;
end $$;

create or replace function public.claim_invite_for_device(p_code text,p_user_id uuid,p_full_name text)
returns jsonb
language plpgsql
security definer
set search_path to 'public','extensions'
as $$
declare
  inv public.invitations;
  t public.teams;
  v_role text;
  v_team jsonb;
begin
  if p_user_id is null then raise exception 'Missing user'; end if;
  if length(trim(coalesce(p_full_name,'')))<2 then raise exception 'Enter your name'; end if;

  select * into inv from public.invitations
   where code_hash=extensions.digest(upper(trim(p_code)),'sha256')
     and used_at is null and expires_at>now()
   order by created_at desc limit 1 for update;
  if inv.id is null then raise exception 'Invite is invalid, expired, or already used'; end if;

  if inv.role='club_admin' then
    v_role='club_admin';
    v_team=null;
    update public.profiles
       set club_id=inv.club_id,team_id=null,coach_team_id=null,
           full_name=trim(p_full_name),role='club_admin',access_method='invite',
           approved_at=now(),approved_by=inv.created_by,updated_at=now()
     where user_id=p_user_id;
  else
    select * into t from public.teams
      where id=inv.team_id and club_id=inv.club_id and active=true;
    if t.id is null then raise exception 'The invited team is no longer available'; end if;
    v_role=case when inv.role='parent' then 'pending_parent' else 'coach' end;
    v_team=to_jsonb(t);
    update public.profiles
       set club_id=inv.club_id,team_id=inv.team_id,coach_team_id=null,
           full_name=trim(p_full_name),role=v_role,access_method='invite',
           approved_at=case when inv.role='coach' then now() else null end,
           approved_by=case when inv.role='coach' then inv.created_by else null end,
           updated_at=now()
     where user_id=p_user_id;
  end if;

  if not found then raise exception 'Profile was not created'; end if;
  update public.invitations set used_at=now(),used_by=p_user_id where id=inv.id;
  return jsonb_build_object('role',v_role,'team',v_team,'approval_required',inv.role='parent');
end $$;
