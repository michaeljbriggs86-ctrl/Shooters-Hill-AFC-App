import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "npm:@supabase/supabase-js@2";

const SUPABASE_URL = Deno.env.get("SUPABASE_URL") ?? "";
const SERVICE_ROLE = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "";
const ANON_KEY = Deno.env.get("SUPABASE_ANON_KEY") ?? "";

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Content-Type": "application/json",
};

function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), { status, headers: cors });
}

function randomSecret(bytes = 32) {
  const a = new Uint8Array(bytes);
  crypto.getRandomValues(a);
  return btoa(String.fromCharCode(...a))
    .replace(/\+/g, "-")
    .replace(/\//g, "_")
    .replace(/=+$/g, "");
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  if (req.method !== "POST") return json({ error: "Method not allowed" }, 405);
  if (!SUPABASE_URL || !SERVICE_ROLE || !ANON_KEY) {
    return json({ error: "Server authentication is not configured" }, 500);
  }

  let body: any;
  try {
    body = await req.json();
  } catch {
    return json({ error: "Invalid request" }, 400);
  }

  const name = String(body?.name ?? "").trim().replace(/\s+/g, " ").slice(0, 80);
  const inviteCode = String(body?.invite_code ?? "").trim().toUpperCase();
  if (name.length < 2) return json({ error: "Enter your name" }, 400);
  if (!/^SH-[A-Z0-9-]{6,30}$/.test(inviteCode)) return json({ error: "Enter a valid invite code" }, 400);

  const admin = createClient(SUPABASE_URL, SERVICE_ROLE, {
    auth: { persistSession: false, autoRefreshToken: false },
  });
  const anon = createClient(SUPABASE_URL, ANON_KEY, {
    auth: { persistSession: false, autoRefreshToken: false },
  });

  const localId = crypto.randomUUID();
  const email = `member-${localId}@access.shootershill.app`;
  const password = `Sh!${randomSecret(36)}`;

  const { data: created, error: createError } = await admin.auth.admin.createUser({
    email,
    password,
    email_confirm: true,
    user_metadata: { full_name: name, invite_access: true, device_account: true },
  });
  if (createError || !created?.user) {
    return json({ error: createError?.message ?? "Could not create device access" }, 400);
  }

  const userId = created.user.id;
  const cleanup = async () => {
    try { await admin.auth.admin.deleteUser(userId); } catch (_) {}
  };

  const { data: claim, error: claimError } = await admin.rpc("claim_invite_for_device", {
    p_code: inviteCode,
    p_user_id: userId,
    p_full_name: name,
  });
  if (claimError) {
    await cleanup();
    return json({ error: claimError.message || "Invite could not be claimed" }, 400);
  }

  const { data: signed, error: signError } = await anon.auth.signInWithPassword({ email, password });
  if (signError || !signed?.session) {
    await cleanup();
    return json({ error: signError?.message ?? "Could not start the device session" }, 500);
  }

  return json({
    session: signed.session,
    role: claim?.role ?? null,
    team: claim?.team ?? null,
    approval_required: Boolean(claim?.approval_required),
    display_name: name,
  });
});
