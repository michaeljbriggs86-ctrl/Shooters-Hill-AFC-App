# join-team Edge Function

Public-by-design invite exchange endpoint. It is deployed with JWT verification disabled because a valid, one-time, expiring `SH-...` invite code is the credential for this onboarding step.

It creates a random synthetic Supabase Auth identity server-side so coaches and parents never need to supply or know an email address/password. Parent identities are created as `pending_parent` and cannot read team data until a coach or Club Admin approves them.
