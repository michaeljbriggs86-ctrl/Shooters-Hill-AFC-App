# Shooters Hill Team Tracker — Cloud v2.0.11

## v2.0.11 competition-mode changes

- Reads Selkent's public Results page to identify which age groups currently have published league tables. Teams in those ages automatically run in **League** mode; other age groups run in **No-league** mode.
- League teams get a dedicated **League** bottom-navigation tab for standings, division opponents and upcoming synced fixtures.
- No-league teams do not show a league-table tab. Coaches get a **+ Result** action on Matches and enter division results directly by selecting a synced division opponent plus Home or Away.
- No-league division results are stored separately from friendlies/cups and are included in the team's division/overall records without creating a public league table.
- Club Admin overview labels every team as League or No-league using the same Selkent Results age list.


One Android app is used by Club Admins, coaches and parents. Access is enforced by the live Supabase backend rather than by hiding controls in the APK.

## Access model

- **Club Admin** signs in with the administrator email/password and can access every Shooters Hill team.
- **Coach** joins using only their **name + one-time invite code**. No email address/password is requested from the coach.
- **Parent** joins using only their **name + one-time invite code**. Parent access remains **Awaiting approval** until a coach or Club Admin approves it.
- Coaches can approve and remove parents for their own team.
- Club Admins can create Coach or Parent invites for any team and can remove team-access accounts.
- Removed accounts become `revoked` and cannot read team data. Removing access does not delete football records.

## v2.0.9 UI changes

- Club Overview has its own **Club** tab for Club Admin accounts.
- The bottom app navigation now hides while scrolling down and rises back when scrolling up.
- Android navigation-bar insets are passed into CSS so the app bar sits above gesture/three-button phone controls.
- Settings are presented as a compact list of collapsible sections.
- Award history moved to **Home → Player awards**.
- Manual backup/export controls were removed from the normal UI. Team changes are automatically archived server-side in `team_state_history`; the latest 50 revisions per team are retained.
- Player/match/award dialogs are constrained to the usable screen. Android Back, the X button and Cancel close the dialog without browser required-field validation trapping the user.
- The software keyboard uses `adjustResize` so forms remain usable on smaller phones.

## Selkent sync

- **Divisions source:** `https://www.selkent.org.uk/public/divisions/all`
- **Fixtures source:** `https://www.selkent.org.uk/public/fixtures/all`
- **League tables/results source:** `https://www.selkent.org.uk/public/results`
- The app confirms the selected team's age/division from the Divisions page before syncing fixtures/results.
- Published league tables/results sync from the Selkent Results / League Tables page for supported ages.
- Manual result entry remains only as a fallback for friendlies, tournaments or unpublished results.

## Live Supabase changes already applied

Production includes migration `invite_only_team_access_and_server_backups` and the `join-team` Edge Function. Source copies are included under:

- `supabase/migrations/20260912_v207_invite_access.sql`
- `supabase/functions/join-team/index.ts`

The invite generator no longer uses the broken unqualified `gen_random_bytes()` call. Invite codes are single-use, expiring and stored only as SHA-256 hashes.

## Cloud backup model

Every saved team-state revision archives the previous state in the server database before the new revision is stored. This replaces user-facing JSON backup/import controls. Recovery can be carried out centrally without asking coaches or parents to manage backup files.

## Build APK

The Android project uses Java 17, compile/target SDK 35. A GitHub Actions workflow can unzip this project and run:

`gradle :app:assembleDebug`

The debug APK is created at:

`app/build/outputs/apk/debug/app-debug.apk`

## Security notes

- The APK contains only the Supabase publishable key; no service-role key is shipped in the client.
- Parent writes are blocked by Row Level Security/server RPC permissions.
- Coaches can edit only their assigned team.
- Club Admin access remains tied to the authenticated admin account.
- Coach/parent synthetic auth credentials are generated only inside the `join-team` Edge Function and are never shown to users.


## v2.0.9 changes
- Selkent Divisions/Results pages are now rendered through a native background WebView before parsing, so JavaScript-driven age/division tabs populate correctly.
- Club Admin team cards open a read-only team preview. Admins who also have Coach permission get a one-tap profile switch in the header; Coach profile opens only their assigned coach team with normal coach editing rights.
- Players can be removed from the current squad without deleting historical goals, assists, bookings or awards.


## v2.0.9 reliability fixes

- Selkent division parsing now rejects page scripts, controls and unrelated text instead of accepting them as clubs. A division can never populate more than 24 validated team names.
- Selkent standings are accepted only when the team exists in the confirmed division and P/W/D/L/GF/GA/GD values are internally consistent. This prevents malformed 50+ row tables such as the U15 example.
- Previously malformed local Selkent team/table data is discarded automatically and must be re-synced.
- The live cloud `save_team_state` function was repaired so revision-history cleanup no longer raises `column reference "revision" is ambiguous`.
- Michael's Club Admin account is configured with dual Coach access to U9 Valiants; the profile switch appears only when an admin account also has an assigned coach team.

## v2.0.11
- League tab is forcibly hidden for Selkent no-league age groups.
- Coaches can create/remove custom award types without deleting historical awards.
- Android status-bar inset is applied to the header so content clears battery/signal/notification icons.
- Club Admin can see all coach accounts with app access and revoke a coach without deleting team data.
- Coach Club tab shows only Selkent-published Shooters Hill results; no squad, awards, notes or other teams' private data is exposed.
