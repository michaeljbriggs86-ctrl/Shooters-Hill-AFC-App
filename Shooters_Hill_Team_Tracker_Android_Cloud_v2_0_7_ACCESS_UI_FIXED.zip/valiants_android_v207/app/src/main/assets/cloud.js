(function(){
  'use strict';

  const cfg = window.VALIANTS_CLOUD || {};
  const SESSION_KEY = 'shooters_hill_cloud_session_v2';
  const INVITE_KEY = 'shooters_hill_pending_invite_v2';
  const ACTIVE_TEAM_KEY = 'shooters_hill_admin_active_team_v2';
  const VERIFY_EMAIL_KEY = 'shooters_hill_verify_email_v2';
  const AUTH_REDIRECT = 'shootershilltracker://auth-callback';
  const INITIAL_AUTH_CALLBACK = new URLSearchParams(location.search).get('auth_callback') || '';
  let initialAuthCallbackHandled = false;
  let session = null;
  let context = null;
  let visibleTeams = [];
  let activeTeam = null;
  let activeRevision = -1;
  let lastRemoteUpdatedAt = '';
  let saveTimer = null;
  let saving = false;
  let pendingState = null;
  let pollTimer = null;
  let hooks = {};

  function configured(){
    return cfg.enabled !== false && /^https:\/\/.+\.supabase\.co$/i.test(String(cfg.url||'')) &&
      String(cfg.anonKey||'').length > 40 && !String(cfg.anonKey).includes('YOUR-');
  }
  function base(){ return String(cfg.url||'').replace(/\/$/,''); }
  function emitStatus(text, type='info'){
    const el=document.getElementById('cloud-sync-status');
    if(el){el.textContent=text;el.dataset.state=type;}
    window.dispatchEvent(new CustomEvent('valiants-cloud-status',{detail:{text,type}}));
  }
  function saveSession(s){
    session=s||null;
    if(session) localStorage.setItem(SESSION_KEY,JSON.stringify(session));
    else localStorage.removeItem(SESSION_KEY);
  }
  function loadSession(){
    try{return JSON.parse(localStorage.getItem(SESSION_KEY)||'null');}catch{return null;}
  }
  function authHeaders(accessToken){
    const h={'apikey':cfg.anonKey,'Content-Type':'application/json'};
    if(accessToken)h['Authorization']='Bearer '+accessToken;
    return h;
  }
  async function request(path,{method='GET',body=null,token=true,headers={}}={}){
    const res=await fetch(base()+path,{method,headers:{...authHeaders(token?session?.access_token:null),...headers},body:body==null?undefined:JSON.stringify(body)});
    const text=await res.text();
    let data=null;try{data=text?JSON.parse(text):null;}catch{data=text;}
    if(!res.ok){
      const msg=(data&&typeof data==='object'&&(data.msg||data.message||data.error_description||data.hint||data.details||data.error))||text||('HTTP '+res.status);
      const err=new Error(msg);err.status=res.status;err.data=data;throw err;
    }
    return {data,headers:res.headers,status:res.status};
  }
  async function refreshSession(){
    if(!session?.refresh_token)return false;
    try{
      const res=await fetch(base()+'/auth/v1/token?grant_type=refresh_token',{method:'POST',headers:authHeaders(),body:JSON.stringify({refresh_token:session.refresh_token})});
      const data=await res.json();
      if(!res.ok||!data.access_token)throw new Error(data?.msg||data?.error_description||'Session refresh failed');
      data.expires_at=Math.floor(Date.now()/1000)+(data.expires_in||3600);
      saveSession(data);return true;
    }catch{saveSession(null);return false;}
  }
  async function ensureFreshSession(){
    session=loadSession();
    if(!session?.access_token)return false;
    const exp=Number(session.expires_at||0);
    if(!exp||exp < Math.floor(Date.now()/1000)+90)return await refreshSession();
    return true;
  }
  async function signIn(email,password){
    const res=await fetch(base()+'/auth/v1/token?grant_type=password',{method:'POST',headers:authHeaders(),body:JSON.stringify({email,password})});
    const data=await res.json();
    if(!res.ok)throw new Error(data?.error_description||data?.msg||data?.message||'Sign in failed');
    data.expires_at=Math.floor(Date.now()/1000)+(data.expires_in||3600);saveSession(data);return data;
  }
  async function signUp(email,password,fullName,inviteCode){
    const url=base()+'/auth/v1/signup?redirect_to='+encodeURIComponent(AUTH_REDIRECT);
    const res=await fetch(url,{method:'POST',headers:authHeaders(),body:JSON.stringify({email,password,data:{full_name:fullName||''}})});
    const data=await res.json();
    if(!res.ok)throw new Error(data?.msg||data?.message||data?.error_description||'Account creation failed');
    if(inviteCode)localStorage.setItem(INVITE_KEY,inviteCode.trim());
    localStorage.setItem(VERIFY_EMAIL_KEY,email.trim());
    if(data?.access_token){data.expires_at=Math.floor(Date.now()/1000)+(data.expires_in||3600);saveSession(data);}
    return data;
  }
  async function resendSignup(email){
    const res=await fetch(base()+'/auth/v1/resend?redirect_to='+encodeURIComponent(AUTH_REDIRECT),{method:'POST',headers:authHeaders(),body:JSON.stringify({type:'signup',email})});
    const data=await res.json().catch(()=>({}));
    if(!res.ok)throw new Error(data?.msg||data?.message||data?.error_description||'Could not resend confirmation email');
    localStorage.setItem(VERIFY_EMAIL_KEY,email.trim());
    return data;
  }
  async function sendPasswordReset(email){
    const res=await fetch(base()+'/auth/v1/recover?redirect_to='+encodeURIComponent(AUTH_REDIRECT),{method:'POST',headers:authHeaders(),body:JSON.stringify({email})});
    const data=await res.json().catch(()=>({}));
    if(!res.ok)throw new Error(data?.msg||data?.message||data?.error_description||'Could not send password reset email');
    return data;
  }
  async function joinWithInvite(name,inviteCode){
    const res=await fetch(base()+'/functions/v1/join-team',{method:'POST',headers:{'apikey':cfg.anonKey,'Content-Type':'application/json'},body:JSON.stringify({name:String(name||'').trim(),invite_code:String(inviteCode||'').trim()})});
    const data=await res.json().catch(()=>({}));
    if(!res.ok||!data?.session?.access_token)throw new Error(data?.error||data?.message||'Could not join the team');
    const next=data.session;
    if(!next.expires_at)next.expires_at=Math.floor(Date.now()/1000)+Number(next.expires_in||3600);
    saveSession(next);
    return data;
  }

  async function updatePassword(newPassword){
    const {data}=await request('/auth/v1/user',{method:'PUT',body:{password:newPassword}});
    if(session&&data){session.user=data;saveSession(session);}
    return data;
  }
  async function hydrateSessionUser(){
    try{
      const {data}=await request('/auth/v1/user');
      if(session&&data){session.user=data;saveSession(session);}
    }catch{}
  }
  async function handleAuthCallback(uri,{duringBootstrap=false}={}){
    if(!uri)return null;
    try{
      const u=new URL(uri);
      const hash=new URLSearchParams((u.hash||'').replace(/^#/,''));
      const query=u.searchParams;
      const get=(k)=>hash.get(k)||query.get(k)||'';
      const error=get('error_description')||get('error');
      if(error){setGateHtml('signin',decodeURIComponent(error.replace(/\+/g,' ')));return 'error';}
      const accessToken=get('access_token');
      const refreshToken=get('refresh_token');
      const type=get('type');
      if(!accessToken||!refreshToken)return null;
      const expiresIn=Number(get('expires_in')||3600);
      saveSession({access_token:accessToken,refresh_token:refreshToken,token_type:get('token_type')||'bearer',expires_in:expiresIn,expires_at:Math.floor(Date.now()/1000)+expiresIn});
      await hydrateSessionUser();
      localStorage.removeItem(VERIFY_EMAIL_KEY);
      if(type==='recovery'){
        setGateHtml('newpassword','Password reset verified. Choose your new password below.');
        return 'recovery';
      }
      if(!duringBootstrap) location.reload();
      return type||'auth';
    }catch(e){
      if(!duringBootstrap)setGateHtml('signin','The email link could not be opened in the app. '+(e.message||''));
      return 'error';
    }
  }
  async function rpc(name,args={}){
    const {data}=await request('/rest/v1/rpc/'+encodeURIComponent(name),{method:'POST',body:args});return data;
  }
  async function getContext(){
    let data=await rpc('get_my_context',{});
    if(Array.isArray(data)&&data.length===1)data=data[0];
    if(data&&data.context)data=data.context;
    return data;
  }
  async function claimInvite(code){return await rpc('claim_invite',{p_code:String(code||'').trim()});}
  async function listTeams(){
    const {data}=await request('/rest/v1/teams?select=id,club_id,name,age_group,division,season,selkent_label,league_name,active&active=eq.true&order=age_group.asc,name.asc');
    return Array.isArray(data)?data:[];
  }
  function oldShapeTeam(t){
    if(!t)return null;
    const age = typeof t.age_group==='number'?'U'+t.age_group:String(t.age_group||'');
    return {id:t.id,selkentName:t.selkent_label||t.name,teamName:t.name,ageGroup:age,leagueName:t.league_name||t.name,division:t.division||'',season:t.season||''};
  }
  function role(){
    const r=context?.profile?.role||context?.role||'pending';
    return r==='club_admin'?'admin':r;
  }
  function assignedTeam(){
    const t=context?.team||null;return oldShapeTeam(t);
  }
  function canEdit(){return ['admin','coach'].includes(role());}
  function canAdmin(){return role()==='admin';}
  function teamMatchesState(team,state){
    const stateName=String(state?.division?.teamName||state?.meta?.teamName||'').toLowerCase().replace(/[^a-z0-9]+/g,' ').trim();
    const teamName=String(team?.league_name||team?.name||'').toLowerCase().replace(/[^a-z0-9]+/g,' ').trim();
    return stateName && teamName && (stateName===teamName || stateName.includes(teamName) || teamName.includes(stateName));
  }
  function chooseActiveTeam(localState){
    if(!visibleTeams.length)return null;
    const own=context?.team;
    if(own)return visibleTeams.find(t=>t.id===own.id)||own;
    const stored=localStorage.getItem(ACTIVE_TEAM_KEY);
    let found=visibleTeams.find(t=>t.id===stored);
    if(!found)found=visibleTeams.find(t=>teamMatchesState(t,localState));
    if(!found)found=visibleTeams[0];
    localStorage.setItem(ACTIVE_TEAM_KEY,found.id);return found;
  }
  async function fetchTeamState(teamId){
    const {data}=await request('/rest/v1/team_state?team_id=eq.'+encodeURIComponent(teamId)+'&select=state,revision,updated_at&limit=1');
    const row=Array.isArray(data)?data[0]:null;
    if(row){activeRevision=Number(row.revision||0);lastRemoteUpdatedAt=row.updated_at||'';}
    else{activeRevision=-1;lastRemoteUpdatedAt='';}
    return row||null;
  }
  async function getClubOverview(){
    if(!canAdmin())return [];
    const {data}=await request('/rest/v1/team_state?select=team_id,state,revision,updated_at&order=updated_at.desc');
    const byTeam=new Map((Array.isArray(data)?data:[]).map(row=>[row.team_id,row]));
    return visibleTeams.map(t=>{
      const row=byTeam.get(t.id)||{};
      return {team:oldShapeTeam(t),state:row.state||{},revision:Number(row.revision||0),updatedAt:row.updated_at||''};
    });
  }
  async function saveTeamStateNow(nextState,{force=false}={}){
    if(!configured()||!session||!activeTeam||!canEdit())return null;
    if(saving){pendingState=nextState;return null;}
    saving=true;emitStatus('Saving…','working');
    try{
      const data=await rpc('save_team_state',{p_team_id:activeTeam.id,p_state:nextState,p_expected_revision:force?-2:activeRevision});
      const row=Array.isArray(data)?data[0]:data;
      if(row){activeRevision=Number(row.revision);lastRemoteUpdatedAt=row.updated_at||lastRemoteUpdatedAt;}
      emitStatus('Cloud synced','ok');return row;
    }catch(err){
      if(String(err.message||'').includes('STALE_STATE')){
        emitStatus('Newer cloud changes found — reloading','warn');
        const row=await fetchTeamState(activeTeam.id);
        if(row?.state&&hooks.onRemoteState)hooks.onRemoteState(row.state,{reason:'conflict'});
      }else emitStatus('Sync failed: '+(err.message||err),'error');
      throw err;
    }finally{
      saving=false;
      if(pendingState){const p=pendingState;pendingState=null;setTimeout(()=>saveTeamStateNow(p).catch(()=>{}),50);}
    }
  }
  function queueStateSave(nextState){
    if(!configured()||!canEdit()||!activeTeam)return;
    pendingState=JSON.parse(JSON.stringify(nextState));
    clearTimeout(saveTimer);
    saveTimer=setTimeout(()=>{const p=pendingState;pendingState=null;if(p)saveTeamStateNow(p).catch(()=>{});},700);
  }
  async function pullLatest({quiet=false}={}){
    if(!configured()||!session||!activeTeam)return null;
    if(!quiet)emitStatus('Checking cloud…','working');
    try{
      const before=activeRevision;
      const row=await fetchTeamState(activeTeam.id);
      if(row?.state&&Number(row.revision)!==before&&hooks.onRemoteState){hooks.onRemoteState(row.state,{reason:'pull'});}
      if(!quiet)emitStatus('Cloud synced','ok');
      return row;
    }catch(err){if(!quiet)emitStatus('Sync failed: '+(err.message||err),'error');return null;}
  }
  async function switchAdminTeam(teamId,seedFactory){
    if(!canAdmin())throw new Error('Club Admin access required');
    const team=visibleTeams.find(t=>t.id===teamId);if(!team)throw new Error('Team not found');
    if(pendingState&&canEdit()){const p=pendingState;pendingState=null;await saveTeamStateNow(p).catch(()=>{});}
    activeTeam=team;localStorage.setItem(ACTIVE_TEAM_KEY,team.id);
    const row=await fetchTeamState(team.id);
    if(row?.state){hooks.onRemoteState&&hooks.onRemoteState(row.state,{reason:'switch'});}
    else if(seedFactory){
      const seed=seedFactory(oldShapeTeam(team));
      activeRevision=-1;
      await saveTeamStateNow(seed);
      hooks.onRemoteState&&hooks.onRemoteState(seed,{reason:'switch-seed'});
    }
    updateCloudPanel();return oldShapeTeam(team);
  }
  async function createInvite({teamId,role:inviteRole,label='',expiresHours=168}){
    if(!['admin','coach'].includes(role()))throw new Error('Coach or Club Admin access required');
    if(role()==='coach'&&inviteRole!=='parent')throw new Error('Coaches can only invite parents');
    const data=await rpc('create_invite',{p_team_id:teamId,p_role:inviteRole,p_label:label||'',p_expires_hours:expiresHours});
    return Array.isArray(data)?data[0]:data;
  }
  async function listTeamMembers(teamId=null){
    if(!['admin','coach'].includes(role()))return [];
    const data=await rpc('list_team_members',{p_team_id:teamId||null});
    return Array.isArray(data)?data:[];
  }
  async function approveParent(userId){
    if(!['admin','coach'].includes(role()))throw new Error('Coach or Club Admin access required');
    return await rpc('approve_parent',{p_user_id:userId});
  }
  async function removeTeamMember(userId){
    if(!['admin','coach'].includes(role()))throw new Error('Coach or Club Admin access required');
    return await rpc('remove_team_member',{p_user_id:userId});
  }
  async function syncTeamDirectory(teams){
    if(!canAdmin())return 0;
    const payload=(teams||[]).map(t=>({name:t.teamName,age_group:Number(String(t.ageGroup||'').replace(/\D/g,''))||0,selkent_label:t.selkentName,league_name:t.leagueName})).filter(t=>t.name&&t.age_group&&t.selkent_label&&t.league_name);
    if(!payload.length)return 0;
    const result=await rpc('sync_team_directory',{p_teams:payload});
    visibleTeams=await listTeams();
    return Number(result?.count??result??payload.length);
  }
  function visibleTeamList(){return visibleTeams.map(oldShapeTeam);}
  function currentTeam(){return oldShapeTeam(activeTeam);}

  function setGateHtml(mode='join',message='',prefillEmail=''){
    const gate=document.getElementById('activation-gate');
    if(!gate)return;
    gate.classList.remove('hidden');
    document.body.classList.add('auth-open');
    document.querySelector('.app-shell')?.classList.add('account-locked');

    if(mode==='approval'||context?.profile?.role==='pending_parent'){
      const p=context?.profile||{};const t=context?.team?oldShapeTeam(context.team):null;
      gate.innerHTML=`<div class="activation-card cloud-auth-card"><img src="club-logo.png" alt="Shooters Hill Football Club logo" class="activation-logo"/><p class="kicker">Parent access</p><h1>Waiting for approval</h1><p class="muted"><strong>${escapeHtml(p.full_name||'Parent')}</strong>${t?` has requested access to <strong>${escapeHtml(t.ageGroup+' '+t.teamName)}</strong>.`:''} A team coach must approve the request before team data is shown.</p><p class="auth-notice ${message?'':'hidden'}" id="cloud-auth-notice">${escapeHtml(message)}</p><button class="primary-button large" id="cloud-check-approval">Check approval</button><button class="text-button" id="cloud-reset-device">Use a different invite</button></div>`;
      document.getElementById('cloud-check-approval')?.addEventListener('click',async()=>{try{context=await getContext();if(context?.profile?.role==='parent')location.reload();else showNotice('Still waiting for a coach to approve access.');}catch(e){authError(e.message||String(e));}});
      document.getElementById('cloud-reset-device')?.addEventListener('click',signOut);
      setTimeout(async()=>{try{context=await getContext();if(context?.profile?.role==='parent')location.reload();}catch{}},15000);
      return;
    }

    if(mode==='revoked'||context?.profile?.role==='revoked'){
      gate.innerHTML=`<div class="activation-card cloud-auth-card"><img src="club-logo.png" alt="Shooters Hill Football Club logo" class="activation-logo"/><p class="kicker">Team access</p><h1>Access removed</h1><p class="muted">This device no longer has access to a team. Ask a coach or Club Admin for a new invite code.</p><button class="primary-button large" id="cloud-reset-device">Join with a new invite</button></div>`;
      document.getElementById('cloud-reset-device')?.addEventListener('click',signOut);return;
    }

    if(mode==='verify'){
      const email=prefillEmail||localStorage.getItem(VERIFY_EMAIL_KEY)||'';
      gate.innerHTML=`<div class="activation-card cloud-auth-card"><img src="club-logo.png" alt="Shooters Hill Football Club logo" class="activation-logo"/><p class="kicker">Verify Club Admin email</p><h1>Check your inbox</h1><p class="muted">Tap the confirmation link in the email. It will return you to the app.</p><label for="cloud-verify-email">Email address<input id="cloud-verify-email" type="email" autocomplete="off" value="${escapeHtml(email)}" placeholder="name@example.com"/></label><p class="auth-notice ${message?'':'hidden'}" id="cloud-auth-notice">${escapeHtml(message)}</p><p class="activation-error hidden" id="cloud-auth-error"></p><button class="primary-button large" id="cloud-resend-btn">Resend confirmation email</button><button class="text-button" id="cloud-back-signin">Back to Club Admin sign in</button></div>`;
      document.getElementById('cloud-resend-btn')?.addEventListener('click',async()=>{const addr=document.getElementById('cloud-verify-email')?.value?.trim();if(!addr)return authError('Enter your email address.');try{await resendSignup(addr);showNotice('Confirmation email sent.');}catch(e){authError(e.message||String(e));}});
      document.getElementById('cloud-back-signin')?.addEventListener('click',()=>setGateHtml('signin'));return;
    }

    if(mode==='forgot'){
      gate.innerHTML=`<div class="activation-card cloud-auth-card"><img src="club-logo.png" alt="Shooters Hill Football Club logo" class="activation-logo"/><p class="kicker">Club Admin recovery</p><h1>Reset password</h1><p class="muted">Password recovery is only needed for Club Admin accounts. Coaches and parents use invite access.</p><label for="cloud-reset-email">Email address<input id="cloud-reset-email" type="email" autocomplete="off" autocapitalize="none" spellcheck="false" placeholder="name@example.com"/></label><p class="auth-notice ${message?'':'hidden'}" id="cloud-auth-notice">${escapeHtml(message)}</p><p class="activation-error hidden" id="cloud-auth-error"></p><button class="primary-button large" id="cloud-reset-send">Send reset email</button><button class="text-button" id="cloud-back-signin">Back</button></div>`;
      document.getElementById('cloud-reset-send')?.addEventListener('click',async()=>{const email=document.getElementById('cloud-reset-email')?.value?.trim();if(!email)return authError('Enter your email address.');try{await sendPasswordReset(email);showNotice('Password reset email sent.');}catch(e){authError(e.message||String(e));}});
      document.getElementById('cloud-back-signin')?.addEventListener('click',()=>setGateHtml('signin'));return;
    }

    if(mode==='newpassword'){
      gate.innerHTML=`<div class="activation-card cloud-auth-card"><img src="club-logo.png" alt="Shooters Hill Football Club logo" class="activation-logo"/><p class="kicker">Club Admin account</p><h1>Choose new password</h1><label for="cloud-new-password">New password<input id="cloud-new-password" type="password" autocomplete="new-password" placeholder="New password"/></label><label for="cloud-new-password2">Confirm new password<input id="cloud-new-password2" type="password" autocomplete="new-password" placeholder="Repeat new password"/></label><p class="auth-notice ${message?'':'hidden'}" id="cloud-auth-notice">${escapeHtml(message)}</p><p class="activation-error hidden" id="cloud-auth-error"></p><button class="primary-button large" id="cloud-password-save">Save new password</button><button class="text-button" id="cloud-password-cancel">Cancel</button></div>`;
      document.getElementById('cloud-password-save')?.addEventListener('click',async()=>{const a=document.getElementById('cloud-new-password')?.value||'';const b=document.getElementById('cloud-new-password2')?.value||'';if(a.length<8)return authError('Use at least 8 characters.');if(a!==b)return authError('The passwords do not match.');try{await updatePassword(a);location.reload();}catch(e){authError(e.message||String(e));}});
      document.getElementById('cloud-password-cancel')?.addEventListener('click',()=>{if(session?.access_token)location.reload();else setGateHtml('signin');});return;
    }

    if(mode==='signin'){
      gate.innerHTML=`<div class="activation-card cloud-auth-card"><img src="club-logo.png" alt="Shooters Hill Football Club logo" class="activation-logo"/><p class="kicker">Club administration</p><h1>Club Admin sign in</h1><p class="muted">Coaches and parents do not need an email address. Use Join team instead.</p><label for="cloud-email">Email address<input id="cloud-email" type="email" autocomplete="username" autocapitalize="none" spellcheck="false" placeholder="name@example.com"/></label><label for="cloud-password">Password<input id="cloud-password" type="password" autocomplete="current-password" placeholder="Password"/></label><p class="auth-notice ${message?'':'hidden'}" id="cloud-auth-notice">${escapeHtml(message)}</p><p class="activation-error hidden" id="cloud-auth-error"></p><button class="primary-button large" id="cloud-auth-submit">Sign in</button><button class="text-button cloud-forgot-password" id="cloud-forgot-password">Forgot password?</button><button class="text-button" id="cloud-back-join">Join a team with invite code</button></div>`;
      document.getElementById('cloud-forgot-password')?.addEventListener('click',()=>setGateHtml('forgot'));
      document.getElementById('cloud-back-join')?.addEventListener('click',()=>setGateHtml('join'));
      document.getElementById('cloud-auth-submit')?.addEventListener('click',async()=>{const email=document.getElementById('cloud-email')?.value?.trim();const password=document.getElementById('cloud-password')?.value||'';if(!email||!password)return authError('Enter your email and password.');try{await signIn(email,password);location.reload();}catch(e){const msg=e.message||String(e);if(/confirm|verified/i.test(msg)){localStorage.setItem(VERIFY_EMAIL_KEY,email);setGateHtml('verify','Your email still needs confirming.',email);}else authError(msg);}});
      return;
    }

    gate.innerHTML=`<div class="activation-card cloud-auth-card"><img src="club-logo.png" alt="Shooters Hill Football Club logo" class="activation-logo"/><p class="kicker">Shooters Hill team access</p><h1>Join your team</h1><p class="muted">Enter your name and the invite code supplied by your coach or Club Admin. No email address or password is required.</p><label for="cloud-join-name">Your name<input id="cloud-join-name" type="text" autocomplete="off" autocapitalize="words" spellcheck="false" placeholder="e.g. Michael Briggs"/></label><label for="cloud-join-code">Invite code<input id="cloud-join-code" type="text" autocomplete="one-time-code" autocapitalize="characters" spellcheck="false" placeholder="SH-…"/></label><p class="auth-notice ${message?'':'hidden'}" id="cloud-auth-notice">${escapeHtml(message)}</p><p class="activation-error hidden" id="cloud-auth-error"></p><button class="primary-button large" id="cloud-join-submit">Join team</button><button class="text-button" id="cloud-admin-signin">Club Admin sign in</button></div>`;
    requestAnimationFrame(()=>['cloud-join-name','cloud-join-code'].forEach(id=>{const el=document.getElementById(id);if(el)el.value='';}));
    document.getElementById('cloud-admin-signin')?.addEventListener('click',()=>setGateHtml('signin'));
    document.getElementById('cloud-join-submit')?.addEventListener('click',async()=>{const name=document.getElementById('cloud-join-name')?.value?.trim()||'';const code=document.getElementById('cloud-join-code')?.value?.trim()||'';if(name.length<2)return authError('Enter your name.');if(!code)return authError('Enter your invite code.');try{const joined=await joinWithInvite(name,code);if(joined?.approval_required){location.reload();return;}location.reload();}catch(e){authError(e.message||String(e));}});
  }
  function escapeHtml(s=''){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
  function authError(msg){const el=document.getElementById('cloud-auth-error');if(el){el.textContent=msg;el.classList.remove('hidden');}const notice=document.getElementById('cloud-auth-notice');if(notice)notice.classList.add('hidden');}
  function showNotice(msg){const el=document.getElementById('cloud-auth-notice');if(el){el.textContent=msg;el.classList.remove('hidden');}const err=document.getElementById('cloud-auth-error');if(err)err.classList.add('hidden');}
  function hideGate(){document.getElementById('activation-gate')?.classList.add('hidden');document.body.classList.remove('auth-open');document.querySelector('.app-shell')?.classList.remove('account-locked');}
  function signOut(){saveSession(null);context=null;visibleTeams=[];activeTeam=null;localStorage.removeItem(INVITE_KEY);location.reload();}

  function updateCloudPanel(){
    const panel=document.getElementById('access-panel');if(!panel||!configured()||!context)return;
    panel.classList.add('cloud-access-panel');
    const profile=context.profile||{};const t=currentTeam();const inviteAccess=profile.access_method==='invite'||session?.user?.user_metadata?.invite_access;
    const summary=document.getElementById('access-summary');
    if(summary)summary.textContent=`${profile.full_name||'Account'} · ${role()==='admin'?'Club Admin':role()==='coach'?'Coach':'Parent'}${t?' · '+t.ageGroup+' '+t.teamName:''}`;
    let controls=document.getElementById('cloud-account-controls');
    if(!controls){controls=document.createElement('div');controls.id='cloud-account-controls';controls.className='cloud-account-controls';panel.querySelector('.settings-accordion-body')?.appendChild(controls)||panel.appendChild(controls);}
    controls.innerHTML=`<div class="cloud-account-row"><span><strong>${escapeHtml(inviteAccess?(profile.full_name||'Invite access'):(session?.user?.email||profile.full_name||''))}</strong><small id="cloud-sync-status">Cloud connected</small></span><div class="cloud-account-actions"><button class="secondary-button compact" id="cloud-sync-now">Sync now</button>${inviteAccess?'':`<button class="secondary-button compact" id="cloud-change-password">Change password</button><button class="text-button" id="cloud-signout-settings">Sign out</button>`}</div></div>`;
    document.getElementById('cloud-sync-now')?.addEventListener('click',()=>pullLatest({quiet:false}));
    document.getElementById('cloud-change-password')?.addEventListener('click',()=>setGateHtml('newpassword'));
    document.getElementById('cloud-signout-settings')?.addEventListener('click',signOut);
    document.body.classList.add('cloud-enabled');
  }

  async function bootstrap(options={}){
    hooks=options||{};
    if(!configured()){document.body.classList.add('cloud-not-configured');return {configured:false};}
    document.body.classList.add('cloud-enabled');
    if(INITIAL_AUTH_CALLBACK&&!initialAuthCallbackHandled){initialAuthCallbackHandled=true;const callbackType=await handleAuthCallback(INITIAL_AUTH_CALLBACK,{duringBootstrap:true});if(callbackType==='recovery'||callbackType==='error')return null;}
    const valid=await ensureFreshSession();
    if(!valid){setGateHtml('join');return null;}
    try{context=await getContext();}catch(e){saveSession(null);setGateHtml('join','Your saved access expired. Enter a new invite code.');return null;}
    if(!context?.profile){saveSession(null);setGateHtml('join','No club access was found for this device.');return null;}
    if(context.profile.role==='pending_parent'){setGateHtml('approval');return null;}
    if(context.profile.role==='revoked'){setGateHtml('revoked');return null;}
    if(context.profile.role==='pending'){saveSession(null);setGateHtml('join','Enter a current invite code to join a team.');return null;}
    visibleTeams=await listTeams();
    activeTeam=chooseActiveTeam(options.localState||null);
    if(!activeTeam){setGateHtml('join','No team is available to this account.');return null;}
    hideGate();updateCloudPanel();
    return {configured:true,role:role(),profile:context.profile,club:context.club,team:oldShapeTeam(activeTeam),teams:visibleTeamList(),email:session?.user?.email||''};
  }

  async function loadInitialState(localState,seedFactory){
    if(!configured()||!activeTeam)return {state:localState,fromCloud:false};
    const row=await fetchTeamState(activeTeam.id);
    if(row?.state)return {state:row.state,fromCloud:true,revision:activeRevision};
    if(canEdit()){
      const seed=seedFactory?seedFactory(oldShapeTeam(activeTeam)):localState;
      activeRevision=-1;
      await saveTeamStateNow(seed);
      return {state:seed,fromCloud:false,created:true,revision:activeRevision};
    }
    return {state:localState,fromCloud:false};
  }
  function startPolling(){
    if(!configured()||!activeTeam)return;
    clearInterval(pollTimer);
    pollTimer=setInterval(()=>{if(document.visibilityState==='visible')pullLatest({quiet:true});},Math.max(30000,Number(cfg.syncIntervalMs||60000)));
    document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='visible')pullLatest({quiet:true});});
  }

  window.ValiantsCloud={
    configured,bootstrap,loadInitialState,queueStateSave,pullLatest,startPolling,
    role,canEdit,canAdmin,assignedTeam,currentTeam,visibleTeamList,createInvite,listTeamMembers,approveParent,removeTeamMember,syncTeamDirectory,switchAdminTeam,getClubOverview,signOut,handleAuthCallback,
    updateCloudPanel,
    get context(){return context;},get session(){return session;},get revision(){return activeRevision;}
  };
})();
