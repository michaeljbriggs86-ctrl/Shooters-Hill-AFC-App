-- Shooters Hill Team Tracker v2 cloud backend (Supabase/Postgres)
-- BEFORE RUNNING: change the bootstrap_admin_email value near the bottom.

create extension if not exists pgcrypto;

create table if not exists public.clubs (
  id uuid primary key default gen_random_uuid(),
  name text not null unique,
  selkent_club_url text,
  created_at timestamptz not null default now()
);

create table if not exists public.teams (
  id uuid primary key default gen_random_uuid(),
  club_id uuid not null references public.clubs(id) on delete cascade,
  name text not null,
  age_group integer not null check (age_group between 5 and 99),
  division text not null default '',
  season text not null default '2026/27',
  selkent_label text not null,
  league_name text not null,
  active boolean not null default true,
  created_at timestamptz not null default now(),
  unique (club_id, selkent_label)
);

create table if not exists public.profiles (
  user_id uuid primary key references auth.users(id) on delete cascade,
  club_id uuid references public.clubs(id) on delete cascade,
  team_id uuid references public.teams(id) on delete set null,
  full_name text not null default '',
  role text not null default 'pending' check (role in ('pending','club_admin','coach','parent')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.team_state (
  team_id uuid primary key references public.teams(id) on delete cascade,
  state jsonb not null default '{}'::jsonb,
  revision bigint not null default 0,
  updated_at timestamptz not null default now(),
  updated_by uuid references auth.users(id) on delete set null
);

create table if not exists public.invitations (
  id uuid primary key default gen_random_uuid(),
  club_id uuid not null references public.clubs(id) on delete cascade,
  team_id uuid not null references public.teams(id) on delete cascade,
  role text not null check (role in ('coach','parent')),
  label text not null default '',
  code_hash bytea not null unique,
  created_by uuid not null references auth.users(id) on delete cascade,
  created_at timestamptz not null default now(),
  expires_at timestamptz not null,
  used_at timestamptz,
  used_by uuid references auth.users(id) on delete set null
);

create table if not exists public.app_config (
  key text primary key,
  value jsonb not null
);

-- Helpers intentionally SECURITY DEFINER so RLS rules can ask one authoritative question.
create or replace function public.my_profile()
returns public.profiles
language sql stable security definer set search_path=public
as $$ select p from public.profiles p where p.user_id=auth.uid() $$;

create or replace function public.is_club_admin()
returns boolean
language sql stable security definer set search_path=public
as $$ select exists(select 1 from public.profiles p where p.user_id=auth.uid() and p.role='club_admin') $$;

create or replace function public.my_club_id()
returns uuid
language sql stable security definer set search_path=public
as $$ select p.club_id from public.profiles p where p.user_id=auth.uid() $$;

create or replace function public.my_team_id()
returns uuid
language sql stable security definer set search_path=public
as $$ select p.team_id from public.profiles p where p.user_id=auth.uid() $$;

create or replace function public.my_role()
returns text
language sql stable security definer set search_path=public
as $$ select p.role from public.profiles p where p.user_id=auth.uid() $$;

create or replace function public.can_read_team(p_team uuid)
returns boolean
language sql stable security definer set search_path=public
as $$
  select exists(
    select 1 from public.profiles p join public.teams t on t.id=p_team
    where p.user_id=auth.uid()
      and p.club_id=t.club_id
      and (p.role='club_admin' or (p.role in ('coach','parent') and p.team_id=p_team))
  )
$$;

create or replace function public.can_edit_team(p_team uuid)
returns boolean
language sql stable security definer set search_path=public
as $$
  select exists(
    select 1 from public.profiles p join public.teams t on t.id=p_team
    where p.user_id=auth.uid()
      and p.club_id=t.club_id
      and (p.role='club_admin' or (p.role='coach' and p.team_id=p_team))
  )
$$;

alter table public.clubs enable row level security;
alter table public.teams enable row level security;
alter table public.profiles enable row level security;
alter table public.team_state enable row level security;
alter table public.invitations enable row level security;
alter table public.app_config enable row level security;

-- Idempotent policy recreation.
do $$ begin
  drop policy if exists clubs_read on public.clubs;
  drop policy if exists teams_read on public.teams;
  drop policy if exists profiles_read on public.profiles;
  drop policy if exists team_state_read on public.team_state;
  drop policy if exists team_state_insert on public.team_state;
  drop policy if exists team_state_update on public.team_state;
  drop policy if exists team_state_delete on public.team_state;
  drop policy if exists invitations_admin on public.invitations;
exception when undefined_object then null; end $$;

create policy clubs_read on public.clubs for select to authenticated using (
  id=public.my_club_id()
);
create policy teams_read on public.teams for select to authenticated using (
  club_id=public.my_club_id() and (public.my_role()='club_admin' or id=public.my_team_id())
);
create policy profiles_read on public.profiles for select to authenticated using (
  user_id=auth.uid() or (public.my_role()='club_admin' and club_id=public.my_club_id())
);
create policy team_state_read on public.team_state for select to authenticated using (public.can_read_team(team_id));
create policy team_state_insert on public.team_state for insert to authenticated with check (public.can_edit_team(team_id));
create policy team_state_update on public.team_state for update to authenticated using (public.can_edit_team(team_id)) with check (public.can_edit_team(team_id));
create policy team_state_delete on public.team_state for delete to authenticated using (public.is_club_admin());
create policy invitations_admin on public.invitations for all to authenticated using (public.is_club_admin()) with check (public.is_club_admin());

-- New auth users get a pending profile. The bootstrap admin email is promoted automatically.
create or replace function public.handle_new_user()
returns trigger
language plpgsql security definer set search_path=public
as $$
declare v_club uuid; v_admin_email text;
begin
  select id into v_club from public.clubs order by created_at limit 1;
  select trim(both '"' from value::text) into v_admin_email from public.app_config where key='bootstrap_admin_email';
  insert into public.profiles(user_id,club_id,full_name,role)
  values(
    new.id,
    v_club,
    coalesce(nullif(new.raw_user_meta_data->>'full_name',''), split_part(coalesce(new.email,''),'@',1)),
    case when lower(coalesce(new.email,''))=lower(coalesce(v_admin_email,'')) then 'club_admin' else 'pending' end
  ) on conflict (user_id) do nothing;
  return new;
end $$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users for each row execute procedure public.handle_new_user();

create or replace function public.get_my_context()
returns jsonb
language plpgsql stable security definer set search_path=public
as $$
declare p public.profiles; t public.teams; c public.clubs;
begin
  select * into p from public.profiles where user_id=auth.uid();
  if p.user_id is null then return null; end if;
  if p.team_id is not null then select * into t from public.teams where id=p.team_id; end if;
  if p.club_id is not null then select * into c from public.clubs where id=p.club_id; end if;
  return jsonb_build_object(
    'profile',to_jsonb(p),
    'team',case when t.id is null then null else to_jsonb(t) end,
    'club',case when c.id is null then null else to_jsonb(c) end
  );
end $$;

grant execute on function public.get_my_context() to authenticated;

create or replace function public.create_invite(p_team_id uuid,p_role text,p_label text default '',p_expires_hours integer default 168)
returns table(code text, invitation_id uuid, expires_at timestamptz)
language plpgsql security definer set search_path=public
as $$
declare p public.profiles; t public.teams; v_code text; v_id uuid; v_exp timestamptz;
begin
  select * into p from public.profiles where user_id=auth.uid();
  if p.role<>'club_admin' then raise exception 'Club Admin access required'; end if;
  if p_role not in ('coach','parent') then raise exception 'Role must be coach or parent'; end if;
  select * into t from public.teams where id=p_team_id and club_id=p.club_id and active=true;
  if t.id is null then raise exception 'Team not available'; end if;
  v_code='SH-'||upper(substr(encode(gen_random_bytes(10),'hex'),1,16));
  v_exp=now()+make_interval(hours=>greatest(1,least(coalesce(p_expires_hours,168),720)));
  insert into public.invitations(club_id,team_id,role,label,code_hash,created_by,expires_at)
  values(p.club_id,t.id,p_role,coalesce(p_label,''),digest(v_code,'sha256'),auth.uid(),v_exp)
  returning id into v_id;
  return query select v_code,v_id,v_exp;
end $$;

grant execute on function public.create_invite(uuid,text,text,integer) to authenticated;

create or replace function public.claim_invite(p_code text)
returns jsonb
language plpgsql security definer set search_path=public
as $$
declare inv public.invitations; p public.profiles; t public.teams;
begin
  if auth.uid() is null then raise exception 'Sign in first'; end if;
  select * into inv from public.invitations
   where code_hash=digest(trim(p_code),'sha256') and used_at is null and expires_at>now()
   order by created_at desc limit 1 for update;
  if inv.id is null then raise exception 'Invite is invalid, expired, or already used'; end if;
  select * into p from public.profiles where user_id=auth.uid() for update;
  if p.user_id is null then raise exception 'No profile found'; end if;
  if p.role='club_admin' then raise exception 'Club Admin accounts cannot claim team invites'; end if;
  update public.profiles set club_id=inv.club_id,team_id=inv.team_id,role=inv.role,updated_at=now() where user_id=auth.uid();
  update public.invitations set used_at=now(),used_by=auth.uid() where id=inv.id;
  select * into t from public.teams where id=inv.team_id;
  return jsonb_build_object('role',inv.role,'team',to_jsonb(t));
end $$;

grant execute on function public.claim_invite(text) to authenticated;

create or replace function public.sync_team_directory(p_teams jsonb)
returns integer
language plpgsql security definer set search_path=public
as $$
declare p public.profiles; item jsonb; n integer:=0; age_n integer;
begin
  select * into p from public.profiles where user_id=auth.uid();
  if p.role<>'club_admin' then raise exception 'Club Admin access required'; end if;
  if jsonb_typeof(p_teams)<>'array' then raise exception 'Team directory must be an array'; end if;
  for item in select * from jsonb_array_elements(p_teams)
  loop
    age_n=coalesce((item->>'age_group')::integer,0);
    if age_n>0 and coalesce(item->>'name','')<>'' and coalesce(item->>'selkent_label','')<>'' and coalesce(item->>'league_name','')<>'' then
      insert into public.teams(club_id,name,age_group,selkent_label,league_name,season,active)
      values(p.club_id,item->>'name',age_n,item->>'selkent_label',item->>'league_name','2026/27',true)
      on conflict (club_id,selkent_label) do update set name=excluded.name,age_group=excluded.age_group,league_name=excluded.league_name,active=true;
      n=n+1;
    end if;
  end loop;
  return n;
end $$;

grant execute on function public.sync_team_directory(jsonb) to authenticated;
revoke all on function public.sync_team_directory(jsonb) from public, anon;

-- Revision-checked save prevents one coach from silently overwriting another coach's newer edit.
create or replace function public.save_team_state(p_team_id uuid,p_state jsonb,p_expected_revision bigint)
returns table(revision bigint, updated_at timestamptz)
language plpgsql security definer set search_path=public
as $$
declare current_rev bigint; new_rev bigint; stamp timestamptz;
begin
  if not public.can_edit_team(p_team_id) then raise exception 'You do not have edit access to this team'; end if;
  select ts.revision into current_rev from public.team_state ts where ts.team_id=p_team_id for update;
  if current_rev is null then
    if p_expected_revision not in (-1,-2) then raise exception 'STALE_STATE'; end if;
    insert into public.team_state(team_id,state,revision,updated_at,updated_by)
    values(p_team_id,p_state,0,now(),auth.uid())
    returning team_state.revision,team_state.updated_at into new_rev,stamp;
  else
    if p_expected_revision<>-2 and current_rev<>p_expected_revision then raise exception 'STALE_STATE'; end if;
    update public.team_state set state=p_state,revision=current_rev+1,updated_at=now(),updated_by=auth.uid()
    where team_id=p_team_id returning team_state.revision,team_state.updated_at into new_rev,stamp;
  end if;
  return query select new_rev,stamp;
end $$;

grant execute on function public.save_team_state(uuid,jsonb,bigint) to authenticated;


revoke all on function public.get_my_context() from public, anon;
revoke all on function public.create_invite(uuid,text,text,integer) from public, anon;
revoke all on function public.claim_invite(text) from public, anon;
revoke all on function public.save_team_state(uuid,jsonb,bigint) from public, anon;

-- Club and current Shooters Hill teams.
insert into public.clubs(name,selkent_club_url)
values('Shooters Hill Football Club','https://www.selkent.org.uk/public/clubs/499')
on conflict (name) do update set selkent_club_url=excluded.selkent_club_url;

with c as (select id from public.clubs where name='Shooters Hill Football Club')
insert into public.teams(club_id,name,age_group,selkent_label,league_name,season)
select c.id,v.name,v.age,v.label,v.league_name,'2026/27' from c cross join (values
 ('Cannons',8,'Under 8s Cannons','Shooters Hill AFC Cannons'),
 ('Green',8,'Under 8s Green','Shooters Hill AFC Green'),
 ('Gunners',9,'Under 9s Gunners','Shooters Hill AFC Gunners'),
 ('Valiants',9,'Under 9s Valiants','Shooters Hill AFC Valiants'),
 ('Royals',10,'Under 10s Royals','Shooters Hill AFC Royals'),
 ('Vikings',10,'Under 10s Vikings','Shooters Hill AFC Vikings'),
 ('Jaguars',11,'Under 11s Jaguars','Shooters Hill AFC Jaguars'),
 ('Archers',12,'Under 12s Archers','Shooters Hill AFC Archers'),
 ('Cannons',12,'Under 12s Cannons','Shooters Hill AFC Cannons'),
 ('Lions',12,'Under 12s Lions','Shooters Hill AFC Lions'),
 ('Vipers',13,'Under 13s Vipers','Shooters Hill AFC Vipers'),
 ('Lions',14,'Under 14s Lions','Shooters Hill AFC Lions'),
 ('Cannons',14,'Under 14s Cannons','Shooters Hill AFC Cannons'),
 ('Romans',15,'Under 15s Romans','Shooters Hill AFC Romans'),
 ('Cannons',15,'Under 15s Cannons','Shooters Hill AFC Cannons')
) as v(name,age,label,league_name)
on conflict (club_id,selkent_label) do update set name=excluded.name,age_group=excluded.age_group,league_name=excluded.league_name,active=true;

-- CHANGE THIS to the email address that should become the first Club Admin.
insert into public.app_config(key,value)
values('bootstrap_admin_email',to_jsonb('CHANGE_ME_TO_CLUB_ADMIN_EMAIL@example.com'::text))
on conflict (key) do update set value=excluded.value;

-- ---------------------------------------------------------------------------
-- v2.0.7 invite-only team access, parent approvals and server-side backups.
-- This block mirrors migrations/20260912_v207_invite_access.sql so that this
-- consolidated schema remains suitable for a fresh Supabase project.
-- ---------------------------------------------------------------------------
-- v2.0.7 access model: invite-only coach/parent devices, coach approval for parents,
-- parent removal, fixed invite generation, and server-side state revision backups.

alter table public.profiles drop constraint if exists profiles_role_check;
alter table public.profiles add constraint profiles_role_check
  check (role in ('pending','pending_parent','club_admin','coach','parent','revoked'));

alter table public.profiles add column if not exists access_method text not null default 'email';
alter table public.profiles add column if not exists approved_at timestamptz;
alter table public.profiles add column if not exists approved_by uuid references auth.users(id) on delete set null;
alter table public.profiles drop constraint if exists profiles_access_method_check;
alter table public.profiles add constraint profiles_access_method_check check (access_method in ('email','invite'));

update public.profiles
set approved_at=coalesce(approved_at,created_at)
where role in ('club_admin','coach','parent');

create table if not exists public.team_state_history (
  id bigint generated always as identity primary key,
  team_id uuid not null references public.teams(id) on delete cascade,
  revision bigint not null,
  state jsonb not null,
  archived_at timestamptz not null default now(),
  archived_by uuid references auth.users(id) on delete set null
);
create index if not exists team_state_history_team_revision_idx on public.team_state_history(team_id,revision desc);
alter table public.team_state_history enable row level security;
revoke all on public.team_state_history from anon, authenticated;

create index if not exists profiles_team_id_idx on public.profiles(team_id);
create index if not exists profiles_club_id_idx on public.profiles(club_id);
create index if not exists invitations_team_id_idx on public.invitations(team_id);
create index if not exists invitations_club_id_idx on public.invitations(club_id);

create or replace function public.create_invite(p_team_id uuid,p_role text,p_label text default '',p_expires_hours integer default 168)
returns table(code text, invitation_id uuid, expires_at timestamptz)
language plpgsql security definer set search_path=public,extensions
as $$
declare p public.profiles; t public.teams; v_code text; v_id uuid; v_exp timestamptz;
begin
  select * into p from public.profiles where user_id=auth.uid();
  if p.role not in ('club_admin','coach') then raise exception 'Coach or Club Admin access required'; end if;
  if p_role not in ('coach','parent') then raise exception 'Role must be coach or parent'; end if;
  if p.role='coach' and p_role<>'parent' then raise exception 'Coaches can only invite parents'; end if;
  select * into t from public.teams where id=p_team_id and club_id=p.club_id and active=true;
  if t.id is null then raise exception 'Team not available'; end if;
  if p.role='coach' and p.team_id<>t.id then raise exception 'Coaches can only invite parents to their own team'; end if;
  v_code='SH-'||upper(substr(replace(gen_random_uuid()::text,'-',''),1,12));
  v_exp=now()+make_interval(hours=>greatest(1,least(coalesce(p_expires_hours,168),720)));
  insert into public.invitations(club_id,team_id,role,label,code_hash,created_by,expires_at)
  values(p.club_id,t.id,p_role,coalesce(p_label,''),extensions.digest(v_code,'sha256'),auth.uid(),v_exp)
  returning id into v_id;
  return query select v_code,v_id,v_exp;
end $$;
grant execute on function public.create_invite(uuid,text,text,integer) to authenticated;
revoke all on function public.create_invite(uuid,text,text,integer) from public,anon;

create or replace function public.claim_invite(p_code text)
returns jsonb
language plpgsql security definer set search_path=public,extensions
as $$
declare inv public.invitations; p public.profiles; t public.teams; v_role text;
begin
  if auth.uid() is null then raise exception 'Sign in first'; end if;
  select * into inv from public.invitations
   where code_hash=extensions.digest(trim(p_code),'sha256') and used_at is null and expires_at>now()
   order by created_at desc limit 1 for update;
  if inv.id is null then raise exception 'Invite is invalid, expired, or already used'; end if;
  select * into p from public.profiles where user_id=auth.uid() for update;
  if p.user_id is null then raise exception 'No profile found'; end if;
  if p.role='club_admin' then raise exception 'Club Admin accounts cannot claim team invites'; end if;
  v_role=case when inv.role='parent' then 'pending_parent' else 'coach' end;
  update public.profiles set club_id=inv.club_id,team_id=inv.team_id,role=v_role,access_method='invite',
    approved_at=case when inv.role='coach' then now() else null end,
    approved_by=case when inv.role='coach' then inv.created_by else null end,
    updated_at=now() where user_id=auth.uid();
  update public.invitations set used_at=now(),used_by=auth.uid() where id=inv.id;
  select * into t from public.teams where id=inv.team_id;
  return jsonb_build_object('role',v_role,'team',to_jsonb(t),'approval_required',inv.role='parent');
end $$;
grant execute on function public.claim_invite(text) to authenticated;
revoke all on function public.claim_invite(text) from public,anon;

create or replace function public.claim_invite_for_device(p_code text,p_user_id uuid,p_full_name text)
returns jsonb
language plpgsql security definer set search_path=public,extensions
as $$
declare inv public.invitations; t public.teams; v_role text;
begin
  if p_user_id is null then raise exception 'Missing user'; end if;
  if length(trim(coalesce(p_full_name,'')))<2 then raise exception 'Enter your name'; end if;
  select * into inv from public.invitations
   where code_hash=extensions.digest(trim(p_code),'sha256') and used_at is null and expires_at>now()
   order by created_at desc limit 1 for update;
  if inv.id is null then raise exception 'Invite is invalid, expired, or already used'; end if;
  select * into t from public.teams where id=inv.team_id and active=true;
  if t.id is null then raise exception 'The invited team is no longer available'; end if;
  v_role=case when inv.role='parent' then 'pending_parent' else 'coach' end;
  update public.profiles
     set club_id=inv.club_id,team_id=inv.team_id,full_name=trim(p_full_name),role=v_role,access_method='invite',
         approved_at=case when inv.role='coach' then now() else null end,
         approved_by=case when inv.role='coach' then inv.created_by else null end,
         updated_at=now()
   where user_id=p_user_id;
  if not found then raise exception 'Profile was not created'; end if;
  update public.invitations set used_at=now(),used_by=p_user_id where id=inv.id;
  return jsonb_build_object('role',v_role,'team',to_jsonb(t),'approval_required',inv.role='parent');
end $$;
revoke all on function public.claim_invite_for_device(text,uuid,text) from public,anon,authenticated;
grant execute on function public.claim_invite_for_device(text,uuid,text) to service_role;

create or replace function public.list_team_members(p_team_id uuid default null)
returns table(user_id uuid,full_name text,role text,access_method text,created_at timestamptz,approved_at timestamptz)
language plpgsql stable security definer set search_path=public
as $$
declare me public.profiles; target_team uuid;
begin
  select * into me from public.profiles where profiles.user_id=auth.uid();
  if me.role not in ('club_admin','coach') then raise exception 'Coach or Club Admin access required'; end if;
  target_team=coalesce(p_team_id,me.team_id);
  if target_team is null then raise exception 'Choose a team'; end if;
  if me.role='coach' and target_team<>me.team_id then raise exception 'You can only manage your own team'; end if;
  if not exists(select 1 from public.teams t where t.id=target_team and t.club_id=me.club_id) then raise exception 'Team not available'; end if;
  return query
    select p.user_id,p.full_name,p.role,p.access_method,p.created_at,p.approved_at
    from public.profiles p
    where p.team_id=target_team and p.role in ('coach','parent','pending_parent')
    order by case p.role when 'pending_parent' then 0 when 'coach' then 1 else 2 end,p.full_name;
end $$;
grant execute on function public.list_team_members(uuid) to authenticated;
revoke all on function public.list_team_members(uuid) from public,anon;

create or replace function public.approve_parent(p_user_id uuid)
returns boolean
language plpgsql security definer set search_path=public
as $$
declare me public.profiles; target public.profiles;
begin
  select * into me from public.profiles where profiles.user_id=auth.uid();
  if me.role not in ('club_admin','coach') then raise exception 'Coach or Club Admin access required'; end if;
  select * into target from public.profiles where profiles.user_id=p_user_id for update;
  if target.user_id is null or target.role<>'pending_parent' then raise exception 'Pending parent not found'; end if;
  if target.club_id<>me.club_id then raise exception 'Parent belongs to another club'; end if;
  if me.role='coach' and target.team_id<>me.team_id then raise exception 'You can only approve parents for your own team'; end if;
  update public.profiles set role='parent',approved_at=now(),approved_by=auth.uid(),updated_at=now() where user_id=p_user_id;
  return true;
end $$;
grant execute on function public.approve_parent(uuid) to authenticated;
revoke all on function public.approve_parent(uuid) from public,anon;

create or replace function public.remove_team_member(p_user_id uuid)
returns boolean
language plpgsql security definer set search_path=public
as $$
declare me public.profiles; target public.profiles;
begin
  select * into me from public.profiles where profiles.user_id=auth.uid();
  if me.role not in ('club_admin','coach') then raise exception 'Coach or Club Admin access required'; end if;
  select * into target from public.profiles where profiles.user_id=p_user_id for update;
  if target.user_id is null then raise exception 'Member not found'; end if;
  if target.club_id<>me.club_id then raise exception 'Member belongs to another club'; end if;
  if me.role='coach' then
    if target.team_id<>me.team_id or target.role not in ('parent','pending_parent') then raise exception 'Coaches can only remove parents from their own team'; end if;
  else
    if target.role not in ('coach','parent','pending_parent') then raise exception 'This account cannot be removed here'; end if;
  end if;
  update public.profiles set role='revoked',team_id=null,approved_at=null,approved_by=null,updated_at=now() where user_id=p_user_id;
  return true;
end $$;
grant execute on function public.remove_team_member(uuid) to authenticated;
revoke all on function public.remove_team_member(uuid) from public,anon;

create or replace function public.save_team_state(p_team_id uuid,p_state jsonb,p_expected_revision bigint)
returns table(revision bigint, updated_at timestamptz)
language plpgsql security definer set search_path=public
as $$
declare current_rev bigint; current_state jsonb; new_rev bigint; stamp timestamptz;
begin
  if not public.can_edit_team(p_team_id) then raise exception 'You do not have edit access to this team'; end if;
  select ts.revision,ts.state into current_rev,current_state from public.team_state ts where ts.team_id=p_team_id for update;
  if current_rev is null then
    if p_expected_revision not in (-1,-2) then raise exception 'STALE_STATE'; end if;
    insert into public.team_state(team_id,state,revision,updated_at,updated_by)
    values(p_team_id,p_state,0,now(),auth.uid())
    returning team_state.revision,team_state.updated_at into new_rev,stamp;
  else
    if p_expected_revision<>-2 and current_rev<>p_expected_revision then raise exception 'STALE_STATE'; end if;
    insert into public.team_state_history(team_id,revision,state,archived_at,archived_by)
    values(p_team_id,current_rev,current_state,now(),auth.uid());
    update public.team_state set state=p_state,revision=current_rev+1,updated_at=now(),updated_by=auth.uid()
    where team_id=p_team_id returning team_state.revision,team_state.updated_at into new_rev,stamp;
    delete from public.team_state_history h where h.team_id=p_team_id and h.id not in
      (select id from public.team_state_history where team_id=p_team_id order by revision desc,id desc limit 50);
  end if;
  return query select new_rev,stamp;
end $$;
grant execute on function public.save_team_state(uuid,jsonb,bigint) to authenticated;
revoke all on function public.save_team_state(uuid,jsonb,bigint) from public,anon;

create or replace function public.can_read_team(p_team uuid)
returns boolean
language sql stable security definer set search_path=public
as $$
  select exists(
    select 1 from public.profiles p join public.teams t on t.id=p_team
    where p.user_id=auth.uid()
      and p.club_id=t.club_id
      and (p.role='club_admin' or (p.role in ('coach','parent') and p.team_id=p_team))
  )
$$;

revoke execute on function public.my_profile() from anon,public;
revoke execute on function public.is_club_admin() from anon,public;
revoke execute on function public.my_club_id() from anon,public;
revoke execute on function public.my_team_id() from anon,public;
revoke execute on function public.my_role() from anon,public;
revoke execute on function public.can_read_team(uuid) from anon,public;
revoke execute on function public.can_edit_team(uuid) from anon,public;
revoke execute on function public.handle_new_user() from anon,authenticated,public;
