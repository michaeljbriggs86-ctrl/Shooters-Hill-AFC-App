(function(){
  'use strict';

  const cfg = window.VALIANTS_CLOUD || {};
  const SESSION_KEY = 'shooters_hill_cloud_session_v2';
  const INVITE_KEY = 'shooters_hill_pending_invite_v2';
  const ACTIVE_TEAM_KEY = 'shooters_hill_admin_active_team_v2';
  let session = null;
  let context = null;
  let visibleTeams = [];
  let activeTeam = null;
  let activeRevision = -1;
  let lastRemoteUpdatedAt = '';
  let saveTimer = null;
  let saving = false;
  let pendingState = null;
  let pollTimer = null;
  let hooks = {};

  function configured(){
    return cfg.enabled !== false && /^https:\/\/.+\.supabase\.co$/i.test(String(cfg.url||'')) &&
      String(cfg.anonKey||'').length > 40 && !String(cfg.anonKey).includes('YOUR-');
  }
  function base(){ return String(cfg.url||'').replace(/\/$/,''); }
  function emitStatus(text, type='info'){
    const el=document.getElementById('cloud-sync-status');
    if(el){el.textContent=text;el.dataset.state=type;}
    window.dispatchEvent(new CustomEvent('valiants-cloud-status',{detail:{text,type}}));
  }
  function saveSession(s){
    session=s||null;
    if(session) localStorage.setItem(SESSION_KEY,JSON.stringify(session));
    else localStorage.removeItem(SESSION_KEY);
  }
  function loadSession(){
    try{return JSON.parse(localStorage.getItem(SESSION_KEY)||'null');}catch{return null;}
  }
  function authHeaders(accessToken){
    const h={'apikey':cfg.anonKey,'Content-Type':'application/json'};
    if(accessToken)h['Authorization']='Bearer '+accessToken;
    return h;
  }
  async function request(path,{method='GET',body=null,token=true,headers={}}={}){
    const res=await fetch(base()+path,{method,headers:{...authHeaders(token?session?.access_token:null),...headers},body:body==null?undefined:JSON.stringify(body)});
    const text=await res.text();
    let data=null;try{data=text?JSON.parse(text):null;}catch{data=text;}
    if(!res.ok){
      const msg=(data&&typeof data==='object'&&(data.msg||data.message||data.error_description||data.hint||data.details||data.error))||text||('HTTP '+res.status);
      const err=new Error(msg);err.status=res.status;err.data=data;throw err;
    }
    return {data,headers:res.headers,status:res.status};
  }
  async function refreshSession(){
    if(!session?.refresh_token)return false;
    try{
      const res=await fetch(base()+'/auth/v1/token?grant_type=refresh_token',{method:'POST',headers:authHeaders(),body:JSON.stringify({refresh_token:session.refresh_token})});
      const data=await res.json();
      if(!res.ok||!data.access_token)throw new Error(data?.msg||data?.error_description||'Session refresh failed');
      data.expires_at=Math.floor(Date.now()/1000)+(data.expires_in||3600);
      saveSession(data);return true;
    }catch{saveSession(null);return false;}
  }
  async function ensureFreshSession(){
    session=loadSession();
    if(!session?.access_token)return false;
    const exp=Number(session.expires_at||0);
    if(!exp||exp < Math.floor(Date.now()/1000)+90)return await refreshSession();
    return true;
  }
  async function signIn(email,password){
    const res=await fetch(base()+'/auth/v1/token?grant_type=password',{method:'POST',headers:authHeaders(),body:JSON.stringify({email,password})});
    const data=await res.json();
    if(!res.ok)throw new Error(data?.error_description||data?.msg||data?.message||'Sign in failed');
    data.expires_at=Math.floor(Date.now()/1000)+(data.expires_in||3600);saveSession(data);return data;
  }
  async function signUp(email,password,fullName,inviteCode){
    const res=await fetch(base()+'/auth/v1/signup',{method:'POST',headers:authHeaders(),body:JSON.stringify({email,password,data:{full_name:fullName||''}})});
    const data=await res.json();
    if(!res.ok)throw new Error(data?.msg||data?.message||data?.error_description||'Account creation failed');
    if(inviteCode)localStorage.setItem(INVITE_KEY,inviteCode.trim());
    if(data?.access_token){data.expires_at=Math.floor(Date.now()/1000)+(data.expires_in||3600);saveSession(data);}
    return data;
  }
  async function rpc(name,args={}){
    const {data}=await request('/rest/v1/rpc/'+encodeURIComponent(name),{method:'POST',body:args});return data;
  }
  async function getContext(){
    let data=await rpc('get_my_context',{});
    if(Array.isArray(data)&&data.length===1)data=data[0];
    if(data&&data.context)data=data.context;
    return data;
  }
  async function claimInvite(code){return await rpc('claim_invite',{p_code:String(code||'').trim()});}
  async function listTeams(){
    const {data}=await request('/rest/v1/teams?select=id,club_id,name,age_group,division,season,selkent_label,league_name,active&active=eq.true&order=age_group.asc,name.asc');
    return Array.isArray(data)?data:[];
  }
  function oldShapeTeam(t){
    if(!t)return null;
    const age = typeof t.age_group==='number'?'U'+t.age_group:String(t.age_group||'');
    return {id:t.id,selkentName:t.selkent_label||t.name,teamName:t.name,ageGroup:age,leagueName:t.league_name||t.name,division:t.division||'',season:t.season||''};
  }
  function role(){
    const r=context?.profile?.role||context?.role||'pending';
    return r==='club_admin'?'admin':r;
  }
  function assignedTeam(){
    const t=context?.team||null;return oldShapeTeam(t);
  }
  function canEdit(){return ['admin','coach'].includes(role());}
  function canAdmin(){return role()==='admin';}
  function teamMatchesState(team,state){
    const stateName=String(state?.division?.teamName||state?.meta?.teamName||'').toLowerCase().replace(/[^a-z0-9]+/g,' ').trim();
    const teamName=String(team?.league_name||team?.name||'').toLowerCase().replace(/[^a-z0-9]+/g,' ').trim();
    return stateName && teamName && (stateName===teamName || stateName.includes(teamName) || teamName.includes(stateName));
  }
  function chooseActiveTeam(localState){
    if(!visibleTeams.length)return null;
    const own=context?.team;
    if(own)return visibleTeams.find(t=>t.id===own.id)||own;
    const stored=localStorage.getItem(ACTIVE_TEAM_KEY);
    let found=visibleTeams.find(t=>t.id===stored);
    if(!found)found=visibleTeams.find(t=>teamMatchesState(t,localState));
    if(!found)found=visibleTeams[0];
    localStorage.setItem(ACTIVE_TEAM_KEY,found.id);return found;
  }
  async function fetchTeamState(teamId){
    const {data}=await request('/rest/v1/team_state?team_id=eq.'+encodeURIComponent(teamId)+'&select=state,revision,updated_at&limit=1');
    const row=Array.isArray(data)?data[0]:null;
    if(row){activeRevision=Number(row.revision||0);lastRemoteUpdatedAt=row.updated_at||'';}
    else{activeRevision=-1;lastRemoteUpdatedAt='';}
    return row||null;
  }
  async function saveTeamStateNow(nextState,{force=false}={}){
    if(!configured()||!session||!activeTeam||!canEdit())return null;
    if(saving){pendingState=nextState;return null;}
    saving=true;emitStatus('Saving…','working');
    try{
      const data=await rpc('save_team_state',{p_team_id:activeTeam.id,p_state:nextState,p_expected_revision:force?-2:activeRevision});
      const row=Array.isArray(data)?data[0]:data;
      if(row){activeRevision=Number(row.revision);lastRemoteUpdatedAt=row.updated_at||lastRemoteUpdatedAt;}
      emitStatus('Cloud synced','ok');return row;
    }catch(err){
      if(String(err.message||'').includes('STALE_STATE')){
        emitStatus('Newer cloud changes found — reloading','warn');
        const row=await fetchTeamState(activeTeam.id);
        if(row?.state&&hooks.onRemoteState)hooks.onRemoteState(row.state,{reason:'conflict'});
      }else emitStatus('Sync failed: '+(err.message||err),'error');
      throw err;
    }finally{
      saving=false;
      if(pendingState){const p=pendingState;pendingState=null;setTimeout(()=>saveTeamStateNow(p).catch(()=>{}),50);}
    }
  }
  function queueStateSave(nextState){
    if(!configured()||!canEdit()||!activeTeam)return;
    pendingState=JSON.parse(JSON.stringify(nextState));
    clearTimeout(saveTimer);
    saveTimer=setTimeout(()=>{const p=pendingState;pendingState=null;if(p)saveTeamStateNow(p).catch(()=>{});},700);
  }
  async function pullLatest({quiet=false}={}){
    if(!configured()||!session||!activeTeam)return null;
    if(!quiet)emitStatus('Checking cloud…','working');
    try{
      const before=activeRevision;
      const row=await fetchTeamState(activeTeam.id);
      if(row?.state&&Number(row.revision)!==before&&hooks.onRemoteState){hooks.onRemoteState(row.state,{reason:'pull'});}
      if(!quiet)emitStatus('Cloud synced','ok');
      return row;
    }catch(err){if(!quiet)emitStatus('Sync failed: '+(err.message||err),'error');return null;}
  }
  async function switchAdminTeam(teamId,seedFactory){
    if(!canAdmin())throw new Error('Club Admin access required');
    const team=visibleTeams.find(t=>t.id===teamId);if(!team)throw new Error('Team not found');
    if(pendingState&&canEdit()){const p=pendingState;pendingState=null;await saveTeamStateNow(p).catch(()=>{});}
    activeTeam=team;localStorage.setItem(ACTIVE_TEAM_KEY,team.id);
    const row=await fetchTeamState(team.id);
    if(row?.state){hooks.onRemoteState&&hooks.onRemoteState(row.state,{reason:'switch'});}
    else if(seedFactory){
      const seed=seedFactory(oldShapeTeam(team));
      activeRevision=-1;
      await saveTeamStateNow(seed);
      hooks.onRemoteState&&hooks.onRemoteState(seed,{reason:'switch-seed'});
    }
    updateCloudPanel();return oldShapeTeam(team);
  }
  async function createInvite({teamId,role:inviteRole,label,expiresHours=168}){
    if(!canAdmin())throw new Error('Club Admin access required');
    const data=await rpc('create_invite',{p_team_id:teamId,p_role:inviteRole,p_label:label||'',p_expires_hours:expiresHours});
    return Array.isArray(data)?data[0]:data;
  }
  async function syncTeamDirectory(teams){
    if(!canAdmin())return 0;
    const payload=(teams||[]).map(t=>({name:t.teamName,age_group:Number(String(t.ageGroup||'').replace(/\D/g,''))||0,selkent_label:t.selkentName,league_name:t.leagueName})).filter(t=>t.name&&t.age_group&&t.selkent_label&&t.league_name);
    if(!payload.length)return 0;
    const result=await rpc('sync_team_directory',{p_teams:payload});
    visibleTeams=await listTeams();
    return Number(result?.count??result??payload.length);
  }
  function visibleTeamList(){return visibleTeams.map(oldShapeTeam);}
  function currentTeam(){return oldShapeTeam(activeTeam);}

  function setGateHtml(mode='signin',message=''){
    const gate=document.getElementById('activation-gate');
    if(!gate)return;
    gate.classList.remove('hidden');
    document.body.classList.add('auth-open');
    document.querySelector('.app-shell')?.classList.add('account-locked');
    const pending=context?.profile?.role==='pending';
    if(pending||mode==='claim'){
      gate.innerHTML=`<div class="activation-card cloud-auth-card"><img src="club-logo.png" alt="Shooters Hill Football Club logo" class="activation-logo"/><p class="kicker">Account setup</p><h1>Join your team</h1><p class="muted">Enter the invite code supplied by your club administrator. Your team and access level are enforced by the cloud account.</p><label>Invite code<input id="cloud-invite-code" type="text" autocomplete="one-time-code" placeholder="SH-…" value="${escapeHtml(localStorage.getItem(INVITE_KEY)||'')}"/></label><p class="activation-error ${message?'':'hidden'}" id="cloud-auth-error">${escapeHtml(message)}</p><button class="primary-button large" id="cloud-claim-btn">Activate account</button><button class="text-button cloud-signout-pending" id="cloud-signout-btn">Sign out</button></div>`;
      document.getElementById('cloud-claim-btn')?.addEventListener('click',async()=>{
        const code=document.getElementById('cloud-invite-code')?.value?.trim();if(!code)return authError('Enter your invite code.');
        try{await claimInvite(code);localStorage.removeItem(INVITE_KEY);location.reload();}catch(e){authError(e.message||String(e));}
      });
      document.getElementById('cloud-signout-btn')?.addEventListener('click',signOut);
      return;
    }
    const signup=mode==='signup';
    gate.innerHTML=`<div class="activation-card cloud-auth-card"><img src="club-logo.png" alt="Shooters Hill Football Club logo" class="activation-logo"/><p class="kicker">Secure club account</p><h1>${signup?'Create account':'Sign in'}</h1><p class="muted">${signup?'Create your account, then your invite fixes it to one Shooters Hill team and role.':'Use the email and password for your club account.'}</p>${signup?'<label>Name<input id="cloud-name" type="text" autocomplete="name" placeholder="Your name"/></label>':''}<label>Email<input id="cloud-email" type="email" autocomplete="email"/></label><label>Password<input id="cloud-password" type="password" autocomplete="${signup?'new-password':'current-password'}"/></label>${signup?'<label>Invite code<input id="cloud-signup-invite" type="text" autocomplete="one-time-code" placeholder="SH-…"/></label>':''}<p class="activation-error ${message?'':'hidden'}" id="cloud-auth-error">${escapeHtml(message)}</p><button class="primary-button large" id="cloud-auth-submit">${signup?'Create account':'Sign in'}</button><button class="text-button cloud-auth-switch" id="cloud-auth-switch">${signup?'I already have an account':'Create an account'}</button></div>`;
    document.getElementById('cloud-auth-switch')?.addEventListener('click',()=>setGateHtml(signup?'signin':'signup'));
    document.getElementById('cloud-auth-submit')?.addEventListener('click',async()=>{
      const email=document.getElementById('cloud-email')?.value?.trim();const password=document.getElementById('cloud-password')?.value||'';
      if(!email||!password)return authError('Enter your email and password.');
      try{
        if(signup){
          const name=document.getElementById('cloud-name')?.value?.trim()||'';const invite=document.getElementById('cloud-signup-invite')?.value?.trim()||'';
          const data=await signUp(email,password,name,invite);
          if(data?.access_token){location.reload();return;}
          setGateHtml('signin','Account created. Check your email to confirm it, then sign in.');
        }else{await signIn(email,password);location.reload();}
      }catch(e){authError(e.message||String(e));}
    });
  }
  function escapeHtml(s=''){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
  function authError(msg){const el=document.getElementById('cloud-auth-error');if(el){el.textContent=msg;el.classList.remove('hidden');}}
  function hideGate(){document.getElementById('activation-gate')?.classList.add('hidden');document.body.classList.remove('auth-open');document.querySelector('.app-shell')?.classList.remove('account-locked');}
  function signOut(){saveSession(null);context=null;visibleTeams=[];activeTeam=null;localStorage.removeItem(INVITE_KEY);location.reload();}

  function updateCloudPanel(){
    const panel=document.getElementById('access-panel');if(!panel||!configured()||!context)return;
    panel.classList.add('cloud-access-panel');
    const profile=context.profile||{};const t=currentTeam();
    const summary=document.getElementById('access-summary');
    if(summary)summary.textContent=`${profile.full_name||session?.user?.email||'Account'} · ${role()==='admin'?'Club Admin':role()==='coach'?'Coach':'Parent'}${t?' · '+t.ageGroup+' '+t.teamName:''}. Team access is enforced by the server.`;
    let controls=document.getElementById('cloud-account-controls');
    if(!controls){controls=document.createElement('div');controls.id='cloud-account-controls';controls.className='cloud-account-controls';panel.appendChild(controls);}
    controls.innerHTML=`<div class="cloud-account-row"><span><strong>${escapeHtml(session?.user?.email||'')}</strong><small id="cloud-sync-status">Cloud connected</small></span><div class="cloud-account-actions"><button class="secondary-button compact" id="cloud-sync-now">Sync now</button><button class="text-button" id="cloud-signout-settings">Sign out</button></div></div>`;
    document.getElementById('cloud-sync-now')?.addEventListener('click',()=>pullLatest({quiet:false}));
    document.getElementById('cloud-signout-settings')?.addEventListener('click',signOut);
    const adminPanel=document.getElementById('admin-assignment-panel');
    if(adminPanel&&canAdmin()){
      const h=adminPanel.querySelector('h3');if(h)h.textContent='Invite Coach or Parent';
      const p=adminPanel.querySelector('.muted');if(p)p.textContent='Create a one-time account invite. When it is claimed, the server permanently assigns that account to the selected team and role.';
      const btn=document.getElementById('generate-assignment-code');if(btn)btn.textContent='Generate account invite';
      const note=adminPanel.querySelector('.settings-note');if(note)note.textContent='Each code can be used once. Team and role permissions are checked by the cloud database, not by the APK.';
    }
    document.body.classList.add('cloud-enabled');
  }

  async function bootstrap(options={}){
    hooks=options||{};
    if(!configured()){
      document.body.classList.add('cloud-not-configured');
      return {configured:false};
    }
    document.body.classList.add('cloud-enabled');
    const valid=await ensureFreshSession();
    if(!valid){setGateHtml('signin');return null;}
    try{context=await getContext();}catch(e){saveSession(null);setGateHtml('signin','Your session expired. Sign in again.');return null;}
    if(!context?.profile){setGateHtml('signin','No club profile was found for this account.');return null;}
    if(context.profile.role==='pending'){
      const pending=localStorage.getItem(INVITE_KEY);
      if(pending){try{await claimInvite(pending);localStorage.removeItem(INVITE_KEY);context=await getContext();}catch{} }
      if(context.profile.role==='pending'){setGateHtml('claim');return null;}
    }
    visibleTeams=await listTeams();
    activeTeam=chooseActiveTeam(options.localState||null);
    if(!activeTeam){setGateHtml('signin','No team is available to this account.');return null;}
    hideGate();
    updateCloudPanel();
    return {configured:true,role:role(),profile:context.profile,club:context.club,team:oldShapeTeam(activeTeam),teams:visibleTeamList(),email:session?.user?.email||''};
  }
  async function loadInitialState(localState,seedFactory){
    if(!configured()||!activeTeam)return {state:localState,fromCloud:false};
    const row=await fetchTeamState(activeTeam.id);
    if(row?.state)return {state:row.state,fromCloud:true,revision:activeRevision};
    if(canEdit()){
      const seed=seedFactory?seedFactory(oldShapeTeam(activeTeam)):localState;
      activeRevision=-1;
      await saveTeamStateNow(seed);
      return {state:seed,fromCloud:false,created:true,revision:activeRevision};
    }
    return {state:localState,fromCloud:false};
  }
  function startPolling(){
    if(!configured()||!activeTeam)return;
    clearInterval(pollTimer);
    pollTimer=setInterval(()=>{if(document.visibilityState==='visible')pullLatest({quiet:true});},Math.max(30000,Number(cfg.syncIntervalMs||60000)));
    document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='visible')pullLatest({quiet:true});});
  }

  window.ValiantsCloud={
    configured,bootstrap,loadInitialState,queueStateSave,pullLatest,startPolling,
    role,canEdit,canAdmin,assignedTeam,currentTeam,visibleTeamList,createInvite,syncTeamDirectory,switchAdminTeam,signOut,
    updateCloudPanel,
    get context(){return context;},get session(){return session;},get revision(){return activeRevision;}
  };
})();
