package com.shootershill.valiants;

import android.app.Activity;
import android.os.Bundle;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.content.Intent;
import android.net.Uri;
import java.net.URLEncoder;
import android.webkit.JavascriptInterface;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.view.WindowInsets;
import android.view.View;

import org.json.JSONObject;
import org.json.JSONArray;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private WebView webView;
    private int systemBottomInset = 0;
    private int systemTopInset = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);

        // Android 15+ uses edge-to-edge layouts for target SDK 35. Instead of
        // padding the whole WebView (which does not reliably move CSS fixed
        // elements), expose the navigation-bar inset to CSS. The app's own
        // bottom navigation can then sit above the phone controls on every
        // device and still animate off-screen while scrolling.
        webView.setOnApplyWindowInsetsListener((View v, WindowInsets insets) -> {
            int bottom;
            int top;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                bottom = insets.getInsets(WindowInsets.Type.navigationBars()).bottom;
                top = insets.getInsets(WindowInsets.Type.statusBars()).top;
            } else {
                bottom = insets.getSystemWindowInsetBottom();
                top = insets.getSystemWindowInsetTop();
            }
            systemBottomInset = Math.max(0, bottom);
            systemTopInset = Math.max(0, top);
            v.setPadding(0, 0, 0, 0);
            applySystemInsetToPage();
            return insets;
        });
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setMediaPlaybackRequiresUserGesture(false);

        webView.addJavascriptInterface(new NativeBridge(), "ValiantsNative");
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                applySystemInsetToPage();
            }
        });
        webView.setWebChromeClient(new WebChromeClient());

        String startUrl = "file:///android_asset/index.html?build=cloud";
        Uri callback = getIntent() != null ? getIntent().getData() : null;
        if (callback != null) {
            try {
                startUrl += "&auth_callback=" + URLEncoder.encode(callback.toString(), "UTF-8");
            } catch (Exception ignored) {}
        }
        webView.loadUrl(startUrl);
        webView.requestApplyInsets();
    }

    private void applySystemInsetToPage() {
        if (webView == null) return;
        final int inset = systemBottomInset;
        final int topInset = systemTopInset;
        webView.post(() -> webView.evaluateJavascript(
            "document.documentElement.style.setProperty('--android-inset-bottom','" + inset + "px');" +
            "document.documentElement.style.setProperty('--android-inset-top','" + topInset + "px');" +
            "window.dispatchEvent(new CustomEvent('android-inset-change',{detail:{bottom:" + inset + ",top:" + topInset + "}}));",
            null));
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        Uri callback = intent != null ? intent.getData() : null;
        if (callback != null && webView != null) {
            final String uri = callback.toString();
            webView.post(() -> webView.evaluateJavascript(
                "if(window.ValiantsCloud&&window.ValiantsCloud.handleAuthCallback){window.ValiantsCloud.handleAuthCallback(" + JSONObject.quote(uri) + ");}", null));
        }
    }

    private class NativeBridge {
        @JavascriptInterface
        public void renderPage(String requestId, String url, String choicesJson) {
            runOnUiThread(() -> {
                final WebView renderer = new WebView(MainActivity.this);
                WebSettings rs = renderer.getSettings();
                rs.setJavaScriptEnabled(true);
                rs.setDomStorageEnabled(true);
                rs.setDatabaseEnabled(true);
                rs.setUserAgentString("Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/126 Mobile Safari/537.36 ShootersHillTracker/2.0.13");
                final Handler handler = new Handler(Looper.getMainLooper());
                final JSONArray choices;
                try { choices = new JSONArray(choicesJson == null ? "[]" : choicesJson); }
                catch (Exception ex) {
                    webView.evaluateJavascript("window.__nativeRenderResolve(" + JSONObject.quote(requestId) + ",0,''," + JSONObject.quote(ex.getMessage()) + ",'');", null);
                    renderer.destroy();
                    return;
                }
                final boolean[] started = {false};
                final int[] choiceIndex = {0};
                final int[] choiceRetries = {0};
                final boolean[] choiceMissing = {false};
                final String[] lastUrl = {url};
                final Runnable[] step = new Runnable[1];
                final Runnable finish = () -> {
                    if (renderer.getProgress() < 90) {
                        handler.postDelayed(() -> {
                            if (step[0] != null) step[0].run();
                        }, 500);
                        return;
                    }
                    renderer.evaluateJavascript("(function(){return document.documentElement?document.documentElement.outerHTML:'';})()", value -> {
                        String html = value == null ? "" : value;
                        try {
                            if (html.startsWith("\"") && html.endsWith("\"")) {
                                html = new JSONArray("[" + html + "]").getString(0);
                            }
                        } catch (Exception ignored) {}
                        final String finalHtml = html;
                        webView.post(() -> webView.evaluateJavascript(
                            "window.__nativeRenderResolve(" + JSONObject.quote(requestId) + "," + (choiceMissing[0] ? 422 : 200) + "," + JSONObject.quote(finalHtml) + "," + JSONObject.quote(choiceMissing[0] ? "Selkent selector not found" : "") + "," + JSONObject.quote(lastUrl[0] == null ? url : lastUrl[0]) + ");", null));
                        renderer.stopLoading();
                        renderer.destroy();
                    });
                };
                step[0] = () -> {
                    if (choiceIndex[0] >= choices.length()) {
                        handler.postDelayed(finish, 900);
                        return;
                    }
                    if (renderer.getProgress() < 85) { handler.postDelayed(step[0], 450); return; }
                    String choice = choices.optString(choiceIndex[0], "");
                    String js = "(function(choice){" +
                        "const n=s=>String(s||'').toLowerCase().replace(/&/g,'and').replace(/[^a-z0-9]+/g,' ').trim().replace(/\\s+/g,' ');" +
                        "const target=n(choice);const els=[...document.querySelectorAll('a,button,summary,[role=tab],[role=button],label,option')];" +
                        "let el=els.find(x=>n(x.textContent||x.value)===target)||els.find(x=>target.length>2&&n(x.textContent||x.value).includes(target));" +
                        "if(!el)return 'missing';" +
                        "if(el.tagName==='OPTION'){const sel=el.parentElement;sel.value=el.value;el.selected=true;sel.dispatchEvent(new Event('change',{bubbles:true}));sel.dispatchEvent(new Event('input',{bubbles:true}));return 'changed';}" +
                        "el.scrollIntoView({block:'center'});el.click();return 'clicked';" +
                        "})(" + JSONObject.quote(choice) + ")";
                    renderer.evaluateJavascript(js, result -> {
                        boolean missing = result != null && result.contains("missing");
                        if (missing && choiceRetries[0] < 3) {
                            choiceRetries[0]++;
                            handler.postDelayed(step[0], 1100);
                            return;
                        }
                        if (missing) choiceMissing[0] = true;
                        choiceRetries[0] = 0;
                        choiceIndex[0]++;
                        handler.postDelayed(step[0], 1700);
                    });
                };
                renderer.setWebViewClient(new WebViewClient() {
                    @Override public void onPageFinished(WebView view, String pageUrl) {
                        lastUrl[0] = pageUrl;
                        if (!started[0]) { started[0] = true; handler.postDelayed(step[0], 900); }
                    }
                    @Override public void onReceivedError(WebView view, android.webkit.WebResourceRequest request, android.webkit.WebResourceError error) {
                        if (request != null && request.isForMainFrame()) {
                            String msg = error == null ? "Rendered page failed" : String.valueOf(error.getDescription());
                            webView.post(() -> webView.evaluateJavascript("window.__nativeRenderResolve(" + JSONObject.quote(requestId) + ",0,''," + JSONObject.quote(msg) + "," + JSONObject.quote(lastUrl[0] == null ? url : lastUrl[0]) + ");", null));
                            renderer.destroy();
                        }
                    }
                });
                renderer.loadUrl(url);
                handler.postDelayed(() -> {
                    if (renderer.getProgress() < 100 && started[0]) finish.run();
                }, 30000);
            });
        }

        @JavascriptInterface
        public void request(String requestId, String url, String method, String body) {
            new Thread(() -> {
                int status = 0;
                String response = "";
                String error = "";
                HttpURLConnection connection = null;
                try {
                    URL target = new URL(url);
                    connection = (HttpURLConnection) target.openConnection();
                    connection.setConnectTimeout(15000);
                    connection.setReadTimeout(20000);
                    connection.setInstanceFollowRedirects(true);
                    connection.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/126 Mobile Safari/537.36 ShootersHillTracker/2.0.13");
                    connection.setRequestProperty("Accept", "text/html,application/xhtml+xml,application/json;q=0.9,*/*;q=0.8");
                    String cookies = CookieManager.getInstance().getCookie(url);
                    if (cookies != null && !cookies.isEmpty()) connection.setRequestProperty("Cookie", cookies);
                    String httpMethod = (method == null || method.isEmpty()) ? "GET" : method.toUpperCase();
                    connection.setRequestMethod(httpMethod);
                    if (!"GET".equals(httpMethod) && body != null && !body.isEmpty()) {
                        byte[] payload = body.getBytes(StandardCharsets.UTF_8);
                        connection.setDoOutput(true);
                        connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");
                        try (OutputStream os = connection.getOutputStream()) { os.write(payload); }
                    }
                    status = connection.getResponseCode();
                    java.util.List<String> setCookies = connection.getHeaderFields().get("Set-Cookie");
                    if (setCookies != null) for (String cookie : setCookies) CookieManager.getInstance().setCookie(url, cookie);
                    InputStream stream = status >= 400 ? connection.getErrorStream() : connection.getInputStream();
                    if (stream != null) {
                        StringBuilder sb = new StringBuilder();
                        try (BufferedReader reader = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8))) {
                            String line; while ((line = reader.readLine()) != null) sb.append(line).append('\n');
                        }
                        response = sb.toString();
                    }
                } catch (Exception ex) {
                    error = ex.getMessage() == null ? ex.toString() : ex.getMessage();
                } finally { if (connection != null) connection.disconnect(); }

                final int finalStatus = status; final String finalResponse = response; final String finalError = error;
                webView.post(() -> webView.evaluateJavascript(
                    "window.__nativeFetchResolve(" + JSONObject.quote(requestId) + "," + finalStatus + "," + JSONObject.quote(finalResponse) + "," + JSONObject.quote(finalError) + ");", null));
            }).start();
        }
    }

    private void performDefaultBack() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override
    public void onBackPressed() {
        if (webView == null) {
            super.onBackPressed();
            return;
        }
        // Give the web app first refusal so Android Back closes an open player,
        // match-detail or award dialog instead of re-focusing an invalid field.
        webView.evaluateJavascript(
            "(window.closeTopDialog && window.closeTopDialog()) === true",
            result -> {
                if ("true".equals(result)) return;
                performDefaultBack();
            });
    }
}
