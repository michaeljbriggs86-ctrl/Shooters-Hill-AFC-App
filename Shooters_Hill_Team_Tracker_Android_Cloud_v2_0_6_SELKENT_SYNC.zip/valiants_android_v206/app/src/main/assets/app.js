const STORAGE_KEY = 'shootersHillValiants_2026_27_v1';
const ROLE_KEY = 'shootersHillValiants_role_v3';
const ACCOUNT_KEY = 'shootersHillValiants_account_v1';
const BUILD_MODE = new URLSearchParams(location.search).get('build') || 'standard';
const IS_ADMIN_BUILD = BUILD_MODE === 'admin';
const IS_PARENT_BUILD = BUILD_MODE === 'parent';
const IS_COACH_BUILD = BUILD_MODE === 'coach';


const SHOOTERS_HILL_STARTER_TEAMS = [
  { selkentName:'Under 8s Cannons', ageGroup:'U8', teamName:'Cannons', leagueName:'Shooters Hill AFC Cannons' },
  { selkentName:'Under 8s Green', ageGroup:'U8', teamName:'Green', leagueName:'Shooters Hill AFC Green' },
  { selkentName:'Under 9s Gunners', ageGroup:'U9', teamName:'Gunners', leagueName:'Shooters Hill AFC Gunners' },
  { selkentName:'Under 9s Valiants', ageGroup:'U9', teamName:'Valiants', leagueName:'Shooters Hill AFC Valiants' },
  { selkentName:'Under 10s Royals', ageGroup:'U10', teamName:'Royals', leagueName:'Shooters Hill AFC Royals' },
  { selkentName:'Under 10s Vikings', ageGroup:'U10', teamName:'Vikings', leagueName:'Shooters Hill AFC Vikings' },
  { selkentName:'Under 11s Jaguars', ageGroup:'U11', teamName:'Jaguars', leagueName:'Shooters Hill AFC Jaguars' },
  { selkentName:'Under 12s Archers', ageGroup:'U12', teamName:'Archers', leagueName:'Shooters Hill AFC Archers' },
  { selkentName:'Under 12s Cannons', ageGroup:'U12', teamName:'Cannons', leagueName:'Shooters Hill AFC Cannons' },
  { selkentName:'Under 12s Lions', ageGroup:'U12', teamName:'Lions', leagueName:'Shooters Hill AFC Lions' },
  { selkentName:'Under 13s Vipers', ageGroup:'U13', teamName:'Vipers', leagueName:'Shooters Hill AFC Vipers' },
  { selkentName:'Under 14s Lions', ageGroup:'U14', teamName:'Lions', leagueName:'Shooters Hill AFC Lions' },
  { selkentName:'Under 14s Cannons', ageGroup:'U14', teamName:'Cannons', leagueName:'Shooters Hill AFC Cannons' },
  { selkentName:'Under 15s Romans', ageGroup:'U15', teamName:'Romans', leagueName:'Shooters Hill AFC Romans' },
  { selkentName:'Under 15s Cannons', ageGroup:'U15', teamName:'Cannons', leagueName:'Shooters Hill AFC Cannons' }
];

const STARTER_DATA = {
  meta: {
    clubName: 'Shooters Hill Football Club',
    teamName: 'Valiants',
    ageGroup: 'U9',
    season: '2026/27'
  },
  division: {
    name: 'Under 9D Navy',
    teamName: 'Shooters Hill AFC Valiants',
    meetingsPerOpponent: 2,
    teams: [
      'AFC Green Court Dukes',
      'Chislehurst Wanderers Panthers',
      'Dartford Royals Blue',
      'Erith Town Selkent',
      'Eversley Rangers Red',
      'Junior Reds Athletic',
      'Junior Reds Sabres',
      'Phoenix Sports Panthers',
      'Shooters Hill AFC Gunners',
      'Shooters Hill AFC Valiants',
      'Slade Green Knights',
      'Welling Sport'
    ]
  },
  squad: [
    { number: 1, name: 'Albie', status: 'active', role: 'goalkeeper' },
    { number: 4, name: 'Ronnie', status: 'active', role: 'outfield' },
    { number: 5, name: 'Aavi', status: 'active', role: 'outfield' },
    { number: 6, name: 'Lindi', status: 'active', role: 'outfield' },
    { number: 7, name: 'Bulut', status: 'active', role: 'outfield' },
    { number: 8, name: 'Wyatt', status: 'active', role: 'outfield' },
    { number: 9, name: 'Oscar', status: 'active', role: 'outfield' },
    { number: 10, name: 'Umut', status: 'active', role: 'outfield' }
  ],
  matches: [
    { id:'m1', date:'2026-08-31', competition:'Preseason Tournament', type:'Tournament', opponent:'Boca Polars', venue:'', duration:10, gf:2, ga:3, stage:'', notes:'Oscar scored 2.' },
    { id:'m2', date:'2026-08-31', competition:'Preseason Tournament', type:'Tournament', opponent:'Cray Wanderers Blue', venue:'', duration:10, gf:0, ga:6, stage:'', notes:'' },
    { id:'m3', date:'2026-08-31', competition:'Preseason Tournament', type:'Tournament', opponent:'SAS Barca', venue:'', duration:10, gf:0, ga:6, stage:'', notes:'' },
    { id:'m4', date:'2026-08-31', competition:'Preseason Tournament', type:'Tournament', opponent:'Hoo FC', venue:'', duration:10, gf:1, ga:2, stage:'Semi Final', notes:'Lindi scored.' },
    { id:'m5', date:'2026-09-06', competition:'Friendly', type:'Friendly', opponent:'Shooters Hill Cannons', venue:'H', duration:40, gf:8, ga:4, stage:'', notes:'PoTM: Ronnie.' }
  ],
  goals: [
    { id:'g1', matchId:'m1', player:'Oscar', goals:2 },
    { id:'g2', matchId:'m4', player:'Lindi', goals:1 },
    { id:'g3', matchId:'m5', player:'Oscar', goals:3 },
    { id:'g4', matchId:'m5', player:'Umut', goals:2 },
    { id:'g5', matchId:'m5', player:'Bulut', goals:2 },
    { id:'g6', matchId:'m5', player:'Wyatt', goals:1 }
  ],
  assists: [],
  bookings: [],
  features: { goals:true, assists:true, awards:true, bookings:true },
  leagueResults: [],
  selkent: {
    enabled: true,
    divisionsUrl: 'https://www.selkent.org.uk/public/divisions/all',
    fixturesUrl: 'https://www.selkent.org.uk/public/fixtures/all',
    resultsUrl: 'https://www.selkent.org.uk/public/results',
    clubUrl: 'https://www.selkent.org.uk/public/clubs/499',
    clubTeams: SHOOTERS_HILL_STARTER_TEAMS,
    lastClubSync: '',
    lastDivisionSync: '',
    lastTableSync: '',
    lastSync: '',
    status: '',
    fixtures: [],
    results: [],
    table: []
  },
  awards: [
    { id:'a1', date:'2026-08-31', event:'Preseason Tournament', type:'Tournament Manager PoTM', player:'Aavi', matchId:null, notes:'' },
    { id:'a2', date:'2026-08-31', event:'Preseason Tournament', type:'Tournament Parent PoTM', player:'Albie', matchId:null, notes:'' },
    { id:'a3', date:'2026-09-06', event:'Shooters Hill Cannons', type:'PoTM', player:'Ronnie', matchId:'m5', notes:'' }
  ]
};

function repairStateIdentity(input){
  const s=input||{};
  const a=String(s.meta?.ageGroup||'').match(/\d{1,2}/), d=String(s.division?.name||'').match(/(?:Under\s*|U\s*)(\d{1,2})/i);
  if(a&&d&&Number(a[0])!==Number(d[1])){
    s.division.name='';s.division.teams=[s.division.teamName].filter(Boolean);
    s.selkent=s.selkent||{};s.selkent.lastSync='';s.selkent.lastDivisionSync='';s.selkent.lastTableSync='';s.selkent.table=[];s.selkent.results=[];s.selkent.fixtures=[];s.selkent.status='Team age changed — Selkent Divisions will identify the correct division.';
  }
  return s;
}
let state = repairStateIdentity(loadState());
let account = loadAccount();
let currentView = 'home';
let currentRole = IS_ADMIN_BUILD || BUILD_MODE === 'standard' || BUILD_MODE === 'cloud' ? 'admin' : IS_PARENT_BUILD ? 'parent' : 'coach';
const CLOUD_MODE = !!window.ValiantsCloud?.configured?.();
let cloudBootContext = null;


function loadAccount(){
  try{
    const raw=localStorage.getItem(ACCOUNT_KEY);
    if(!raw)return null;
    const parsed=JSON.parse(raw);
    return parsed&&parsed.team&&parsed.role?parsed:null;
  }catch{return null;}
}
function saveAccount(value){ account=value||null; if(account)localStorage.setItem(ACCOUNT_KEY,JSON.stringify(account)); else localStorage.removeItem(ACCOUNT_KEY); }
function isAdmin(){ return CLOUD_MODE ? currentRole==='admin' : (IS_ADMIN_BUILD || BUILD_MODE === 'standard' || currentRole === 'admin'); }
function assignmentRequired(){ return CLOUD_MODE ? false : (IS_COACH_BUILD || IS_PARENT_BUILD); }
function assignedTeam(){ return CLOUD_MODE ? (window.ValiantsCloud?.assignedTeam?.()||null) : (account?.team||null); }
function isTeamLocked(){ return CLOUD_MODE ? (!isAdmin() && !!assignedTeam()) : (!isAdmin() && !!assignedTeam()); }
function roleLabel(){ return currentRole==='admin'?'Club Admin':currentRole==='parent'?'Parent':'Coach'; }
function b64urlEncodeText(text=''){
  const bytes=new TextEncoder().encode(text);let bin='';bytes.forEach(b=>bin+=String.fromCharCode(b));return btoa(bin).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'');
}
function b64urlDecodeText(input=''){
  let s=String(input).replace(/-/g,'+').replace(/_/g,'/');while(s.length%4)s+='=';const bin=atob(s);const bytes=Uint8Array.from(bin,c=>c.charCodeAt(0));return new TextDecoder().decode(bytes);
}
function nativeSignAssignment(payloadB64){
  try{ return window.ValiantsNative?.signAssignment ? String(window.ValiantsNative.signAssignment(payloadB64)||'') : ''; }catch{return '';}
}
function nativeVerifyAssignment(payloadB64,signature){
  try{ return !!(window.ValiantsNative?.verifyAssignment && window.ValiantsNative.verifyAssignment(payloadB64,signature)); }catch{return false;}
}
function teamIdentityMatches(team){
  if(!team)return false;
  return selkentNorm(state.division?.teamName||'')===selkentNorm(team.leagueName||'') && String(state.meta?.ageGroup||'')===String(team.ageGroup||'');
}
function blankStateForTeam(team){
  const starter=cloneStarter();
  return normalizeState({
    meta:{clubName:starter.meta.clubName,teamName:team.teamName,ageGroup:team.ageGroup,season:starter.meta.season},
    division:{name:team.division||'',teamName:team.leagueName,meetingsPerOpponent:2,teams:[team.leagueName]},
    squad:[],matches:[],goals:[],assists:[],bookings:[],features:{goals:true,assists:true,awards:true,bookings:true},leagueResults:[],awards:[],
    selkent:{...starter.selkent,clubTeams:Array.isArray(state?.selkent?.clubTeams)&&state.selkent.clubTeams.length?state.selkent.clubTeams:starter.selkent.clubTeams,status:'Team activated — sync Selkent to load league information.'}
  });
}
function enforceAssignedTeam(persist=false){
  const team=assignedTeam();if(!team)return;
  const oldSelf=state.division?.teamName||'';
  state.meta.teamName=team.teamName;
  state.meta.ageGroup=team.ageGroup;
  state.division.teamName=team.leagueName;
  if(!Array.isArray(state.division.teams))state.division.teams=[];
  const idx=state.division.teams.findIndex(t=>selkentNorm(t)===selkentNorm(oldSelf));
  if(idx>=0)state.division.teams[idx]=team.leagueName;
  if(!state.division.teams.some(t=>selkentNorm(t)===selkentNorm(team.leagueName)))state.division.teams.push(team.leagueName);
  if(persist)localStorage.setItem(STORAGE_KEY,JSON.stringify(state));
}
function updateActivationGate(){
  // Cloud authentication owns the opening screen. Do not let the legacy
  // device-activation logic reveal the dashboard underneath it.
  if(CLOUD_MODE)return;
  const gate=document.getElementById('activation-gate');
  const shell=document.querySelector('.app-shell');
  const needed=assignmentRequired()&&!account;
  if(gate)gate.classList.toggle('hidden',!needed);
  if(shell)shell.classList.toggle('account-locked',needed);
  const title=document.getElementById('activation-role-title');
  const copy=document.getElementById('activation-role-copy');
  if(title)title.textContent=IS_PARENT_BUILD?'Activate parent access':'Activate coach access';
  if(copy)copy.textContent=IS_PARENT_BUILD?'Paste the Parent access code supplied by your club administrator.':'Paste the Coach access code supplied by your club administrator.';
}
function decodeAssignmentToken(token=''){
  const parts=String(token).trim().split('.');
  if(parts.length!==3||parts[0]!=='VA1')throw new Error('That is not a valid Valiants access code.');
  const payloadB64=parts[1],signature=parts[2];
  const payload=JSON.parse(b64urlDecodeText(payloadB64));
  if(!payload?.team?.selkentName||!payload?.team?.ageGroup||!payload?.team?.teamName||!payload?.team?.leagueName)throw new Error('The access code is missing its team assignment.');
  if(!['coach','parent'].includes(payload.role))throw new Error('The access code has an invalid role.');
  return{payload,payloadB64,signature};
}
function activateAssignment(){
  const input=document.getElementById('activation-code');const feedback=document.getElementById('activation-error');
  try{
    const decoded=decodeAssignmentToken(input?.value||'');
    const expected=IS_PARENT_BUILD?'parent':IS_COACH_BUILD?'coach':decoded.payload.role;
    if(decoded.payload.role!==expected)throw new Error(`This code is for ${decoded.payload.role} access, not ${expected} access.`);
    const verified=nativeVerifyAssignment(decoded.payloadB64,decoded.signature);
    if(!verified)throw new Error('This access code could not be verified. Ask your club administrator for a new code.');
    const previousMatches=teamIdentityMatches(decoded.payload.team);
    saveAccount({...decoded.payload,token:String(input.value).trim()});
    currentRole=decoded.payload.role;
    if(!previousMatches)state=blankStateForTeam(decoded.payload.team);
    enforceAssignedTeam(true);
    if(feedback){feedback.textContent='';feedback.classList.add('hidden');}
    updateActivationGate();renderAll();navigate('home',false);toast(`${roleLabel()} access activated`);
    setTimeout(()=>syncSelkent(true),600);
  }catch(err){if(feedback){feedback.textContent=err.message||String(err);feedback.classList.remove('hidden');}}
}
function adminAssignmentTeam(){
  const select=document.getElementById('assignment-team');const key=select?.value||'';
  return clubTeams().find(t=>t.selkentName===key)||null;
}
function renderAssignmentTeamOptions(){
  const select=document.getElementById('assignment-team');if(!select)return;
  const list=clubTeams();const prev=select.value;
  select.innerHTML=list.map(t=>`<option value="${esc(t.selkentName)}">${esc(t.ageGroup+' '+t.teamName)}</option>`).join('');
  if(list.some(t=>t.selkentName===prev))select.value=prev;
  else{
    const cur=list.find(t=>t.ageGroup===state.meta.ageGroup&&selkentNorm(t.leagueName)===selkentNorm(state.division.teamName));
    if(cur)select.value=cur.selkentName;
  }
}
async function generateAssignmentCode(){
  if(!isAdmin()){toast('Club Admin access is required.');return;}
  if(CLOUD_MODE){
    const user=(document.getElementById('assignment-user')?.value||'').trim();
    const role=document.getElementById('assignment-role')?.value||'coach';
    const team=adminAssignmentTeam();
    if(!user){alert('Enter the coach or parent name.');return;}
    if(!team){alert('Choose a team.');return;}
    const cloudTeam=(window.ValiantsCloud?.visibleTeamList?.()||[]).find(t=>t.selkentName===team.selkentName||t.leagueName===team.leagueName);
    if(!cloudTeam){alert('That team is not available in the cloud database yet.');return;}
    try{
      const invite=await window.ValiantsCloud.createInvite({teamId:cloudTeam.id,role,label:user,expiresHours:168});
      const out=document.getElementById('assignment-code-output');if(out)out.value=invite?.code||invite?.invite_code||'';
      const meta=document.getElementById('assignment-code-meta');if(meta)meta.textContent=`${user} · ${role==='coach'?'Coach':'Parent'} · ${team.ageGroup} ${team.teamName} · expires in 7 days`;
      toast('Account invite created');
    }catch(err){alert('Could not create invite: '+(err.message||err));}
    return;
  }
  const user=(document.getElementById('assignment-user')?.value||'').trim();
  const role=document.getElementById('assignment-role')?.value||'coach';
  const team=adminAssignmentTeam();
  if(!user){alert('Enter the coach or parent name.');return;}
  if(!team){alert('Choose a team.');return;}
  const payload={v:1,user,role,team,issuedAt:new Date().toISOString(),nonce:uid('invite')};
  const payloadB64=b64urlEncodeText(JSON.stringify(payload));
  const signature=nativeSignAssignment(payloadB64);
  const out=document.getElementById('assignment-code-output');
  if(!signature){
    if(out)out.value='Access-code signing is available in the Club Admin Android app. Build/install the Club Admin APK to generate secure codes.';
    return;
  }
  if(out)out.value=`VA1.${payloadB64}.${signature}`;
  const meta=document.getElementById('assignment-code-meta');
  if(meta)meta.textContent=`${user} · ${role==='coach'?'Coach':'Parent'} · ${team.ageGroup} ${team.teamName}`;
}
async function copyAssignmentCode(){
  const out=document.getElementById('assignment-code-output');if(!out?.value)return;
  try{await navigator.clipboard.writeText(out.value);toast('Access code copied');}catch{out.select();document.execCommand('copy');toast('Access code copied');}
}

function cloneStarter(){ return JSON.parse(JSON.stringify(STARTER_DATA)); }
function normalizeState(data={}){
  const starter = cloneStarter();
  const oldMeta = data.meta || {};
  const rawSquad = Array.isArray(data.squad) ? data.squad : starter.squad;
  const squad = rawSquad
    .filter(p => p && String(p.name || '').trim())
    .map(p => ({
      number: Number(p.number) || 0,
      name: String(p.name || '').trim(),
      status: p.status === 'inactive' ? 'inactive' : 'active',
      role: p.role === 'goalkeeper' || (Number(p.number) === 1 && String(p.name || '').toLowerCase() === 'albie') ? 'goalkeeper' : 'outfield'
    }))
    .filter(p => p.number > 0);

  let legacyTeamName = oldMeta.teamName;
  if(!legacyTeamName && oldMeta.club){
    legacyTeamName = /valiants/i.test(oldMeta.club) ? 'Valiants' : oldMeta.club;
  }

  const d = data.division || {};
  return {
    meta: {
      clubName: oldMeta.clubName || starter.meta.clubName,
      teamName: legacyTeamName || starter.meta.teamName,
      ageGroup: oldMeta.ageGroup || oldMeta.age || starter.meta.ageGroup,
      season: oldMeta.season || starter.meta.season
    },
    division: {
      name: Object.prototype.hasOwnProperty.call(d,'name') ? String(d.name||'') : starter.division.name,
      teamName: Object.prototype.hasOwnProperty.call(d,'teamName') ? String(d.teamName||'') : starter.division.teamName,
      meetingsPerOpponent: Number(d.meetingsPerOpponent || starter.division.meetingsPerOpponent) || 2,
      teams: Array.isArray(d.teams) ? d.teams : starter.division.teams
    },
    squad: Array.isArray(data.squad) ? squad : starter.squad,
    matches: Array.isArray(data.matches) ? data.matches : starter.matches,
    goals: Array.isArray(data.goals) ? data.goals : starter.goals,
    assists: Array.isArray(data.assists) ? data.assists : [],
    bookings: Array.isArray(data.bookings) ? data.bookings : [],
    features: {
      goals: data.features?.goals !== false,
      assists: data.features?.assists !== false,
      awards: data.features?.awards !== false,
      bookings: data.features?.bookings !== false
    },
    leagueResults: Array.isArray(data.leagueResults) ? data.leagueResults.map(r=>({
      id:r.id||uid('lr'), date:r.date||'', home:String(r.home||'').trim(), away:String(r.away||'').trim(),
      homeGoals:Number(r.homeGoals||0), awayGoals:Number(r.awayGoals||0), source:r.source||'paste', raw:r.raw||''
    })).filter(r=>r.home&&r.away) : [],
    selkent: {
      enabled: data.selkent?.enabled !== false,
      divisionsUrl: data.selkent?.divisionsUrl || starter.selkent.divisionsUrl,
      fixturesUrl: data.selkent?.fixturesUrl || starter.selkent.fixturesUrl,
      resultsUrl: data.selkent?.resultsUrl || starter.selkent.resultsUrl,
      clubUrl: data.selkent?.clubUrl || starter.selkent.clubUrl,
      clubTeams: Array.isArray(data.selkent?.clubTeams) && data.selkent.clubTeams.length ? data.selkent.clubTeams : starter.selkent.clubTeams,
      lastClubSync: data.selkent?.lastClubSync || '',
      lastDivisionSync: data.selkent?.lastDivisionSync || '',
      lastTableSync: data.selkent?.lastTableSync || '',
      lastSync: data.selkent?.lastSync || '',
      status: data.selkent?.status || '',
      fixtures: Array.isArray(data.selkent?.fixtures) ? data.selkent.fixtures : [],
      results: Array.isArray(data.selkent?.results) ? data.selkent.results : [],
      table: Array.isArray(data.selkent?.table) ? data.selkent.table : []
    },
    awards: Array.isArray(data.awards) ? data.awards : starter.awards
  };
}
function loadState(){
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? normalizeState(JSON.parse(raw)) : cloneStarter();
  } catch { return cloneStarter(); }
}
function saveState(){ localStorage.setItem(STORAGE_KEY, JSON.stringify(state)); renderAll(); if(CLOUD_MODE)window.ValiantsCloud?.queueStateSave?.(state); }
function uid(prefix){ return prefix + Date.now().toString(36) + Math.random().toString(36).slice(2,7); }
function resultOf(m){ return Number(m.gf) > Number(m.ga) ? 'W' : Number(m.gf) < Number(m.ga) ? 'L' : 'D'; }
function formatDate(iso){ if(!iso) return ''; return new Intl.DateTimeFormat('en-GB',{day:'numeric',month:'short',year:'2-digit'}).format(new Date(iso+'T12:00:00')); }
function esc(str=''){ return String(str).replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c])); }
function activePlayers(){ return state.squad.filter(p=>p.status==='active' && p.name).sort((a,b)=>a.number-b.number); }
function rosterPlayers(){ return state.squad.filter(p=>p.name).sort((a,b)=>a.number-b.number); }
function shirtFor(name){ return state.squad.find(p=>p.name===name)?.number ?? ''; }
function isLeagueMatch(m){ return String(m.competition||'').trim().toLowerCase()==='league'; }
function isFriendlyMatch(m){ return String(m.competition||'').trim().toLowerCase()==='friendly'; }
function featureEnabled(name){ return state.features?.[name] !== false; }
function isSyncedMatch(m){ return String(m.source||'')==='selkent'; }
function otherMatches(){ return state.matches.filter(m=>!isLeagueMatch(m)&&!isFriendlyMatch(m)); }
function ageGroupNumber(){
  const source=`${state.meta.ageGroup||''} ${state.division.name||''}`;
  const m=source.match(/(?:\bU\s*|\bUnder\s*)(\d{1,2})\b/i);
  return m?Number(m[1]):0;
}
function leagueTableEnabled(){ return ageGroupNumber()>=11; }
function normalizeTeamKey(s=''){ return String(s).toLowerCase().replace(/&/g,'and').replace(/[^a-z0-9]+/g,' ').trim().replace(/\s+/g,' '); }
function allDivisionTeams(){
  const d=state.division||{};
  const raw=[...(Array.isArray(d.teams)?d.teams:[]),d.teamName].filter(Boolean);
  const out=[],seen=new Set();
  raw.forEach(t=>{ const name=String(t).trim(), key=normalizeTeamKey(name); if(name&&!seen.has(key)){seen.add(key);out.push(name);} });
  return out;
}
function canonicalTeam(candidate=''){
  const key=normalizeTeamKey(candidate);
  if(!key) return null;
  const teams=allDivisionTeams();
  let exact=teams.find(t=>normalizeTeamKey(t)===key); if(exact) return exact;
  if(key.length>=5){
    const fuzzy=teams.filter(t=>{const tk=normalizeTeamKey(t);return tk.includes(key)||key.includes(tk);});
    if(fuzzy.length===1) return fuzzy[0];
  }
  return null;
}
function ownLeagueResults(){
  const self=state.division.teamName||state.meta.teamName||'Our team';
  return state.matches.filter(isLeagueMatch).map(m=>{
    const away=String(m.venue||'').toUpperCase()==='A';
    return {id:'match:'+m.id,date:m.date||'',home:away?m.opponent:self,away:away?self:m.opponent,homeGoals:away?Number(m.ga||0):Number(m.gf||0),awayGoals:away?Number(m.gf||0):Number(m.ga||0),source:'match'};
  });
}
function leagueResultSignature(r){
  const a=normalizeTeamKey(r.home),b=normalizeTeamKey(r.away),hg=Number(r.homeGoals||0),ag=Number(r.awayGoals||0);
  // Direction matters so home/away return fixtures remain distinct.
  return `${a}|${hg}|${ag}|${b}`;
}
function combinedLeagueResults(){
  const own=ownLeagueResults();
  const seen=new Set(own.map(leagueResultSignature));
  const out=[...own];
  [...(state.leagueResults||[]),...(state.selkent?.results||[])].forEach(r=>{
    const sig=leagueResultSignature(r);
    if(!seen.has(sig)){ seen.add(sig); out.push(r); }
  });
  return out;
}
function calculateLeagueTable(){
  const rows=new Map();
  allDivisionTeams().forEach(name=>rows.set(normalizeTeamKey(name),{team:name,p:0,w:0,d:0,l:0,gf:0,ga:0,gd:0,pts:0}));
  combinedLeagueResults().forEach(r=>{
    const home=canonicalTeam(r.home),away=canonicalTeam(r.away);
    if(!home||!away||normalizeTeamKey(home)===normalizeTeamKey(away)) return;
    const h=rows.get(normalizeTeamKey(home)),a=rows.get(normalizeTeamKey(away));
    if(!h||!a) return;
    const hg=Number(r.homeGoals||0),ag=Number(r.awayGoals||0);
    h.p++;a.p++;h.gf+=hg;h.ga+=ag;a.gf+=ag;a.ga+=hg;
    if(hg>ag){h.w++;a.l++;h.pts+=3;} else if(hg<ag){a.w++;h.l++;a.pts+=3;} else {h.d++;a.d++;h.pts++;a.pts++;}
  });
  const table=[...rows.values()];
  table.forEach(r=>r.gd=r.gf-r.ga);
  table.sort((a,b)=>b.pts-a.pts||b.gd-a.gd||b.gf-a.gf||a.team.localeCompare(b.team));
  return table;
}
function parseResultDate(text){
  let m=String(text).match(/\b(20\d{2})[-/.](\d{1,2})[-/.](\d{1,2})\b/);
  if(m) return `${m[1]}-${String(m[2]).padStart(2,'0')}-${String(m[3]).padStart(2,'0')}`;
  m=String(text).match(/\b(\d{1,2})[/.](\d{1,2})[/.](\d{2,4})\b/);
  if(m){let y=Number(m[3]);if(y<100)y+=2000;return `${y}-${String(m[2]).padStart(2,'0')}-${String(m[1]).padStart(2,'0')}`;}
  return '';
}
function parseLeagueResultLine(raw){
  const original=String(raw||'').trim(); if(!original) return null;
  let text=original.replace(/^[•·*\-]+\s*/,'').replace(/\s+/g,' ').trim();
  const date=parseResultDate(text);
  const scoreText=text
    .replace(/\b20\d{2}[-/.]\d{1,2}[-/.]\d{1,2}\b/g,' ')
    .replace(/\b\d{1,2}[/.]\d{1,2}[/.]\d{2,4}\b/g,' ');
  const teams=allDivisionTeams().sort((a,b)=>b.length-a.length);
  const hits=[];
  teams.forEach(team=>{const idx=text.toLowerCase().indexOf(team.toLowerCase());if(idx>=0)hits.push({team,idx});});
  hits.sort((a,b)=>a.idx-b.idx);
  const score=scoreText.match(/\b(\d{1,2})\s*[-–—:]\s*(\d{1,2})\b/);
  if(hits.length>=2&&score){
    return {date,home:hits[0].team,away:hits[1].team,homeGoals:Number(score[1]),awayGoals:Number(score[2]),raw:original};
  }
  // Supports copied table rows such as Team A<TAB>3<TAB>1<TAB>Team B or Team A 3 1 Team B.
  const cells=original.split(/\t+/).map(x=>x.trim()).filter(Boolean);
  if(cells.length>=4){
    const nums=cells.map((c,i)=>/^\d{1,2}$/.test(c)?i:-1).filter(i=>i>=0);
    if(nums.length>=2){
      const h=canonicalTeam(cells.slice(0,nums[0]).join(' '));
      const a=canonicalTeam(cells.slice(nums[1]+1).join(' '));
      if(h&&a) return {date,home:h,away:a,homeGoals:Number(cells[nums[0]]),awayGoals:Number(cells[nums[1]]),raw:original};
    }
  }
  const loose=text.match(/^(.+?)\s+(\d{1,2})\s+(\d{1,2})\s+(.+?)$/);
  if(loose){
    const h=canonicalTeam(loose[1]),a=canonicalTeam(loose[4]);
    if(h&&a) return {date,home:h,away:a,homeGoals:Number(loose[2]),awayGoals:Number(loose[3]),raw:original};
  }
  return null;
}
function aggregateStats(a,b){
  const played=Number(a.played||0)+Number(b.played||0), wins=Number(a.wins||0)+Number(b.wins||0), draws=Number(a.draws||0)+Number(b.draws||0), losses=Number(a.losses||0)+Number(b.losses||0), gf=Number(a.gf||0)+Number(b.gf||0), ga=Number(a.ga||0)+Number(b.ga||0);
  return {played,wins,draws,losses,gf,ga,gd:gf-ga,winrate:played?Math.round(wins/played*100):0};
}
function remoteLeagueRow(){
  const self=normalizeTeamKey(state.division.teamName||state.meta.teamName||'');
  return (state.selkent?.table||[]).find(r=>normalizeTeamKey(r.team)===self)||null;
}
function remoteLeagueStats(){
  const r=remoteLeagueRow(); if(!r) return null;
  const played=Number(r.p||0),wins=Number(r.w||0),draws=Number(r.d||0),losses=Number(r.l||0),gf=Number(r.gf||0),ga=Number(r.ga||0);
  return {played,wins,draws,losses,gf,ga,gd:gf-ga,winrate:played?Math.round(wins/played*100):0};
}

const __nativePending=new Map();
window.__nativeFetchResolve=function(id,status,body,error){
  const pending=__nativePending.get(id); if(!pending) return;
  __nativePending.delete(id);
  if(status>=200&&status<400) pending.resolve({status,body}); else pending.reject(new Error(error||`HTTP ${status||0}`));
};
function nativeHttp(url,method='GET',body=''){
  if(window.ValiantsNative&&typeof window.ValiantsNative.request==='function'){
    return new Promise((resolve,reject)=>{
      const id='req_'+Date.now().toString(36)+Math.random().toString(36).slice(2,8);
      __nativePending.set(id,{resolve,reject});
      window.ValiantsNative.request(id,url,method,body||'');
      setTimeout(()=>{if(__nativePending.has(id)){__nativePending.delete(id);reject(new Error('Selkent request timed out'));}},25000);
    });
  }
  const opts={method,cache:'no-store',headers:{'Accept':'text/html,application/xhtml+xml'}};
  if(method!=='GET'&&body){opts.body=body;opts.headers['Content-Type']='application/x-www-form-urlencoded;charset=UTF-8';}
  return fetch(url,opts).then(async r=>{const text=await r.text();if(!r.ok)throw new Error(`HTTP ${r.status}`);return{status:r.status,body:text};});
}
function selkentNorm(s=''){return String(s).toLowerCase().replace(/&amp;/g,'and').replace(/&/g,'and').replace(/[^a-z0-9]+/g,' ').trim().replace(/\s+/g,' ');}
function resolveWebUrl(base,rel){try{return new URL(rel,base).href;}catch{return base;}}
function formPayload(form,chosenSelect,chosenOption,chosenButton){
  const params=new URLSearchParams();
  form.querySelectorAll('input,select,textarea').forEach(el=>{
    if(!el.name||el.disabled)return;
    if((el.type==='checkbox'||el.type==='radio')&&!el.checked)return;
    if(el.tagName==='SELECT'){
      const opt=el===chosenSelect?chosenOption:el.selectedOptions?.[0];
      if(opt) params.set(el.name,opt.value);
    } else if(el.type!=='submit'&&el.type!=='button') params.set(el.name,el.value||'');
  });
  if(chosenButton?.name) params.set(chosenButton.name,chosenButton.value||chosenButton.textContent.trim());
  return params.toString();
}
function navigationForChoice(html,currentUrl,choice){
  const doc=new DOMParser().parseFromString(html,'text/html');
  const target=selkentNorm(choice);
  const links=[...doc.querySelectorAll('a[href]')];
  const link=links.find(a=>{const t=selkentNorm(a.textContent);return t===target||(target.length>3&&t.includes(target));});
  if(link){const href=link.getAttribute('href')||'';if(href&&href!=='#'&&!href.toLowerCase().startsWith('javascript:'))return{url:resolveWebUrl(currentUrl,href),method:'GET',body:''};}
  for(const sel of doc.querySelectorAll('select')){
    const opts=[...sel.options];
    const opt=opts.find(o=>{const t=selkentNorm(o.textContent);return t===target||(target.length>3&&t.includes(target));});
    if(!opt)continue;
    if(opt.selected||sel.value===opt.value) return null;
    const form=sel.closest('form'); if(!form)continue;
    const method=(form.getAttribute('method')||'GET').toUpperCase();
    const action=resolveWebUrl(currentUrl,form.getAttribute('action')||currentUrl);
    const payload=formPayload(form,sel,opt,null);
    return method==='GET'?{url:action+(action.includes('?')?'&':'?')+payload,method:'GET',body:''}:{url:action,method,body:payload};
  }
  for(const btn of doc.querySelectorAll('button,input[type=submit]')){
    const text=selkentNorm(btn.textContent||btn.value||'');
    if(!(text===target||(target.length>3&&text.includes(target))))continue;
    const form=btn.closest('form');if(!form)continue;
    const method=(form.getAttribute('method')||'GET').toUpperCase(),action=resolveWebUrl(currentUrl,form.getAttribute('action')||currentUrl),payload=formPayload(form,null,null,btn);
    return method==='GET'?{url:action+(action.includes('?')?'&':'?')+payload,method:'GET',body:''}:{url:action,method,body:payload};
  }
  return null;
}
async function fetchSelkentSelected(baseUrl,choices=[]){
  let current=baseUrl;
  let response=await nativeHttp(current);
  let html=response.body;
  for(const choice of choices.filter(Boolean)){
    const nav=navigationForChoice(html,current,choice);
    if(nav){response=await nativeHttp(nav.url,nav.method,nav.body);html=response.body;current=nav.url;}
  }
  return{html,url:current};
}

function parseShootersHillClubTeams(html=''){
  const doc=new DOMParser().parseFromString(html,'text/html');
  const found=[];
  const seen=new Set();
  const addText=(txt='')=>{
    const t=String(txt).replace(/\s+/g,' ').trim();
    const m=t.match(/^Under\s+(\d{1,2})s?\s+(.+?)$/i);
    if(!m)return;
    const n=Number(m[1]),name=m[2].trim();
    if(!n||!name||name.length>40)return;
    const key=`${n}|${selkentNorm(name)}`;
    if(seen.has(key))return;
    seen.add(key);
    found.push({selkentName:`Under ${n}s ${name}`,ageGroup:`U${n}`,teamName:name,leagueName:`Shooters Hill AFC ${name}`});
  };
  doc.querySelectorAll('a,li,td,p').forEach(el=>addText(el.textContent));
  if(found.length<3){
    const raw=doc.body?.innerText||doc.body?.textContent||'';
    raw.split(/\n+/).forEach(addText);
  }
  return found.sort((a,b)=>Number(a.ageGroup.slice(1))-Number(b.ageGroup.slice(1))||a.teamName.localeCompare(b.teamName));
}
function clubTeams(){
  const list=Array.isArray(state.selkent?.clubTeams)&&state.selkent.clubTeams.length?state.selkent.clubTeams:SHOOTERS_HILL_STARTER_TEAMS;
  return [...list].sort((a,b)=>Number(String(a.ageGroup).replace(/\D/g,''))-Number(String(b.ageGroup).replace(/\D/g,''))||String(a.teamName).localeCompare(String(b.teamName)));
}
function selectedClubTeam(){
  const select=document.getElementById('settings-team-name');
  const key=select?.value||'';
  return clubTeams().find(t=>t.selkentName===key)||null;
}
function renderClubTeamOptions(){
  const select=document.getElementById('settings-team-name');
  if(!select)return;
  const list=clubTeams();
  if(isTeamLocked()){
    const team=assignedTeam();
    select.innerHTML=`<option value="${esc(team.selkentName)}">${esc(team.ageGroup+' '+team.teamName)}</option>`;
    select.value=team.selkentName;select.disabled=true;
  }else{
    select.disabled=false;
    const current=list.find(t=>t.ageGroup===state.meta.ageGroup&&(selkentNorm(t.leagueName)===selkentNorm(state.division.teamName)||selkentNorm(t.teamName)===selkentNorm(state.meta.teamName)));
    select.innerHTML=list.map(t=>`<option value="${esc(t.selkentName)}">${esc(t.ageGroup+' '+t.teamName)}</option>`).join('');
    if(current) select.value=current.selkentName;
    else if(state.meta.teamName){
      const fallback=`${state.meta.ageGroup||''} ${state.meta.teamName}`.trim();
      const opt=document.createElement('option');opt.value='__current__';opt.textContent=fallback;select.prepend(opt);select.value='__current__';
    }
  }
  const count=document.getElementById('selkent-club-team-count');
  if(count)count.textContent=`${list.length} Shooters Hill team${list.length===1?'':'s'} available`;
  renderAssignmentTeamOptions();
}
function applySelectedClubTeamToForm(){
  const team=selectedClubTeam();
  if(!team)return;
  const age=document.getElementById('settings-auto-age');
  const division=document.getElementById('settings-auto-division');
  if(age)age.textContent=team.ageGroup||'—';
  if(division)division.textContent=team.division||((team.ageGroup===state.meta.ageGroup)?(state.division.name||'Not synced yet'):'Not synced yet');
}
async function syncShootersHillClubTeams(silent=true){
  state.selkent=state.selkent||cloneStarter().selkent;
  const url=state.selkent.clubUrl||STARTER_DATA.selkent.clubUrl;
  try{
    const response=await nativeHttp(url);
    const teams=parseShootersHillClubTeams(response.body);
    if(teams.length<3)throw new Error('No Shooters Hill team list recognised');
    state.selkent.clubTeams=teams;
    state.selkent.lastClubSync=new Date().toISOString();
    localStorage.setItem(STORAGE_KEY,JSON.stringify(state));
    if(CLOUD_MODE&&isAdmin())window.ValiantsCloud?.syncTeamDirectory?.(teams).catch(()=>{});
    renderClubTeamOptions();
    if(!silent)toast(`${teams.length} Shooters Hill teams synced`);
    return teams;
  }catch(err){
    if(!Array.isArray(state.selkent.clubTeams)||!state.selkent.clubTeams.length)state.selkent.clubTeams=SHOOTERS_HILL_STARTER_TEAMS;
    renderClubTeamOptions();
    if(!silent)toast('Using saved Shooters Hill team list');
    return state.selkent.clubTeams;
  }
}
function selkentScope(doc){
  const needle=selkentNorm(state.division.name||'');
  if(!needle)return doc.body;
  const selectors='h1,h2,h3,h4,h5,h6,legend,summary,.card-header,.panel-heading,.accordion-header,strong';
  const hit=[...doc.querySelectorAll(selectors)].find(el=>selkentNorm(el.textContent).includes(needle));
  if(!hit)return doc.body;
  const container=hit.closest('section,article,.card,.panel,.accordion-item,fieldset,.tab-pane')||hit.parentElement;
  return container&&container.textContent.trim().length>needle.length+20?container:doc.body;
}
function parseNumberCell(v){const n=String(v).replace(/[^0-9-]/g,'');return /^-?\d+$/.test(n)?Number(n):null;}
function plausibleTeamName(v=''){
  const t=String(v).replace(/\s+/g,' ').trim();
  if(t.length<3||t.length>80)return false;
  if(/^\d+$/.test(t)||/^\d{1,2}[:.]\d{2}$/.test(t)||/^\d{1,2}[\s\/-](jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)/i.test(t))return false;
  if(/^(home|away|venue|date|time|fixture|fixtures|result|results|details|postponed|cancelled|league|division|played|points|pts)$/i.test(t))return false;
  return /[a-z]/i.test(t);
}
function parseSelkentDate(text=''){
  const direct=parseResultDate(text);if(direct)return direct;
  const m=String(text).match(/\b(\d{1,2})\s+(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Sept|Oct|Nov|Dec)(?:\w*)\s*(20\d{2})?\b/i);
  if(!m)return'';
  const months={jan:1,feb:2,mar:3,apr:4,may:5,jun:6,jul:7,aug:8,sep:9,sept:9,oct:10,nov:11,dec:12};
  const mon=months[m[2].toLowerCase()],day=Number(m[1]);
  let year=m[3]?Number(m[3]):Number(String(state.meta.season||'').match(/20\d{2}/)?.[0]||new Date().getFullYear());
  if(!m[3]&&mon<=6&&String(state.meta.season||'').includes('/'))year+=1;
  return`${year}-${String(mon).padStart(2,'0')}-${String(day).padStart(2,'0')}`;
}
function standingFromCells(cells){
  const vals=cells.map(x=>String(x).replace(/\s+/g,' ').trim()).filter(Boolean);
  if(vals.length<7)return null;
  let teamIndex=-1;
  if(vals.length>=10&&parseNumberCell(vals[0])!==null&&plausibleTeamName(vals[1]))teamIndex=1;
  else teamIndex=vals.findIndex((v,i)=>plausibleTeamName(v)&&vals.slice(i+1).filter(x=>parseNumberCell(x)!==null).length>=6);
  if(teamIndex<0)return null;
  const nums=vals.slice(teamIndex+1).map(parseNumberCell).filter(n=>n!==null);
  if(nums.length<6)return null;
  const p=nums[0],w=nums[1]??0,d=nums[2]??0,l=nums[3]??0,gf=nums[4]??0,ga=nums[5]??0;
  const gd=nums.length>=8?nums[6]:gf-ga,pts=nums.length>=8?nums[7]:(nums[6]??0);
  if(p<0||p>100||w<0||d<0||l<0)return null;
  return{team:vals[teamIndex],p,w,d,l,gf,ga,gd,pts};
}
function teamPairFromCells(cells,known=[]){
  const vals=cells.map(x=>String(x).replace(/\s+/g,' ').trim()).filter(Boolean);
  const joined=vals.join(' | '),hits=[];
  known.forEach(team=>{if(joined.toLowerCase().includes(String(team).toLowerCase()))hits.push(team);});
  if(hits.length>=2)return[hits[0],hits[1]];
  const candidates=vals.filter(plausibleTeamName).filter(v=>!selkentNorm(v).includes(selkentNorm(state.division.name||''))&&!/^under\s*\d/i.test(v));
  const self=state.division.teamName||state.meta.teamName||'';
  const selfCell=candidates.find(v=>selkentNorm(v).includes(selkentNorm(self))||selkentNorm(self).includes(selkentNorm(v)));
  if(selfCell){const other=candidates.find(v=>v!==selfCell&&selkentNorm(v)!==selkentNorm(selfCell));if(other)return[selfCell,other];}
  if(candidates.length>=2)return[candidates[0],candidates[candidates.length-1]];
  return null;
}
function detectSelkentDivision(html=''){
  const doc=new DOMParser().parseFromString(html,'text/html');
  const self=selkentNorm(state.division?.teamName||state.meta.teamName||'');
  if(!self)return'';
  const all=[...doc.querySelectorAll('a,td,li,p,span,strong')];
  const hit=all.find(el=>{const raw=String(el.textContent||'').replace(/\s+/g,' ').trim();const t=selkentNorm(raw);return raw.length<160&&(t===self||t.includes(self)||(self.includes(t)&&t.length>8));});
  const looksDivision=(txt='')=>{
    const t=String(txt).replace(/\s+/g,' ').trim();
    if(!t||t.length>80)return'';
    const age=ageGroupNumber();
    if(new RegExp(`^(Under\s*${age}|U\s*${age})`, 'i').test(t) && !/Shooters Hill/i.test(t))return t;
    if(/division|league/i.test(t) && new RegExp(`${age}`).test(t))return t;
    return'';
  };
  if(hit){
    let node=hit;
    for(let depth=0;node&&depth<7;depth++,node=node.parentElement){
      const heads=[...node.querySelectorAll(':scope > h1,:scope > h2,:scope > h3,:scope > h4,:scope > h5,:scope > legend,:scope > summary,:scope > .card-header,:scope > .panel-heading')];
      for(const h of heads){const found=looksDivision(h.textContent);if(found)return found;}
      let prev=node.previousElementSibling;
      for(let i=0;prev&&i<4;i++,prev=prev.previousElementSibling){const found=looksDivision(prev.textContent);if(found)return found;}
    }
  }
  const raw=doc.body?.innerText||doc.body?.textContent||'';
  const age=ageGroupNumber();
  const lines=raw.split(/\n+/).map(x=>x.trim()).filter(Boolean);
  const selfIndex=lines.findIndex(x=>{const k=selkentNorm(x);return k.includes(self)||self.includes(k);});
  if(selfIndex>=0){
    for(let i=selfIndex-1;i>=0&&i>=selfIndex-12;i--){const found=looksDivision(lines[i]);if(found)return found;}
  }
  return'';
}

function selkentTeamMatch(a='',b=''){
  const clean=v=>selkentNorm(v).replace(/\bfootball club\b/g,'').replace(/\bfc\b/g,'').replace(/\bafc\b/g,'').replace(/\s+/g,' ').trim();
  const x=clean(a),y=clean(b);if(!x||!y)return false;
  return x===y||(x.length>8&&y.includes(x))||(y.length>8&&x.includes(y));
}
function divisionHeadingForAge(text=''){
  const t=String(text).replace(/\s+/g,' ').trim();
  const age=ageGroupNumber();if(!age||!t||t.length>90)return'';
  const prefix=new RegExp(`^(?:Under\\s*${age}|U\\s*${age})(?:s)?(?=\\s|[A-D]|$)`,'i');
  if(!prefix.test(t))return'';
  const rest=t.replace(prefix,'').trim().replace(/^[-–—:]\s*/,'');
  if(!rest||/^fixtures?|results?|teams?|division(?:s)?$/i.test(rest))return'';
  // Team labels on club pages often look like "Under 12s Lions". A division
  // normally starts with a grading letter/number or a recognised division word.
  if(!/^(?:[A-D](?:\b|\s)|Div(?:ision)?\b|Prem(?:ier)?\b|Champ(?:ionship)?\b|One\b|Two\b|Three\b|Four\b|Navy\b|Silver\b|Red\b|Blue\b|Green\b|Orange\b|Indigo\b|Olive\b|Sage\b|Aqua\b|Brown\b|Purple\b|Maroon\b|Pink\b|Mauve\b|Lime\b|Salmon\b)/i.test(rest))return'';
  return t;
}
function parseSelkentDivisionDirectory(html=''){
  const doc=new DOMParser().parseFromString(html,'text/html');
  const self=state.division?.teamName||state.meta?.teamName||'';
  if(!self)return{division:'',teams:[]};
  const raw=doc.body?.innerText||doc.body?.textContent||'';
  const lines=raw.split(/\n+/).map(x=>x.replace(/\s+/g,' ').trim()).filter(Boolean);
  const headings=[];
  lines.forEach((line,i)=>{const h=divisionHeadingForAge(line);if(h)headings.push({i,name:h});});
  for(let h=0;h<headings.length;h++){
    const start=headings[h].i+1,end=h+1<headings.length?headings[h+1].i:Math.min(lines.length,start+80);
    const block=lines.slice(start,end);
    const selfIndex=block.findIndex(line=>selkentTeamMatch(line,self));
    if(selfIndex<0)continue;
    const teams=[];const seen=new Set();
    block.forEach(line=>{
      if(divisionHeadingForAge(line)||!plausibleTeamName(line))return;
      const k=selkentNorm(line);if(!k||seen.has(k))return;
      // Exclude common page chrome while retaining real team names.
      if(/^(teams?|fixtures?|results?|home|away|table|division|select|11 teams?|12 teams?|13 teams?|14 teams?|15 teams?|16 teams?)$/i.test(line))return;
      seen.add(k);teams.push(line);
    });
    const canonicalSelf=teams.find(t=>selkentTeamMatch(t,self))||self;
    const normalisedTeams=teams.map(t=>selkentTeamMatch(t,self)?self:t);
    if(!normalisedTeams.some(t=>selkentTeamMatch(t,canonicalSelf)))normalisedTeams.push(self);
    return{division:headings[h].name,teams:normalisedTeams};
  }
  // Fall back to the older structural detector if the page layout changes.
  return{division:detectSelkentDivision(html),teams:[]};
}
function updateCurrentClubTeamDivision(division=''){
  if(!division||!Array.isArray(state.selkent?.clubTeams))return;
  const current=state.selkent.clubTeams.find(t=>String(t.ageGroup)===String(state.meta.ageGroup)&&selkentTeamMatch(t.leagueName,state.division.teamName));
  if(current)current.division=division;
}
async function syncSelkentDivision(silent=false){
  state.selkent=state.selkent||cloneStarter().selkent;
  const sk=state.selkent;
  if(!silent)toast('Checking Selkent division…');
  const page=await fetchSelkentSelected(sk.divisionsUrl||STARTER_DATA.selkent.divisionsUrl,[state.meta.ageGroup].filter(Boolean));
  const info=parseSelkentDivisionDirectory(page.html);
  if(!info.division)throw new Error(`No ${state.meta.ageGroup||''} division found for ${state.division.teamName||state.meta.teamName}`.trim());
  state.division.name=info.division;
  if(info.teams.length>=2){
    const unique=[];const seen=new Set();
    [state.division.teamName,...info.teams].filter(Boolean).forEach(t=>{const k=selkentNorm(t);if(k&&!seen.has(k)){seen.add(k);unique.push(t);}});
    state.division.teams=unique;
  }
  updateCurrentClubTeamDivision(info.division);
  state.selkent.lastDivisionSync=new Date().toISOString();
  if(CLOUD_MODE&&isAdmin())window.ValiantsCloud?.syncTeamDirectory?.(state.selkent.clubTeams).catch(()=>{});
  if(!silent)toast(`${info.division} confirmed`);
  return info;
}
async function syncSelkentLeagueTable(silent=false){
  if(!leagueTableEnabled()){
    if(!silent)toast('League table sync is available for U11 and above.');
    return false;
  }
  const sk=state.selkent||cloneStarter().selkent;
  const btn=document.getElementById('sync-league-table');if(btn)btn.disabled=true;
  if(!silent)toast('Syncing league table…');
  try{
    await syncSelkentDivision(true);
    const resultPage=await fetchSelkentSelected(sk.resultsUrl||STARTER_DATA.selkent.resultsUrl,[state.meta.ageGroup,state.division.name].filter(Boolean));
    const resultData=parseSelkentHtml(resultPage.html,resultPage.url);
    if(!resultData.table.length)throw new Error('No league table recognised on the selected Selkent division');
    state.selkent.table=resultData.table||[];
    state.selkent.results=resultData.results||[];
    applySelkentTeamDiscovery(resultData.teams||[]);
    syncOwnLeagueMatchesFromSelkent(state.selkent.results);
    state.selkent.lastTableSync=new Date().toISOString();
    state.selkent.lastSync=new Date().toISOString();
    state.selkent.status=`League table synced: ${state.division.name} · ${state.selkent.table.length} teams · ${state.selkent.results.length} results`;
    saveState();
    if(CLOUD_MODE&&isAdmin())refreshAdminClubOverview(true);
    if(!silent)toast('League table synced');
    return true;
  }catch(err){
    state.selkent.status=`League table sync failed: ${err.message||err}`;localStorage.setItem(STORAGE_KEY,JSON.stringify(state));renderSelkentSettings();if(!silent)toast('League table sync failed');return false;
  }finally{if(btn)btn.disabled=false;}
}

function stableSyncedMatchId(r){
  const raw=`${r.date||''}|${normalizeTeamKey(r.home||'')}|${normalizeTeamKey(r.away||'')}`;
  let h=2166136261;for(let i=0;i<raw.length;i++){h^=raw.charCodeAt(i);h=Math.imul(h,16777619);}return 'sk'+(h>>>0).toString(36);
}
function syncOwnLeagueMatchesFromSelkent(results=[]){
  const self=normalizeTeamKey(state.division.teamName||state.meta.teamName||'');
  if(!self)return;
  results.forEach(r=>{
    const home=normalizeTeamKey(r.home),away=normalizeTeamKey(r.away);
    const ownHome=home===self||home.includes(self)||self.includes(home);
    const ownAway=away===self||away.includes(self)||self.includes(away);
    if(!ownHome&&!ownAway)return;
    const id=stableSyncedMatchId(r);
    const opponent=ownHome?r.away:r.home;
    const match={id,date:r.date||'',competition:'League',type:'League',opponent,venue:ownHome?'H':'A',duration:null,gf:ownHome?Number(r.homeGoals||0):Number(r.awayGoals||0),ga:ownHome?Number(r.awayGoals||0):Number(r.homeGoals||0),stage:'',notes:'',source:'selkent'};
    const idx=state.matches.findIndex(m=>m.id===id||((m.source==='selkent')&&m.date===match.date&&normalizeTeamKey(m.opponent)===normalizeTeamKey(opponent)));
    if(idx>=0)state.matches[idx]={...state.matches[idx],...match};else state.matches.push(match);
  });
}
function parseSelkentHtml(html,url=''){
  const doc=new DOMParser().parseFromString(html,'text/html'),scope=selkentScope(doc),rows=[...scope.querySelectorAll('tr')].map(tr=>[...tr.querySelectorAll('th,td')].map(c=>c.textContent.trim())).filter(r=>r.length);
  const table=[];
  rows.forEach(c=>{const row=standingFromCells(c);if(row&&!table.some(x=>selkentNorm(x.team)===selkentNorm(row.team)))table.push(row);});
  const known=[...allDivisionTeams(),...table.map(r=>r.team)];
  const fixtures=[],results=[],teams=new Set(table.map(r=>r.team));
  const self=state.division.teamName||state.meta.teamName||'';
  rows.forEach(cells=>{
    const text=cells.join(' '),pair=teamPairFromCells(cells,known);if(!pair)return;
    pair.forEach(t=>teams.add(t));
    const scoreCell=cells.find(c=>/^\s*\d{1,2}\s*[-–—:]\s*\d{1,2}\s*$/.test(String(c)));
    const score=scoreCell?String(scoreCell).match(/(\d{1,2})\s*[-–—:]\s*(\d{1,2})/):null;
    const date=parseSelkentDate(text);
    if(score){results.push({id:uid('sr'),date,home:pair[0],away:pair[1],homeGoals:Number(score[1]),awayGoals:Number(score[2]),source:'selkent',raw:text});return;}
    const includesSelf=pair.some(t=>selkentNorm(t)===selkentNorm(self)||selkentNorm(t).includes(selkentNorm(self))||selkentNorm(self).includes(selkentNorm(t)));
    if(includesSelf){
      const ownIndex=pair.findIndex(t=>selkentNorm(t)===selkentNorm(self)||selkentNorm(t).includes(selkentNorm(self))||selkentNorm(self).includes(selkentNorm(t)));
      const opponent=pair[ownIndex===0?1:0];
      fixtures.push({date,opponent,venue:ownIndex===0?'H':'A',raw:text});
    }
  });
  const uniqTable=[];const seenT=new Set();table.forEach(r=>{const k=selkentNorm(r.team);if(!seenT.has(k)){seenT.add(k);uniqTable.push(r);}});
  const uniqFixtures=[];const seenF=new Set();fixtures.forEach(f=>{const k=`${f.date}|${selkentNorm(f.opponent)}|${f.venue}`;if(!seenF.has(k)){seenF.add(k);uniqFixtures.push(f);}});
  const uniqResults=[];const seenR=new Set();results.forEach(r=>{const k=leagueResultSignature(r);if(!seenR.has(k)){seenR.add(k);uniqResults.push(r);}});
  return{table:uniqTable,fixtures:uniqFixtures,results:uniqResults,teams:[...teams].filter(plausibleTeamName),url};
}
function applySelkentTeamDiscovery(discovered=[]){
  const self=state.division.teamName||state.meta.teamName||'';
  const clean=[];const seen=new Set();
  [self,...discovered].forEach(t=>{const name=String(t||'').trim(),k=selkentNorm(name);if(name&&k&&!seen.has(k)&&plausibleTeamName(name)){seen.add(k);clean.push(name);}});
  if(clean.length>=2){
    const existing=allDivisionTeams();
    const merged=[];const mseen=new Set();
    [...clean,...existing].forEach(t=>{const k=selkentNorm(t);if(k&&!mseen.has(k)){mseen.add(k);merged.push(t);}});
    state.division.teams=merged;
  }
}
function renderSelkentSettings(){
  const sk=state.selkent||STARTER_DATA.selkent;
  const auto=document.getElementById('selkent-auto-sync');if(auto)auto.checked=sk.enabled!==false;
  const tc=document.getElementById('selkent-club-team-count');
  if(tc)tc.textContent=`${clubTeams().length} Shooters Hill team${clubTeams().length===1?'':'s'} available`;
  const status=document.getElementById('selkent-sync-status'),dot=document.getElementById('selkent-sync-dot');
  if(status){
    const when=sk.lastSync?new Intl.DateTimeFormat('en-GB',{dateStyle:'medium',timeStyle:'short'}).format(new Date(sk.lastSync)):'';
    status.textContent=sk.status||(when?`Last synced ${when}`:'Not synced yet.');
  }
  if(dot){dot.className='sync-dot '+(sk.status?.toLowerCase().includes('failed')?'bad':sk.lastSync?'good':'');}
  const source=document.getElementById('selkent-division-source');if(source)source.textContent=state.division.name?`Confirmed from Selkent Divisions: ${state.division.name}`:'Division not confirmed yet';
  const tableBtn=document.getElementById('sync-league-table');if(tableBtn){tableBtn.classList.toggle('hidden',!leagueTableEnabled());tableBtn.disabled=false;}
  const tableHint=document.getElementById('league-table-sync-hint');if(tableHint)tableHint.textContent=leagueTableEnabled()?(sk.lastTableSync?`League table last synced ${new Intl.DateTimeFormat('en-GB',{dateStyle:'medium',timeStyle:'short'}).format(new Date(sk.lastTableSync))}.`:'U11+ league table is available to sync.'):'Selkent does not provide a league-table sync here for this age group.';
}
function saveSelkentSettings(){
  if(!requireCoach())return;
  state.selkent=state.selkent||cloneStarter().selkent;
  state.selkent.enabled=document.getElementById('selkent-auto-sync').checked;
  saveState();toast('Selkent sync setting saved');
}
function renderSelkentFixtures(){
  const list=document.getElementById('selkent-fixtures-list'),count=document.getElementById('selkent-fixtures-count'),meta=document.getElementById('selkent-fixtures-meta');if(!list)return;
  const fixtures=[...(state.selkent?.fixtures||[])].sort((a,b)=>(a.date||'9999').localeCompare(b.date||'9999'));
  if(count)count.textContent=String(fixtures.length);
  list.innerHTML=fixtures.slice(0,12).map(f=>`<div class="synced-fixture"><span class="synced-fixture-date">${f.date?formatDate(f.date):'TBC'}</span><span class="synced-fixture-opponent">${esc(f.opponent)}</span><span class="synced-fixture-venue">${f.venue==='A'?'Away':'Home'}</span></div>`).join('')||'<div class="empty-state compact-empty">No Selkent fixtures synced yet.</div>';
  if(meta){const when=state.selkent?.lastSync?formatDate(String(state.selkent.lastSync).slice(0,10)):'';meta.textContent=when?`Public league data last refreshed ${when}.`:'Use Selkent Sync in Settings & Data to populate fixtures.';}
}
async function syncSelkent(silent=false){
  const sk=state.selkent||cloneStarter().selkent;
  const dot=document.getElementById('selkent-sync-dot'),status=document.getElementById('selkent-sync-status');
  if(dot)dot.className='sync-dot busy';if(status)status.textContent='Checking division, fixtures and results with Selkent…';
  if(!silent)toast('Syncing with Selkent…');
  try{
    await syncShootersHillClubTeams(true);
    // The Divisions tab is authoritative for age/division membership. Resolve it
    // before visiting fixtures or results so a team can never inherit a division
    // from the previously selected team.
    await syncSelkentDivision(true);
    const fixturePage=await fetchSelkentSelected(sk.fixturesUrl||STARTER_DATA.selkent.fixturesUrl,[state.meta.ageGroup,state.division.name].filter(Boolean));
    const fixtureData=parseSelkentHtml(fixturePage.html,fixturePage.url);
    let resultData={table:[],fixtures:[],results:[],teams:[]};
    if(leagueTableEnabled()){
      const resultPage=await fetchSelkentSelected(sk.resultsUrl||STARTER_DATA.selkent.resultsUrl,[state.meta.ageGroup,state.division.name].filter(Boolean));
      resultData=parseSelkentHtml(resultPage.html,resultPage.url);
    }
    state.selkent=state.selkent||cloneStarter().selkent;
    state.selkent.fixtures=fixtureData.fixtures||[];
    if(leagueTableEnabled()){
      state.selkent.table=resultData.table||[];
      state.selkent.results=resultData.results||[];
      state.selkent.lastTableSync=new Date().toISOString();
      syncOwnLeagueMatchesFromSelkent(state.selkent.results);
    } else {state.selkent.table=[];state.selkent.results=[];state.selkent.lastTableSync='';}
    applySelkentTeamDiscovery([...(state.division.teams||[]),...(fixtureData.teams||[]),...(resultData.teams||[])]);
    state.selkent.lastSync=new Date().toISOString();
    const bits=[];if(state.division.name)bits.push(state.division.name);if(state.selkent.fixtures.length)bits.push(`${state.selkent.fixtures.length} fixture${state.selkent.fixtures.length===1?'':'s'}`);if(state.selkent.table.length)bits.push(`${state.selkent.table.length} table teams`);if(state.selkent.results.length)bits.push(`${state.selkent.results.length} results`);
    state.selkent.status=bits.length?`Synced: ${bits.join(' · ')}`:'Selkent connected, but no league data was recognised.';
    saveState();
    if(CLOUD_MODE&&isAdmin())refreshAdminClubOverview(true);
    if(!silent)toast(bits.length?'Selkent sync complete':'Selkent page loaded; check setup');
  }catch(err){
    state.selkent=state.selkent||cloneStarter().selkent;state.selkent.status=`Sync failed: ${err.message||err}`;localStorage.setItem(STORAGE_KEY,JSON.stringify(state));renderSelkentSettings();if(!silent)toast('Selkent sync failed');
  }
}
function shouldAutoSync(){
  if(state.selkent?.enabled===false)return false;
  if(!state.selkent?.lastSync)return true;
  return Date.now()-new Date(state.selkent.lastSync).getTime()>6*60*60*1000;
}

function divisionOpponents(){
  const d = state.division || STARTER_DATA.division;
  const self = String(d.teamName || '').trim().toLowerCase();
  return (d.teams || []).filter(t=>String(t).trim().toLowerCase()!==self);
}
function leagueMatchesFor(team){ return state.matches.filter(m=>isLeagueMatch(m)&&m.opponent===team).sort((a,b)=>a.date.localeCompare(b.date)); }
function statsFor(matches){
  const ms = matches || [];
  const wins = ms.filter(m=>resultOf(m)==='W').length;
  const draws = ms.filter(m=>resultOf(m)==='D').length;
  const losses = ms.filter(m=>resultOf(m)==='L').length;
  const gf = ms.reduce((s,m)=>s+Number(m.gf||0),0);
  const ga = ms.reduce((s,m)=>s+Number(m.ga||0),0);
  return { played:ms.length,wins,draws,losses,gf,ga,gd:gf-ga,winrate:ms.length?Math.round(wins/ms.length*100):0 };
}
function isCoach(){ return CLOUD_MODE ? ['admin','coach'].includes(currentRole) : (isAdmin() || (!IS_PARENT_BUILD && (IS_COACH_BUILD || account?.role==='coach'))); }
function requireCoach(message='Coach access is required to edit team data.'){
  if(isCoach()) return true;
  toast(message);
  return false;
}
function safeFileName(){ return (state.meta.teamName || 'Team').replace(/[^a-z0-9]+/gi,'_').replace(/^_|_$/g,'') || 'Team'; }
function applyAccessMode(){
  if(isTeamLocked())enforceAssignedTeam(false);
  const parent=!isCoach();
  document.body.classList.toggle('role-parent',parent);
  document.body.classList.toggle('role-admin',isAdmin());
  document.body.classList.toggle('role-coach',!isAdmin()&&isCoach());
  document.body.classList.toggle('team-locked',isTeamLocked());
  document.body.classList.toggle('build-parent',IS_PARENT_BUILD);
  document.body.classList.toggle('build-coach',IS_COACH_BUILD);
  document.body.classList.toggle('build-admin',IS_ADMIN_BUILD||BUILD_MODE==='standard');
  const summary=document.getElementById('access-summary');
  if(summary){
    if(CLOUD_MODE){
      const ct=window.ValiantsCloud?.currentTeam?.();
      const who=window.ValiantsCloud?.context?.profile?.full_name||cloudBootContext?.email||roleLabel();
      summary.textContent=`${who} · ${roleLabel()}${ct?` · ${ct.ageGroup} ${ct.teamName}`:''}. Access is enforced by the cloud account.`;
    }else if(isAdmin())summary.textContent='Club Admin access. You can select teams and create locked Coach or Parent access codes.';
    else if(account)summary.textContent=`${account.user||roleLabel()} · ${roleLabel()} · ${account.team.ageGroup} ${account.team.teamName}. Team assignment is locked.`;
    else summary.textContent=`${roleLabel()} access requires activation by a Club Admin.`;
  }
  const badge=document.getElementById('account-role-badge');
  if(badge)badge.textContent=roleLabel();
  const readOnly=document.getElementById('read-only-card');
  if(readOnly)readOnly.classList.toggle('hidden',!parent);
  updateActivationGate();
  document.getElementById('admin-club-overview')?.classList.toggle('hidden',!(CLOUD_MODE&&isAdmin()));
  renderMatches();
  renderSquad();
}

function navigate(view,scroll=true){
  if(view==='add' && !isCoach()){ toast('Parent view is read-only'); view='home'; }
  currentView=view;
  document.querySelectorAll('.view').forEach(v=>v.classList.toggle('active',v.dataset.view===view));
  renderTeamIdentity();
  document.querySelectorAll('.nav-item').forEach(b=>b.classList.toggle('active',b.dataset.nav===view));
  if(view==='add' && !document.getElementById('match-id').value) setDefaultDate();
  if(scroll) window.scrollTo({top:0,behavior:'smooth'});
}

function renderAll(){
  renderTeamIdentity();
  renderDashboard();
  renderLeagueProgramme();
  renderDivisionDatalist();
  renderMatches();
  renderSquad();
  renderPlayerSelects();
  renderScorerInputs();
  renderAwards();
  renderTeamSettings();
  renderAssignmentTeamOptions();
  renderLeagueSettings();
  renderSelkentSettings();
  renderSelkentFixtures();
  renderLeagueTable();
  renderLeagueResultsImport();
  renderFeatureSettings();
  applyAccessMode();
  if(CLOUD_MODE&&isAdmin())refreshAdminClubOverview(true);
}

function renderTeamIdentity(){
  const meta=state.meta;
  const adminHome=isAdmin()&&currentView==='home';
  document.getElementById('hero-club-name').textContent=(meta.clubName||'Shooters Hill Football Club').toUpperCase();
  document.getElementById('hero-team-name').textContent=adminHome?'CLUB OVERVIEW':(meta.teamName||'Team').toUpperCase();
  document.getElementById('hero-season-line').textContent=adminHome?[`${window.ValiantsCloud?.visibleTeamList?.().length||clubTeams().length} active teams`,meta.season].filter(Boolean).join(' · '):[meta.ageGroup,state.division.name,meta.season].filter(Boolean).join(' · ');
  document.getElementById('dashboard-season-kicker').textContent=isAdmin()?'Club administration':(meta.season||'Season')+' season';
  const homeTitle=document.getElementById('home-screen-title');if(homeTitle)homeTitle.textContent=isAdmin()?'Club Overview':'Dashboard';
  document.getElementById('squad-team-name').textContent=meta.teamName||'Team';
  document.getElementById('matches-division-kicker').textContent=state.division.name||'League';
  document.getElementById('league-summary-name').textContent=state.division.name||'League';
  document.getElementById('our-score-label').textContent=meta.teamName||'Our team';
  document.title=(adminHome?'Shooters Hill Club':(meta.teamName||'Team'))+' Tracker';
}

function setStats(prefix,s){
  const ids={played:'played',wins:'wins',draws:'draws',losses:'losses',gf:'gf',ga:'ga'};
  Object.entries(ids).forEach(([key,suffix])=>{
    const el=document.getElementById(`${prefix}-${suffix}`);
    if(el) el.textContent=s[key];
  });
}
function renderDashboard(){
  const sorted=[...state.matches].sort((a,b)=>a.date.localeCompare(b.date));
  const league=sorted.filter(isLeagueMatch);
  const friendlies=sorted.filter(isFriendlyMatch);
  const localLeagueStats=statsFor(league);
  const syncedLeagueStats=remoteLeagueStats();
  const leagueStats=(syncedLeagueStats&&syncedLeagueStats.played>=localLeagueStats.played)?syncedLeagueStats:localLeagueStats;
  const nonLeagueStats=statsFor(sorted.filter(m=>!isLeagueMatch(m)));
  const overallStats=aggregateStats(leagueStats,nonLeagueStats);
  const friendlyStats=statsFor(friendlies);

  document.getElementById('stat-played').textContent=leagueStats.played;
  document.getElementById('stat-wins').textContent=leagueStats.wins;
  document.getElementById('stat-draws').textContent=leagueStats.draws;
  document.getElementById('stat-losses').textContent=leagueStats.losses;
  document.getElementById('stat-gf').textContent=leagueStats.gf;
  document.getElementById('stat-ga').textContent=leagueStats.ga;
  document.getElementById('stat-gd').textContent=(leagueStats.gd>0?'+':'')+leagueStats.gd;
  document.getElementById('stat-winrate').textContent=leagueStats.winrate+'%';

  setStats('overall',overallStats);
  setStats('friendly',friendlyStats);

  const expected=divisionOpponents().length*Number(state.division.meetingsPerOpponent||2);
  const localLeaguePlayed=state.matches.filter(m=>isLeagueMatch(m)&&divisionOpponents().includes(m.opponent)).length;
  const leaguePlayed=Math.max(localLeaguePlayed,Number(remoteLeagueRow()?.p||0));
  document.getElementById('league-played-count').textContent=leaguePlayed;
  document.getElementById('league-total-count').textContent='/'+expected;
  document.getElementById('league-summary-text').textContent=`${divisionOpponents().length} opponents · ${expected} league matches`;

  const recent=[...sorted].reverse().slice(0,5);
  document.getElementById('recent-form').innerHTML=recent.length?recent.map(m=>`<span class="form-chip ${resultOf(m)}">${resultOf(m)}</span>`).join(''):'<span class="form-empty">No matches yet</span>';
  document.getElementById('recent-matches').innerHTML=recent.slice(0,3).map(m=>`<div class="mini-item"><div><div class="mini-team">${esc(m.opponent)}</div><div class="mini-meta">${formatDate(m.date)} · ${esc(m.competition)}</div></div><div class="scoreline">${m.gf}–${m.ga}</div></div>`).join('') || '<div class="empty-state">No match records yet.</div>';

  const scoring={};
  state.goals.forEach(g=>scoring[g.player]=(scoring[g.player]||0)+Number(g.goals||0));
  const scorerRows=Object.entries(scoring).sort((a,b)=>b[1]-a[1]||a[0].localeCompare(b[0])).slice(0,5);
  document.getElementById('top-scorers').innerHTML=scorerRows.map(([name,n],i)=>`<div class="rank-item"><div class="rank-left"><span class="rank-no">${shirtFor(name)||i+1}</span><span class="rank-name">${esc(name)}</span></div><span class="rank-value">${n}</span></div>`).join('') || '<div class="empty-state">No goals logged.</div>';

  const assisting={};
  (state.assists||[]).forEach(a=>assisting[a.player]=(assisting[a.player]||0)+Number(a.assists||0));
  const assistRows=Object.entries(assisting).sort((a,b)=>b[1]-a[1]||a[0].localeCompare(b[0])).slice(0,5);
  const assistBox=document.getElementById('top-assists');if(assistBox)assistBox.innerHTML=assistRows.map(([name,n],i)=>`<div class="rank-item"><div class="rank-left"><span class="rank-no">${shirtFor(name)||i+1}</span><span class="rank-name">${esc(name)}</span></div><span class="rank-value">${n}</span></div>`).join('') || '<div class="empty-state">No assists logged.</div>';

  const discipline={};
  (state.bookings||[]).forEach(b=>{discipline[b.player]=discipline[b.player]||{yellow:0,red:0};discipline[b.player].yellow+=Number(b.yellow||0);discipline[b.player].red+=Number(b.red||0);});
  const bookingRows=Object.entries(discipline).sort((a,b)=>(b[1].red*3+b[1].yellow)-(a[1].red*3+a[1].yellow)||a[0].localeCompare(b[0])).slice(0,5);
  const bookingBox=document.getElementById('booking-leaders');if(bookingBox)bookingBox.innerHTML=bookingRows.map(([name,c],i)=>`<div class="rank-item"><div class="rank-left"><span class="rank-no">${shirtFor(name)||i+1}</span><span class="rank-name">${esc(name)}</span></div><span class="rank-value">${c.yellow}Y${c.red?' · '+c.red+'R':''}</span></div>`).join('') || '<div class="empty-state">No bookings logged.</div>';

  const awards={};
  state.awards.forEach(a=>awards[a.player]=(awards[a.player]||0)+1);
  const awardRows=Object.entries(awards).sort((a,b)=>b[1]-a[1]||a[0].localeCompare(b[0])).slice(0,5);
  document.getElementById('award-leaders').innerHTML=awardRows.map(([name,n],i)=>`<div class="rank-item"><div class="rank-left"><span class="rank-no">${shirtFor(name)||i+1}</span><span class="rank-name">${esc(name)}</span></div><span class="rank-value">${n}</span></div>`).join('') || '<div class="empty-state">No awards logged.</div>';
}

function renderLeagueTable(){
  const enabled=leagueTableEnabled();
  const panel=document.getElementById('league-table-panel');
  const matchPanel=document.getElementById('matches-league-table-panel');
  [panel,matchPanel].forEach(el=>{if(el)el.classList.toggle('hidden',!enabled);});
  if(!enabled) return;
  const remote=(state.selkent?.table||[]);
  const table=remote.length?remote:calculateLeagueTable();
  const self=normalizeTeamKey(state.division.teamName||state.meta.teamName||'');
  const rows=table.map((r,i)=>`<tr class="${normalizeTeamKey(r.team)===self?'our-team-row':''}"><td class="pos">${i+1}</td><td class="team-cell">${esc(r.team)}</td><td>${r.p}</td><td>${r.w}</td><td>${r.d}</td><td>${r.l}</td><td>${r.gf}</td><td>${r.ga}</td><td>${r.gd>0?'+':''}${r.gd}</td><td class="pts">${r.pts}</td></tr>`).join('');
  document.querySelectorAll('[data-league-table-body]').forEach(tb=>tb.innerHTML=rows||'<tr><td colspan="10" class="table-empty">No teams configured</td></tr>');
  document.querySelectorAll('[data-league-table-title]').forEach(el=>el.textContent=state.division.name||'League table');
  const count=combinedLeagueResults().length;
  document.querySelectorAll('[data-league-table-meta]').forEach(el=>el.textContent=remote.length?`Official/public standings synced from Selkent · ${remote.length} teams`:`${count} result${count===1?'':'s'} included · calculated from entered results`);
}
function renderLeagueResultsImport(){
  const wrap=document.getElementById('league-results-import');
  if(wrap) wrap.classList.toggle('hidden',!leagueTableEnabled());
  const list=document.getElementById('imported-league-results');
  const count=document.getElementById('imported-league-count');
  const imported=state.leagueResults||[];
  if(count) count.textContent=String(imported.length);
  if(list){
    list.innerHTML=imported.slice().reverse().map(r=>`<div class="imported-result-row"><div><strong>${esc(r.home)} ${r.homeGoals}–${r.awayGoals} ${esc(r.away)}</strong>${r.date?`<span>${formatDate(r.date)}</span>`:''}</div>${isCoach()?`<button class="inline-action delete" data-delete-league-result="${r.id}">Delete</button>`:''}</div>`).join('')||'<div class="empty-state compact-empty">No pasted league results yet.</div>';
  }
}
function importPastedLeagueResults(){
  if(!requireCoach()) return;
  if(!leagueTableEnabled()){toast('League tables are available for U11 and above.');return;}
  const box=document.getElementById('league-results-paste');
  const lines=(box?.value||'').split(/\r?\n/).map(x=>x.trim()).filter(Boolean);
  if(!lines.length){toast('Paste some results first.');return;}
  const parsed=[],failed=[];
  lines.forEach(line=>{const r=parseLeagueResultLine(line);if(r)parsed.push(r);else failed.push(line);});
  const existing=new Set((state.leagueResults||[]).map(leagueResultSignature));
  let added=0,duplicates=0;
  parsed.forEach(r=>{const sig=leagueResultSignature(r);if(existing.has(sig)){duplicates++;return;}existing.add(sig);state.leagueResults.push({id:uid('lr'),...r,source:'paste'});added++;});
  saveState();
  if(box) box.value='';
  const feedback=document.getElementById('league-import-feedback');
  if(feedback){
    let msg=`Added ${added} result${added===1?'':'s'}.`;
    if(duplicates) msg+=` ${duplicates} duplicate${duplicates===1?'':'s'} skipped.`;
    if(failed.length) msg+=` ${failed.length} line${failed.length===1?'':'s'} could not be matched to teams in this division.`;
    feedback.textContent=msg;
    feedback.className='import-feedback '+(failed.length?'warn':'good');
  }
  toast(added?'League table updated':'No new results added');
}
function deleteLeagueResult(id){
  if(!requireCoach()) return;
  state.leagueResults=(state.leagueResults||[]).filter(r=>r.id!==id);saveState();toast('Imported result removed');
}
function clearImportedLeagueResults(){
  if(!requireCoach()) return;
  if(!(state.leagueResults||[]).length){toast('No imported results to clear');return;}
  if(!confirm('Clear all pasted league results? Your own match entries will not be deleted.')) return;
  state.leagueResults=[];saveState();toast('Imported league results cleared');
}
function renderDivisionDatalist(){
  const list=document.getElementById('division-opponents-list');
  if(!list) return;
  list.innerHTML=divisionOpponents().map(t=>`<option value="${esc(t)}"></option>`).join('');
}
function renderLeagueProgramme(){
  const opponents=divisionOpponents();
  const meetings=Number(state.division.meetingsPerOpponent||2);
  const expected=opponents.length*meetings;
  const played=Math.max(state.matches.filter(m=>isLeagueMatch(m)&&opponents.includes(m.opponent)).length,Number(remoteLeagueRow()?.p||0));
  document.getElementById('league-programme-title').textContent=`${opponents.length} opponents · ${meetings} meetings each`;
  document.getElementById('league-programme-progress').textContent=`${played} / ${expected}`;
  const box=document.getElementById('division-opponents');
  if(!box) return;
  box.innerHTML=opponents.map(team=>{
    const matches=leagueMatchesFor(team).slice(0,meetings);
    const resultChips=matches.map(m=>`<span class="league-result ${resultOf(m)}" title="${formatDate(m.date)} · ${m.gf}–${m.ga}">${resultOf(m)} ${m.gf}–${m.ga}</span>`).join('');
    const empty=Array.from({length:Math.max(0,meetings-matches.length)},()=>'<span class="league-slot" aria-hidden="true"></span>').join('');
    return `<div class="division-row"><div class="division-team">${esc(team)}</div><div class="division-results">${resultChips}${empty}<span class="division-count">${matches.length}/${meetings}</span></div></div>`;
  }).join('') || '<div class="empty-state">No league opponents configured.</div>';
}

function matchCardHTML(m){
  const r=resultOf(m);
  const venue=m.venue?` · ${esc(m.venue)}`:'';
  const stage=m.stage?` · ${esc(m.stage)}`:'';
  const goalCount=state.goals.filter(g=>g.matchId===m.id).reduce((n,g)=>n+Number(g.goals||0),0);
  const assistCount=(state.assists||[]).filter(a=>a.matchId===m.id).reduce((n,a)=>n+Number(a.assists||0),0);
  const awardCount=state.awards.filter(a=>a.matchId===m.id).length;
  const bookingCount=(state.bookings||[]).filter(b=>b.matchId===m.id).reduce((n,b)=>n+Number(b.yellow||0)+Number(b.red||0),0);
  const detailBits=[];
  if(featureEnabled('goals')&&goalCount)detailBits.push(`⚽ ${goalCount}`);
  if(featureEnabled('assists')&&assistCount)detailBits.push(`A ${assistCount}`);
  if(featureEnabled('awards')&&awardCount)detailBits.push(`★ ${awardCount}`);
  if(featureEnabled('bookings')&&bookingCount)detailBits.push(`▣ ${bookingCount}`);
  const details=detailBits.length?`<div class="match-detail-badges">${detailBits.map(x=>`<span>${x}</span>`).join('')}</div>`:'';
  const actions=isCoach()?`<div class="match-actions"><button class="inline-action" data-details-match="${m.id}">Details</button>${isSyncedMatch(m)?'':`<button class="inline-action delete" data-delete-match="${m.id}">Delete</button>`}</div>`:'';
  return `<article class="match-card"><div class="result-badge ${r}">${r}</div><div><div class="match-opponent">${esc(m.opponent)}</div><div class="match-meta">${formatDate(m.date)}${venue}${stage}${isSyncedMatch(m)?' · Selkent':''}</div>${details}</div><div class="match-score">${m.gf}–${m.ga}</div>${actions}</article>`;
}
function renderMatchGroup(listId,countId,rows,emptyText){
  const list=document.getElementById(listId);
  const count=document.getElementById(countId);
  if(count) count.textContent=rows.length;
  if(list) list.innerHTML=rows.map(matchCardHTML).join('') || `<div class="empty-state"><strong>${emptyText}</strong></div>`;
}
function renderMatches(){ applyMatchFilter(); }
function applyMatchFilter(){
  const q=(document.getElementById('match-search')?.value||'').trim().toLowerCase();
  const filterRows=rows=>rows.filter(m=>!q||String(m.opponent||'').toLowerCase().includes(q)).sort((a,b)=>b.date.localeCompare(a.date));
  renderMatchGroup('league-match-list','league-match-count',filterRows(state.matches.filter(isLeagueMatch)),'No league matches recorded');
  renderMatchGroup('friendly-match-list','friendly-match-count',filterRows(state.matches.filter(isFriendlyMatch)),'No friendlies recorded');
  renderMatchGroup('other-match-list','other-match-count',filterRows(otherMatches()),'No cup or tournament matches recorded');
}

function detailPlayerInputs(containerId,matchId,type){
  const box=document.getElementById(containerId);if(!box)return;
  const source=type==='goals'?state.goals:(state.assists||[]);
  const key=type==='goals'?'goals':'assists';
  const map={};source.filter(x=>x.matchId===matchId).forEach(x=>map[x.player]=Number(x[key]||0));
  box.innerHTML=activePlayers().map(p=>`<label class="detail-player-row"><span><b>#${p.number}</b> ${esc(p.name)}</span><input type="number" min="0" value="${map[p.name]||0}" data-player="${esc(p.name)}"></label>`).join('')||'<div class="empty-state compact-empty">Add players to the squad first.</div>';
}
function detailBookingInputs(matchId){
  const box=document.getElementById('detail-booking-inputs');if(!box)return;
  const map={};(state.bookings||[]).filter(x=>x.matchId===matchId).forEach(x=>map[x.player]={yellow:Number(x.yellow||0),red:Number(x.red||0)});
  box.innerHTML=activePlayers().map(p=>`<div class="detail-booking-row"><span><b>#${p.number}</b> ${esc(p.name)}</span><label>Y<input type="number" min="0" max="2" value="${map[p.name]?.yellow||0}" data-player="${esc(p.name)}" data-card="yellow"></label><label>R<input type="number" min="0" max="1" value="${map[p.name]?.red||0}" data-player="${esc(p.name)}" data-card="red"></label></div>`).join('')||'<div class="empty-state compact-empty">Add players to the squad first.</div>';
}
function openMatchDetails(matchId){
  if(!requireCoach())return;
  const m=state.matches.find(x=>x.id===matchId);if(!m)return;
  document.getElementById('match-detail-id').value=m.id;
  document.getElementById('match-detail-title').textContent=`${m.opponent}`;
  document.getElementById('match-detail-summary').innerHTML=`<strong>${formatDate(m.date)}</strong><span>${esc(m.competition||'Match')} · ${m.gf}–${m.ga}${isSyncedMatch(m)?' · Synced from Selkent':''}</span>`;
  detailPlayerInputs('detail-goals-inputs',m.id,'goals');
  detailPlayerInputs('detail-assists-inputs',m.id,'assists');
  detailBookingInputs(m.id);
  const opts='<option value="">None</option>'+activePlayers().map(p=>`<option value="${esc(p.name)}">#${p.number} ${esc(p.name)}</option>`).join('');
  [['detail-award-potm','PoTM'],['detail-award-manager','Manager PoTM'],['detail-award-parent','Parent PoTM']].forEach(([id,type])=>{const el=document.getElementById(id);el.innerHTML=opts;el.value=state.awards.find(a=>a.matchId===m.id&&a.type===type)?.player||'';});
  let visible=0;document.querySelectorAll('[data-detail-feature]').forEach(sec=>{const on=featureEnabled(sec.dataset.detailFeature);sec.classList.toggle('hidden',!on);if(on)visible++;});
  document.getElementById('empty-detail-options').classList.toggle('hidden',visible>0);
  document.getElementById('save-match-details').classList.toggle('hidden',visible===0);
  document.getElementById('match-detail-dialog').showModal();
}
function saveMatchDetails(e){
  e.preventDefault();if(!requireCoach())return;
  const id=document.getElementById('match-detail-id').value;const m=state.matches.find(x=>x.id===id);if(!m)return;
  if(featureEnabled('goals')){
    state.goals=state.goals.filter(x=>x.matchId!==id);
    document.querySelectorAll('#detail-goals-inputs input[data-player]').forEach(i=>{const n=Number(i.value||0);if(n>0)state.goals.push({id:uid('g'),matchId:id,player:i.dataset.player,goals:n});});
  }
  if(featureEnabled('assists')){
    state.assists=(state.assists||[]).filter(x=>x.matchId!==id);
    document.querySelectorAll('#detail-assists-inputs input[data-player]').forEach(i=>{const n=Number(i.value||0);if(n>0)state.assists.push({id:uid('as'),matchId:id,player:i.dataset.player,assists:n});});
  }
  if(featureEnabled('bookings')){
    state.bookings=(state.bookings||[]).filter(x=>x.matchId!==id);
    const map={};document.querySelectorAll('#detail-booking-inputs input[data-player]').forEach(i=>{map[i.dataset.player]=map[i.dataset.player]||{yellow:0,red:0};map[i.dataset.player][i.dataset.card]=Number(i.value||0);});
    Object.entries(map).forEach(([player,c])=>{if(c.yellow||c.red)state.bookings.push({id:uid('b'),matchId:id,player,yellow:c.yellow,red:c.red});});
  }
  if(featureEnabled('awards')){
    state.awards=state.awards.filter(a=>a.matchId!==id||!['PoTM','Manager PoTM','Parent PoTM'].includes(a.type));
    [['detail-award-potm','PoTM'],['detail-award-manager','Manager PoTM'],['detail-award-parent','Parent PoTM']].forEach(([elId,type])=>{const player=document.getElementById(elId).value;if(player)state.awards.push({id:uid('a'),date:m.date,event:m.opponent,type,player,matchId:id,notes:''});});
  }
  saveState();document.getElementById('match-detail-dialog').close();toast('Match details saved');
}
function jerseyHTML(player){
  const role=player.role==='goalkeeper'?'goalkeeper':'outfield';
  return `<div class="jersey-icon ${role}" aria-label="${role==='goalkeeper'?'Goalkeeper':'Outfield'} jersey number ${player.number}">
    <svg viewBox="0 0 64 58" aria-hidden="true"><path d="M22 6 28 2h8l6 4 14 8-7 12-7-4v32H22V22l-7 4-7-12 14-8Z"/></svg>
    <span>${player.number}</span>
  </div>`;
}
function renderSquad(){
  const squad=rosterPlayers();
  document.getElementById('squad-count').textContent=squad.length;
  document.getElementById('squad-list').innerHTML=squad.map(p=>{
    const action=isCoach()?`<button class="player-edit" data-edit-player="${p.number}">Edit</button>`:'';
    const role=p.role==='goalkeeper'?'Goalkeeper':'Outfield';
    const status=p.status==='inactive'?' · Inactive':'';
    return `<article class="player-card">${jerseyHTML(p)}<div><div class="player-name">${esc(p.name)}</div><div class="player-sub">${role}${status}</div></div>${action}</article>`;
  }).join('') || '<div class="empty-state"><strong>No players yet</strong>Add players to build the squad.</div>';
}

function renderPlayerSelects(){
  const opts='<option value="">None</option>'+activePlayers().map(p=>`<option value="${esc(p.name)}">#${p.number} ${esc(p.name)}</option>`).join('');
  ['award-potm','award-manager','award-parent'].forEach(id=>{
    const el=document.getElementById(id); const v=el.value; el.innerHTML=opts; el.value=v;
  });
  const stand=document.getElementById('standalone-award-player');
  if(stand){ const v=stand.value; stand.innerHTML=activePlayers().map(p=>`<option value="${esc(p.name)}">#${p.number} ${esc(p.name)}</option>`).join(''); stand.value=v; }
}
function renderScorerInputs(existing=null){
  const area=document.getElementById('scorer-inputs');
  if(!area) return;
  const preserved={};
  area.querySelectorAll('input[data-player]').forEach(i=>preserved[i.dataset.player]=Number(i.value||0));
  const values=existing!==null?existing:preserved;
  area.innerHTML=activePlayers().map(p=>`<label class="scorer-row"><span class="scorer-player"><span class="shirt-tag">#${p.number}</span>${esc(p.name)}</span><input type="number" min="0" value="${values[p.name]||0}" data-player="${esc(p.name)}" aria-label="Goals by ${esc(p.name)}"></label>`).join('');
  area.querySelectorAll('input').forEach(i=>i.addEventListener('input',updateGoalCheck));
  updateGoalCheck();
}
function updateGoalCheck(){
  const target=Number(document.getElementById('match-gf').value||0);
  const assigned=[...document.querySelectorAll('#scorer-inputs input')].reduce((s,i)=>s+Number(i.value||0),0);
  const box=document.getElementById('goal-check');
  if(!box) return;
  box.textContent=`${assigned} of ${target} goals assigned`;
  box.classList.toggle('good',assigned===target);
  box.classList.toggle('bad',assigned!==target);
}
function renderAwards(){
  const rows=[...state.awards].sort((a,b)=>b.date.localeCompare(a.date));
  document.getElementById('awards-list').innerHTML=rows.map(a=>`<div class="award-item"><div><div class="award-type">${esc(a.type)}</div><div class="award-player">${esc(a.player)}</div><div class="award-event">${esc(a.event||'')}</div></div><div class="award-date">${formatDate(a.date)}</div></div>`).join('') || '<div class="empty-state">No awards logged.</div>';
}
function renderTeamSettings(){
  renderClubTeamOptions();
  const locked=isTeamLocked();
  const team=locked?assignedTeam():(selectedClubTeam()||{ageGroup:state.meta.ageGroup,teamName:state.meta.teamName,leagueName:state.division.teamName});
  document.getElementById('settings-season').value=state.meta.season||'';
  const autoAge=document.getElementById('settings-auto-age');if(autoAge)autoAge.textContent=team?.ageGroup||state.meta.ageGroup||'—';
  const autoDivision=document.getElementById('settings-auto-division');if(autoDivision)autoDivision.textContent=state.division.name||team?.division||'Not synced yet';
  const note=document.getElementById('team-lock-note');
  if(note){note.classList.toggle('hidden',!locked);note.textContent=locked?`Team locked by Club Admin: ${team.ageGroup} ${team.teamName}. Age group and team cannot be changed from this account.`:'';}
}
async function switchAdminTeamAndLoad(cloudTeam){
  if(!CLOUD_MODE||!isAdmin()||!cloudTeam)return;
  await window.ValiantsCloud.switchAdminTeam(cloudTeam.id,(assigned)=>blankStateForTeam(assigned));
  const loaded=await window.ValiantsCloud.loadInitialState(state,(assigned)=>blankStateForTeam(assigned));
  if(loaded?.state)state=repairStateIdentity(normalizeState(loaded.state));
  const current=window.ValiantsCloud.currentTeam?.();
  if(current){state.meta.teamName=current.teamName;state.meta.ageGroup=current.ageGroup;state.division.teamName=current.leagueName;if(!state.division.name&&current.division)state.division.name=current.division;}
  localStorage.setItem(STORAGE_KEY,JSON.stringify(state));renderAll();resetMatchForm();
  await syncSelkent(false);
}
async function saveTeamSettings(){
  if(!requireCoach()) return;
  const locked=isTeamLocked();
  const team=locked?assignedTeam():selectedClubTeam();
  if(!team){ alert('Choose a Shooters Hill team from the list.'); return; }
  if(CLOUD_MODE && isAdmin()){
    const currentCloud=window.ValiantsCloud?.currentTeam?.();
    const cloudTeam=(window.ValiantsCloud?.visibleTeamList?.()||[]).find(t=>t.selkentName===team.selkentName||t.leagueName===team.leagueName);
    if(cloudTeam && currentCloud?.id!==cloudTeam.id){
      try{await switchAdminTeamAndLoad(cloudTeam);toast('Team switched and synced');}catch(err){alert('Could not switch team: '+(err.message||err));}
      return;
    }
  }
  const season=document.getElementById('settings-season').value.trim();
  const oldLeagueName=state.division.teamName;
  const identityChanged=team.ageGroup!==state.meta.ageGroup||selkentNorm(team.leagueName)!==selkentNorm(state.division.teamName);
  state.meta.teamName=team.teamName;state.meta.ageGroup=team.ageGroup;state.meta.season=season||state.meta.season;
  const idx=state.division.teams.findIndex(t=>selkentNorm(t)===selkentNorm(oldLeagueName));
  if(idx>=0)state.division.teams[idx]=team.leagueName;else if(!state.division.teams.some(t=>selkentNorm(t)===selkentNorm(team.leagueName)))state.division.teams.push(team.leagueName);
  state.division.teamName=team.leagueName;
  if(identityChanged){state.division.name=team.division||'';state.division.teams=[team.leagueName];state.selkent.fixtures=[];state.selkent.results=[];state.selkent.table=[];state.selkent.lastSync='';state.selkent.lastDivisionSync='';state.selkent.lastTableSync='';state.selkent.status='Team changed — Selkent Divisions will identify the division.';}
  enforceAssignedTeam(false);saveState();toast('Team saved');
  if(identityChanged||!state.division.name)await syncSelkent(false);
}

function renderLeagueSettings(){
  const meetings=document.getElementById('settings-meetings');
  const opponents=document.getElementById('settings-opponents');
  if(meetings) meetings.value=Number(state.division.meetingsPerOpponent||2);
  if(opponents) opponents.value=divisionOpponents().join('\n');
  const div=document.getElementById('league-auto-division');if(div)div.textContent=state.division.name||'Not synced';
  const opp=document.getElementById('league-auto-opponents');if(opp)opp.textContent=String(divisionOpponents().length);
  const meet=document.getElementById('league-auto-meetings');if(meet)meet.textContent=`${Number(state.division.meetingsPerOpponent||2)} each`;
}
function saveLeagueSettings(){
  if(!requireCoach()) return;
  const meetings=Math.max(1,Math.min(10,Number(document.getElementById('settings-meetings').value||2)));
  const raw=document.getElementById('settings-opponents').value
    .split(/\r?\n/)
    .map(x=>x.trim())
    .filter(Boolean);
  const seen=new Set();
  const self=(state.division.teamName||state.meta.teamName||'').trim();
  const opponents=[];
  raw.forEach(name=>{
    const key=name.toLowerCase();
    if(!key || key===self.toLowerCase() || seen.has(key)) return;
    seen.add(key);
    opponents.push(name);
  });
  state.division.meetingsPerOpponent=meetings;
  state.division.teams=[...opponents];
  if(self) state.division.teams.push(self);
  saveState();
  toast('League teams saved');
}

function renderFeatureSettings(){
  ['goals','assists','awards','bookings'].forEach(name=>{const el=document.getElementById('feature-'+name);if(el)el.checked=featureEnabled(name);});
  document.querySelectorAll('[data-feature-panel]').forEach(el=>el.classList.toggle('hidden',!featureEnabled(el.dataset.featurePanel)));
}
function saveFeatureSettings(){
  if(!requireCoach())return;
  state.features=state.features||{};
  ['goals','assists','awards','bookings'].forEach(name=>state.features[name]=!!document.getElementById('feature-'+name)?.checked);
  saveState();toast('Match detail options saved');
}
function clearDetailData(type){
  if(!requireCoach())return;
  const labels={goals:'all goalscorer data',assists:'all assist data',awards:'all player award data',bookings:'all booking data'};
  if(!confirm(`Permanently delete ${labels[type]||'this data'} for this team?`))return;
  if(type==='goals')state.goals=[];if(type==='assists')state.assists=[];if(type==='awards')state.awards=[];if(type==='bookings')state.bookings=[];
  saveState();toast('Stored detail data cleared');
}
let __adminOverviewStamp=0;
async function refreshAdminClubOverview(quiet=false){
  const panel=document.getElementById('admin-club-overview');if(!panel)return;
  const show=CLOUD_MODE&&isAdmin();panel.classList.toggle('hidden',!show);if(!show)return;
  if(quiet&&Date.now()-__adminOverviewStamp<15000)return;__adminOverviewStamp=Date.now();
  const meta=document.getElementById('admin-overview-meta');if(meta)meta.textContent='Refreshing synced club data…';
  try{
    const rows=await window.ValiantsCloud.getClubOverview();
    let synced=0,fixtures=0,results=0;
    rows.forEach(r=>{const st=r.state||{};if(st.selkent?.lastSync)synced++;fixtures+=Number(st.selkent?.fixtures?.length||0);results+=Number(st.selkent?.results?.length||0);});
    document.getElementById('admin-team-count').textContent=rows.length;
    document.getElementById('admin-synced-count').textContent=synced;
    document.getElementById('admin-fixtures-count').textContent=fixtures;
    document.getElementById('admin-results-count').textContent=results;
    const activeId=window.ValiantsCloud.currentTeam?.()?.id;
    const grid=document.getElementById('admin-team-grid');
    grid.innerHTML=rows.map(r=>{const st=r.state||{};const table=Array.isArray(st.selkent?.table)?st.selkent.table:[];const own=table.find(x=>normalizeTeamKey(x.team)===normalizeTeamKey(r.team.leagueName));const played=own?.p??st.matches?.filter(isLeagueMatch).length??0;const rawDiv=st.division?.name||r.team.division||'';const ageNo=Number(String(r.team.ageGroup||'').replace(/\D/g,''));const divAge=Number(String(rawDiv).match(/(?:Under\s*|U\s*)(\d{1,2})/i)?.[1]||0);const div=(divAge&&ageNo&&divAge!==ageNo)?'Needs Selkent sync':(rawDiv||'Division not synced');const when=st.selkent?.lastSync?new Intl.DateTimeFormat('en-GB',{day:'numeric',month:'short',hour:'2-digit',minute:'2-digit'}).format(new Date(st.selkent.lastSync)):'Not synced';return `<article class="admin-team-card ${r.team.id===activeId?'active-team':''}"><div class="admin-team-card-head"><span>${esc(r.team.ageGroup)}</span><strong>${esc(r.team.teamName)}</strong></div><div class="admin-team-division">${esc(div)}</div><div class="admin-team-mini"><span><b>${played}</b> P</span><span><b>${st.selkent?.fixtures?.length||0}</b> fixtures</span><span><b>${st.selkent?.results?.length||0}</b> results</span></div><small>${esc(when)}</small><button class="secondary-button compact" data-admin-open-team="${r.team.id}">${r.team.id===activeId?'Selected':'Open team'}</button></article>`;}).join('')||'<div class="empty-state">No club teams available.</div>';
    if(meta)meta.textContent=`${synced} of ${rows.length} teams have Selkent sync data.`;
  }catch(err){if(meta)meta.textContent='Club overview could not be refreshed: '+(err.message||err);}
}

function setDefaultDate(){
  const el=document.getElementById('match-date');
  if(el&&!el.value) el.value=new Date().toISOString().slice(0,10);
}
function resetMatchForm(){
  document.getElementById('match-form').reset();
  document.getElementById('match-id').value='';
  document.getElementById('match-competition').value='League';
  document.getElementById('match-gf').value=0;
  document.getElementById('match-ga').value=0;
  document.getElementById('form-title').textContent='Add Match';
  document.getElementById('form-kicker').textContent='Matchday entry';
  document.getElementById('cancel-edit').classList.add('hidden');
  setDefaultDate();
  renderScorerInputs({});
  renderPlayerSelects();
}
function editMatch(id){
  if(!requireCoach()) return;
  const m=state.matches.find(x=>x.id===id); if(!m) return;
  navigate('add');
  document.getElementById('match-id').value=m.id;
  document.getElementById('match-date').value=m.date;
  document.getElementById('match-opponent').value=m.opponent;
  document.getElementById('match-competition').value=m.competition;
  if(!document.getElementById('match-competition').value) document.getElementById('match-competition').add(new Option(m.competition,m.competition,true,true));
  document.getElementById('match-venue').value=m.venue||'';
  document.getElementById('match-stage').value=m.stage||'';
  document.getElementById('match-gf').value=m.gf;
  document.getElementById('match-ga').value=m.ga;
  document.getElementById('match-notes').value=m.notes||'';
  const gs={};
  state.goals.filter(g=>g.matchId===id).forEach(g=>gs[g.player]=g.goals);
  renderScorerInputs(gs);
  ['award-potm','award-manager','award-parent'].forEach(x=>document.getElementById(x).value='');
  state.awards.filter(a=>a.matchId===id).forEach(a=>{
    if(a.type==='PoTM') document.getElementById('award-potm').value=a.player;
    if(a.type==='Manager PoTM') document.getElementById('award-manager').value=a.player;
    if(a.type==='Parent PoTM') document.getElementById('award-parent').value=a.player;
  });
  document.getElementById('form-title').textContent='Edit Match';
  document.getElementById('form-kicker').textContent='Update matchday record';
  document.getElementById('cancel-edit').classList.remove('hidden');
}
function submitMatch(e){
  e.preventDefault();
  if(!requireCoach()) return;
  const id=document.getElementById('match-id').value||uid('m');
  const existing=state.matches.find(x=>x.id===id);
  const competition=document.getElementById('match-competition').value;
  const m={
    id,
    date:document.getElementById('match-date').value,
    opponent:document.getElementById('match-opponent').value.trim(),
    competition,
    type:competition.includes('Tournament')?'Tournament':competition,
    venue:document.getElementById('match-venue').value,
    duration:existing?.duration ?? null,
    stage:document.getElementById('match-stage').value.trim(),
    gf:Number(document.getElementById('match-gf').value||0),
    ga:Number(document.getElementById('match-ga').value||0),
    notes:document.getElementById('match-notes').value.trim()
  };
  const idx=state.matches.findIndex(x=>x.id===id);
  if(idx>=0) state.matches[idx]=m; else state.matches.push(m);
  state.goals=state.goals.filter(g=>g.matchId!==id);
  document.querySelectorAll('#scorer-inputs input').forEach(i=>{
    const n=Number(i.value||0);
    if(n>0) state.goals.push({id:uid('g'),matchId:id,player:i.dataset.player,goals:n});
  });
  state.awards=state.awards.filter(a=>a.matchId!==id || !['PoTM','Manager PoTM','Parent PoTM'].includes(a.type));
  [['award-potm','PoTM'],['award-manager','Manager PoTM'],['award-parent','Parent PoTM']].forEach(([elId,type])=>{
    const player=document.getElementById(elId).value;
    if(player) state.awards.push({id:uid('a'),date:m.date,event:m.opponent,type,player,matchId:id,notes:''});
  });
  saveState();
  resetMatchForm();
  navigate('matches');
  toast('Match saved');
}
function deleteMatch(id){
  if(!requireCoach()) return;
  const m=state.matches.find(x=>x.id===id); if(!m) return;
  if(!confirm(`Delete the match against ${m.opponent}?`)) return;
  state.matches=state.matches.filter(x=>x.id!==id);
  state.goals=state.goals.filter(g=>g.matchId!==id);
  state.assists=(state.assists||[]).filter(a=>a.matchId!==id);
  state.bookings=(state.bookings||[]).filter(b=>b.matchId!==id);
  state.awards=state.awards.filter(a=>a.matchId!==id);
  saveState();
  toast('Match deleted');
}

function openPlayerDialog(number=null){
  if(!requireCoach()) return;
  const dialog=document.getElementById('player-dialog');
  const existing=state.squad.find(p=>p.number===Number(number));
  document.getElementById('player-original-number').value=existing?.number||'';
  document.getElementById('player-number').value=existing?.number||'';
  document.getElementById('player-name').value=existing?.name||'';
  document.getElementById('player-role').value=existing?.role==='goalkeeper'?'goalkeeper':'outfield';
  document.getElementById('player-status').value=existing?.status==='inactive'?'inactive':'active';
  document.getElementById('player-dialog-title').textContent=existing?'Edit player':'Add player';
  dialog.showModal();
}
function savePlayer(e){
  e.preventDefault();
  if(!requireCoach()) return;
  const original=Number(document.getElementById('player-original-number').value||0);
  const number=Number(document.getElementById('player-number').value);
  const name=document.getElementById('player-name').value.trim();
  const role=document.getElementById('player-role').value;
  const status=document.getElementById('player-status').value;
  if(!name || number<1 || number>99){ alert('Enter a player name and shirt number from 1 to 99.'); return; }
  const collision=state.squad.find(p=>p.number===number&&p.number!==original&&p.name);
  if(collision){ alert(`Shirt #${number} is already assigned to ${collision.name}.`); return; }
  if(original){ state.squad=state.squad.filter(p=>p.number!==original); }
  state.squad.push({number,name,status,role:role==='goalkeeper'?'goalkeeper':'outfield'});
  saveState();
  document.getElementById('player-dialog').close();
  toast('Squad updated');
}

function openAwardDialog(){
  if(!requireCoach()) return;
  document.getElementById('award-form').reset();
  document.getElementById('standalone-award-date').value=new Date().toISOString().slice(0,10);
  renderPlayerSelects();
  document.getElementById('award-dialog').showModal();
}
function saveStandaloneAward(e){
  e.preventDefault();
  if(!requireCoach()) return;
  state.awards.push({
    id:uid('a'),
    date:document.getElementById('standalone-award-date').value,
    event:document.getElementById('standalone-award-event').value.trim(),
    type:document.getElementById('standalone-award-type').value.trim(),
    player:document.getElementById('standalone-award-player').value,
    matchId:null,
    notes:document.getElementById('standalone-award-notes').value.trim()
  });
  saveState();
  document.getElementById('award-dialog').close();
  toast('Award added');
}

function download(name,text,type){
  const blob=new Blob([text],{type});
  const a=document.createElement('a');
  a.href=URL.createObjectURL(blob);
  a.download=name;
  a.click();
  setTimeout(()=>URL.revokeObjectURL(a.href),800);
}
function csvCell(v){ const s=String(v??''); return /[",\n]/.test(s)?`"${s.replaceAll('"','""')}"`:s; }
function exportMatches(){
  if(!requireCoach()) return;
  const rows=[['Date','Competition','Type','Opponent','Venue','Duration','GF','GA','Result','Stage','Notes'],...state.matches.slice().sort((a,b)=>a.date.localeCompare(b.date)).map(m=>[m.date,m.competition,m.type,m.opponent,m.venue,m.duration??'',m.gf,m.ga,resultOf(m),m.stage,m.notes])];
  download(`${safeFileName()}_Matches_${state.meta.season.replace('/','-')}.csv`,rows.map(r=>r.map(csvCell).join(',')).join('\n'),'text/csv;charset=utf-8');
}
function exportGoals(){
  if(!requireCoach()) return;
  const matchMap=Object.fromEntries(state.matches.map(m=>[m.id,m]));
  const rows=[['Date','Opponent','Player','Shirt No','Goals','Competition'],...state.goals.map(g=>{const m=matchMap[g.matchId]||{};return[m.date||'',m.opponent||'',g.player,shirtFor(g.player),g.goals,m.competition||''];})];
  download(`${safeFileName()}_Goals_${state.meta.season.replace('/','-')}.csv`,rows.map(r=>r.map(csvCell).join(',')).join('\n'),'text/csv;charset=utf-8');
}
function importBackup(file){
  if(!requireCoach()) return;
  const reader=new FileReader();
  reader.onload=()=>{
    try{
      const incoming=repairStateIdentity(normalizeState(JSON.parse(reader.result)));
      if(isTeamLocked()&&selkentNorm(incoming.division.teamName)!==selkentNorm(assignedTeam().leagueName)){alert('That backup belongs to a different team. This account is locked to '+assignedTeam().ageGroup+' '+assignedTeam().teamName+'.');return;}
      state=incoming;enforceAssignedTeam(false);saveState();toast('Backup imported');
    }catch{ alert('That file is not a valid team tracker backup.'); }
  };
  reader.readAsText(file);
}
function toast(msg){
  const t=document.getElementById('toast');
  t.textContent=msg;
  t.classList.add('show');
  clearTimeout(window.__toast);
  window.__toast=setTimeout(()=>t.classList.remove('show'),1800);
}

// Events
document.addEventListener('click',e=>{
  const nav=e.target.closest('[data-nav]');
  if(nav){ navigate(nav.dataset.nav); return; }
  if(e.target.closest('[data-action="quick-add"]')){ if(!requireCoach()) return; resetMatchForm(); navigate('add'); return; }
  const details=e.target.closest('[data-details-match]'); if(details){ openMatchDetails(details.dataset.detailsMatch); return; }
  const adminTeam=e.target.closest('[data-admin-open-team]'); if(adminTeam&&isAdmin()){const team=(window.ValiantsCloud?.visibleTeamList?.()||[]).find(t=>t.id===adminTeam.dataset.adminOpenTeam);if(team)switchAdminTeamAndLoad(team).catch(err=>alert(err.message||err));return;}
  const clear=e.target.closest('[data-clear-detail]'); if(clear){clearDetailData(clear.dataset.clearDetail);return;}
  const del=e.target.closest('[data-delete-match]'); if(del){ deleteMatch(del.dataset.deleteMatch); return; }
  const ep=e.target.closest('[data-edit-player]'); if(ep){ openPlayerDialog(ep.dataset.editPlayer); return; }
  const dlr=e.target.closest('[data-delete-league-result]'); if(dlr){ deleteLeagueResult(dlr.dataset.deleteLeagueResult); return; }
});
document.getElementById('match-search').addEventListener('input',applyMatchFilter);
document.getElementById('match-gf').addEventListener('input',updateGoalCheck);
document.getElementById('match-form').addEventListener('submit',submitMatch);
document.getElementById('cancel-edit').addEventListener('click',()=>{resetMatchForm();navigate('matches');});
document.getElementById('add-player-btn').addEventListener('click',()=>openPlayerDialog());
document.getElementById('save-player').addEventListener('click',savePlayer);
document.getElementById('save-match-details').addEventListener('click',saveMatchDetails);
document.getElementById('add-award-btn').addEventListener('click',openAwardDialog);
document.getElementById('save-award').addEventListener('click',saveStandaloneAward);
document.getElementById('save-team-settings').addEventListener('click',saveTeamSettings);
document.getElementById('save-feature-settings').addEventListener('click',saveFeatureSettings);
document.getElementById('manual-result-entry')?.addEventListener('click',()=>{resetMatchForm();navigate('add');});
document.getElementById('refresh-admin-overview')?.addEventListener('click',()=>refreshAdminClubOverview(false));
document.getElementById('settings-team-name').addEventListener('change',()=>{if(!isTeamLocked())applySelectedClubTeamToForm();});
const refreshClubTeamsBtn=document.getElementById('refresh-club-teams');if(refreshClubTeamsBtn)refreshClubTeamsBtn.addEventListener('click',()=>syncShootersHillClubTeams(false));
document.getElementById('save-league-settings').addEventListener('click',saveLeagueSettings);
document.getElementById('save-selkent-settings').addEventListener('click',saveSelkentSettings);
document.getElementById('sync-selkent-now').addEventListener('click',()=>syncSelkent(false));
document.getElementById('sync-league-table')?.addEventListener('click',()=>syncSelkentLeagueTable(false));
document.getElementById('import-league-results').addEventListener('click',importPastedLeagueResults);
document.getElementById('clear-league-results').addEventListener('click',clearImportedLeagueResults);
document.getElementById('export-json').addEventListener('click',()=>{if(requireCoach())download(`${safeFileName()}_Backup_${state.meta.season.replace('/','-')}.json`,JSON.stringify(state,null,2),'application/json');});
document.getElementById('export-matches').addEventListener('click',exportMatches);
document.getElementById('export-goals').addEventListener('click',exportGoals);
document.getElementById('import-json').addEventListener('change',e=>{if(e.target.files[0])importBackup(e.target.files[0]);e.target.value='';});
document.getElementById('reset-data').addEventListener('click',()=>{if(!requireCoach())return;if(confirm("Reset this team\'s app data?")){state=(CLOUD_MODE&&window.ValiantsCloud?.currentTeam?.())?blankStateForTeam(window.ValiantsCloud.currentTeam()):(isTeamLocked()?blankStateForTeam(assignedTeam()):cloneStarter());enforceAssignedTeam(false);saveState();toast('Team data reset');}});
const activateBtn=document.getElementById('activate-account-btn');if(activateBtn)activateBtn.addEventListener('click',activateAssignment);
const generateBtn=document.getElementById('generate-assignment-code');if(generateBtn)generateBtn.addEventListener('click',generateAssignmentCode);
const copyBtn=document.getElementById('copy-assignment-code');if(copyBtn)copyBtn.addEventListener('click',copyAssignmentCode);

if('serviceWorker' in navigator && location.protocol.startsWith('http')){ window.addEventListener('load',()=>navigator.serviceWorker.register('./service-worker.js').catch(()=>{})); }

async function bootTracker(){
  if(CLOUD_MODE){
    const ctx=await window.ValiantsCloud.bootstrap({
      localState:state,
      onRemoteState:(remote)=>{state=repairStateIdentity(normalizeState(remote));localStorage.setItem(STORAGE_KEY,JSON.stringify(state));if(isTeamLocked())enforceAssignedTeam(false);renderAll();resetMatchForm();},
    });
    if(!ctx)return;
    cloudBootContext=ctx;
    currentRole=ctx.role;
    account={user:ctx.profile?.full_name||ctx.email||roleLabel(),role:ctx.role==='admin'?'admin':ctx.role,team:ctx.team};
    const loaded=await window.ValiantsCloud.loadInitialState(state,(team)=>{
      const localMatches=selkentNorm(state.division?.teamName||'')===selkentNorm(team.leagueName||'');
      return localMatches?state:blankStateForTeam(team);
    });
    if(loaded?.state){state=repairStateIdentity(normalizeState(loaded.state));localStorage.setItem(STORAGE_KEY,JSON.stringify(state));}
    if(isTeamLocked())enforceAssignedTeam(false);
  }else if(isTeamLocked())enforceAssignedTeam(true);

  resetMatchForm();
  renderAll();
  updateActivationGate();
  navigate('home',false);
  if(CLOUD_MODE){window.ValiantsCloud.updateCloudPanel?.();window.ValiantsCloud.startPolling?.();}
  setTimeout(()=>{if(!assignmentRequired()||account){if(shouldAutoSync())syncSelkent(true);}},1200);
}
bootTracker();
