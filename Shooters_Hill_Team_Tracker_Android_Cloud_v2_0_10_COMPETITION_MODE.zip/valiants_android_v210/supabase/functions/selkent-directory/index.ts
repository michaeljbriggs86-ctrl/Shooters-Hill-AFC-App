import "jsr:@supabase/functions-js/edge-runtime.d.ts";

const cors={"Access-Control-Allow-Origin":"*","Access-Control-Allow-Headers":"authorization, x-client-info, apikey, content-type","Access-Control-Allow-Methods":"GET, OPTIONS","Content-Type":"application/json; charset=utf-8"};
const AGE_RE=/^(?:U(?:8X|8|9|10X|10|11|12X|12|13|14X|14|15|16|17)|Senior)$/i;
const clean=(s:string)=>s.replace(/<script[\s\S]*?<\/script>/gi,' ').replace(/<style[\s\S]*?<\/style>/gi,' ').replace(/<[^>]+>/g,' ').replace(/&nbsp;/gi,' ').replace(/&amp;/gi,'&').replace(/&#39;/g,"'").replace(/&quot;/gi,'"').replace(/\s+/g,' ').trim();
function extractAges(html:string){
  const out:string[]=[];const seen=new Set<string>();
  for(const m of html.matchAll(/<(?:a|button|option)\b[^>]*>([\s\S]*?)<\/(?:a|button|option)>/gi)){
    const t=clean(m[1]);if(!AGE_RE.test(t))continue;const v=/^senior$/i.test(t)?'Senior':t.toUpperCase();if(!seen.has(v)){seen.add(v);out.push(v);}
  }
  return out;
}
async function get(url:string){const r=await fetch(url,{headers:{'User-Agent':'Mozilla/5.0 ShootersHillTracker/2.0.10','Accept':'text/html,application/xhtml+xml'}});if(!r.ok)throw new Error(`HTTP ${r.status}`);return await r.text();}
Deno.serve(async(req:Request)=>{
  if(req.method==='OPTIONS')return new Response('ok',{headers:cors});
  if(req.method!=='GET')return new Response(JSON.stringify({error:'Method not allowed'}),{status:405,headers:cors});
  try{
    const divisionsUrl='https://www.selkent.org.uk/public/divisions/all';
    const resultsUrl='https://www.selkent.org.uk/public/results';
    const [divisionsHtml,resultsHtml]=await Promise.all([get(divisionsUrl),get(resultsUrl)]);
    return new Response(JSON.stringify({source:{divisions:divisionsUrl,results:resultsUrl},division_age_groups:extractAges(divisionsHtml),published_league_age_groups:extractAges(resultsHtml),checked_at:new Date().toISOString()}),{status:200,headers:cors});
  }catch(e){return new Response(JSON.stringify({error:String(e)}),{status:502,headers:cors});}
});
