Shooters Hill Team Tracker Android Cloud v2.0.24

Changes in this build
- Fixes successful login getting stuck on “Signing in…” by handing the authenticated session back to the app without a forced WebView reload.
- Removes the footer navigation and uses one persistent top navigation bar across access levels.
- Background-first refresh: cloud state every ~30 seconds while visible, inbox every ~30 seconds, fixture scan every 5 minutes, fuller Selkent refresh when data is older than ~30 minutes.
- Removes visible sync/status notes from the normal user workflow.
- Adds Assistant Coach as a first-class role with the same team permissions as Coach.
- Expands Inbox to Club Admin, Coach, Assistant Coach and Parent.
- Club Admin can message any active club contact and send private-copy group messages to all club members, all coaching staff or all parents.
- Coach / Assistant Coach can message Club Admin and parents on their own team, including private-copy “All parents”.
- Parents can message Club Admin and their own team’s Coach / Assistant Coach.
- Maintains Club Admin read-only inspection of all team sporting data.

Build
The existing GitHub Action can extract this ZIP and run:
  gradle :app:assembleDebug

Android package
  com.shootershill.valiants

Version
  2.0.24


v2.0.24 changes:
- One persistent sticky top navigation bar; no floating/secondary Club navigation.
- Club always returns to Overview; Admin Inbox is a separate global tab.
- Team/Season and Advanced manual controls removed from Coach settings.
- Manual result-entry affordances removed; Selkent remains the match/fixture source.
- Match-detail wording simplified without deleting stored details.
- Age-appropriate formation presets on the tactics board.
- Maps navigation links appear when a fixture location is available.
- Team browser now appears before Needs Attention on Club Overview.

2.0.23 fixes dual Club Admin/Coach mode separation, adds Club Admin invites, and includes dual-role admins in coaching staff/team access.
