Shooters Hill Team Tracker Android source v2.0.18

This source was reconstructed from the current working APK and updated with:
- TBC fixtures until Selkent publishes them
- opposition kit colours and away-ground address lookup
- club Results browser with age-group dropdown and Previous/Next paging
- redundant Club Access panel removed from Club view
- swipeable Squad / Tactics board with draggable players
- age-appropriate 5v5 / 7v7 / 9v9 / 11v11 limits
- existing Supabase cloud accounts, roles and team data retained

The repository GitHub Action locates settings.gradle, so this ZIP can be uploaded after removing/replacing the older Android source ZIP.
